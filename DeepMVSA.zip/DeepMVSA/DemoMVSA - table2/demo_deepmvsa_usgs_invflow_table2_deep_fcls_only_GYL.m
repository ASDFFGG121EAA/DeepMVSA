%% demo_deepmvsa_usgs_invflow_table2_deep_fcls_only
% Accuracy experiment with native MVSA/Soft-ML abundances and DeepMVSA FCLS.
%
% Compared methods in the paper:
%   1) MVSA
%   2) Soft-ML
%   3) DeepMVSA-InvFlow
%
% Paper Table accuracy metrics:
%   - D_TV
%   - Vertex Error
%   - Abundance RMSE
%
% Abundance protocol used here:
%   - MVSA: use the native abundance returned by mvsa (S = QY).
%   - Soft-ML: use the native abundance returned by SoftML_Simplex_2021_v3
%              (barycentric coordinates projected onto the probability simplex).
%   - DeepMVSA: ignore the native A-Net abundance for evaluation and refit
%               abundances by fully constrained least squares (FCLS):
%
%       min_a ||y_n - M_deep a||_2^2
%       s.t.  a >= 0, 1^T a = 1.
%
% Experimental protocol aligned with the paper where explicitly stated:
%   - N = 10^4
%   - R = 20 independent repetitions
%   - Methods: MVSA / Soft-ML / DeepMVSA
%   - Mean (standard deviation) across repetitions
%
% NOTE:
%   This file intentionally preserves the CURRENT USGS/spectMixGen data
%   generator and SNR=30 setting from the user's experiment. The paper's
%   text also discusses generic synthetic K-simplices with Gaussian noise;
%   that generator is not reconstructed here because its exact vertex
%   construction is not specified in the supplied paper text.

clear; clc; close all;

%% ========================== Parameters ================================
SIGNATURES_TYPE = 1; %#ok<NASGU>
K = 2;                       % simplex dimension
p = K + 1;                   % number of endmembers
N = 10000;                   % paper accuracy table: N = 10^4
SNR = 30;
SHAPE_PARAMETER = 1;
MAX_PURIRY = 0.8;
OUTLIERS = 0;

R = 20;                      % paper: 20 independent repetitions
M_MC = 1e5;                  % Monte-Carlo samples per simplex for D_TV
MAKE_PLOTS = false;          % true -> plot only the final repetition

METHOD_NAMES = {'MVSA','Soft-ML','DeepMVSA'};
NMETHODS = numel(METHOD_NAMES);

%% ========================== Load USGS library =========================
load('USGS_1995_Library');
datalib_all = datalib;
[~, n_materiais] = size(datalib_all);
clear datalib wavlen names;

%% ========================== Storage ===================================
% Column order: MVSA, Soft-ML, DeepMVSA
TIME_ALL       = nan(R, NMETHODS);
RELERR_ALL     = nan(R, NMETHODS);
DTV_ALL        = nan(R, NMETHODS);
VOL_ALL        = nan(R, NMETHODS);
VERTEX_ALL     = nan(R, NMETHODS);
ABUND_RMSE_ALL = nan(R, NMETHODS);
SAD_ALL        = nan(R, NMETHODS);  % diagnostic only; not a paper Table-2 metric

COND_M_ALL     = nan(R,1);
LOWER_SNR_ALL  = nan(R,1);
DEEP_C_ALL     = nan(R,1);

fprintf('\n=======================================================================\n');
fprintf('PAPER-ALIGNED ACCURACY EXPERIMENT: K=%d, p=%d, N=%d, R=%d\n', K, p, N, R);
fprintf('Methods: MVSA / Soft-ML / DeepMVSA\n');
fprintf('Abundance evaluation: MVSA native | Soft-ML native | DeepMVSA post-hoc FCLS\n');
fprintf('=======================================================================\n');

%% ========================== Repetitions ================================
for trial = 1:R

    fprintf('\n-------------------------- Trial %02d / %02d --------------------------\n', ...
        trial, R);

    % Independent synthetic scene for every repetition.
    rng(trial, 'twister');

    %% ---------------------- Select true endmembers --------------------
    sel_mat = 4 + randperm(n_materiais - 4);
    sel_mat = sel_mat(1:p);
    M = datalib_all(:, sel_mat);
    L = size(M,1);

    %% ---------------------- Generate data ------------------------------
    [Y, x, noise] = spectMixGen( ...
        M, N, ...
        'Source_pdf', 'Diri_id', ...
        'pdf_pars', SHAPE_PARAMETER, ...
        'max_purity', MAX_PURIRY*ones(1,p), ...
        'no_outliers', OUTLIERS, ...
        'violation_extremes', [1,1.2], ...
        'snr', SNR, ...
        'noise_shape', 'uniform');

    x = orient_abundance(x, p, N, 'Ground-truth x');

    %% ---------------------- Project to affine set ----------------------
    [Y_proj, Up, my, sing_val] = ...
        dataProj(Y, p, 'proj_type', 'affine'); %#ok<ASGLU>

    %% ---------------------- Degree of difficulty -----------------------
    sing_vects = svds(M, p);
    COND_M_ALL(trial) = sing_vects(1) / sing_vects(end);

    Cx = Up'*(M*x)*(M*x)'*Up/N;
    Cn = Up'*noise*noise'*Up/N;
    [U, D] = svd(Cx);
    LOWER_SNR_ALL(trial) = D(p,p) / (U(:,p)'*Cn*U(:,p));

    fprintf('Conditioning number of M        = %.6f\n', COND_M_ALL(trial));
    fprintf('SNR along smallest eigenvalue  = %.6f\n', LOWER_SNR_ALL(trial));

    clear noise;

    %% ---------------------- MVSA ---------------------------------------
    % Use MVSA native abundance output for abundance RMSE.
    tic;
    [A_est, S_mvsa] = mvsa( ...
        Y_proj, p, ...
        'spherize', 'yes', ...
        'verbose', 1);
    t_mvsa = toc;
    Mvsa = Up' * A_est;

    %% ---------------------- Soft-ML ------------------------------------
    % Use Soft-ML native abundance output for abundance RMSE.
    tic;
    [M_softml, S_softml, softml_out] = SoftML_Simplex_2021_v3( ... %#ok<NASGU>
        Y, p, ...
        'YProj', Y_proj, ...
        'Up', Up, ...
        'my', my, ...
        'MTrue', M, ...
        'MaxIter', 3000, ...
        'Gamma', [], ...
        'Alpha', [], ...
        'UseConvexHullInit', true, ...
        'UseHullGradient', true, ...
        'Seed', 1, ...
        'Plot', false, ...
        'Verbose', false);
    t_softml = toc;
    Msoftml = Up' * M_softml;

    %% ---------------------- DeepMVSA-InvFlow ---------------------------
    % Native S_deep (A-Net output) is intentionally ignored for abundance RMSE.
    % DeepMVSA abundances are refitted by FCLS after endmember alignment.
    rng(1000 + trial, 'twister');

    tic;
    [M_deep, ~, ~, ~, theta] = deep_mvsa_invflow( ...
        Y, p, ...
        'spherize', 'yes', ...
        'verbose', 0, ...
        'MM_ITERS', 1500, ...
        'WARM_UP', 400, ...
        'LR', 1e-3, ...
        'LAMBDA_VOL', 0.01, ...
        'LAMBDA_NONNEG', 5, ...
        'LAMBDA_EQ', 80, ...
        'LAMBDA_SUMONE', 2, ...
        'LAMBDA_ENCLOSE', 10);
    t_deep = toc;
    Mdeep = Up' * M_deep;
    DEEP_C_ALL(trial) = theta.c;

    %% ---------------------- Common coordinates -------------------------
    Mtrue = Up' * M;
    Y_disp = Up' * Y_proj;

    %% ---------------------- Optimal permutation alignment --------------
    % One permutation per method, selected by the paper-style vertex error.
    % MVSA/Soft-ML native abundance rows follow the same permutation.
    % DeepMVSA FCLS is computed after its endmember columns are aligned.

    [vertex_mvsa, perm_mvsa] = vertex_error_optimal_perm(Mtrue, Mvsa);
    Mvsa = Mvsa(:, perm_mvsa);
    A_est = A_est(:, perm_mvsa);
    S_mvsa = orient_abundance(S_mvsa, p, N, 'MVSA abundance');
    S_mvsa = S_mvsa(perm_mvsa, :);

    [vertex_softml, perm_softml] = vertex_error_optimal_perm(Mtrue, Msoftml);
    Msoftml = Msoftml(:, perm_softml);
    M_softml = M_softml(:, perm_softml);
    S_softml = orient_abundance(S_softml, p, N, 'Soft-ML abundance');
    S_softml = S_softml(perm_softml, :);

    [vertex_deep, perm_deep] = vertex_error_optimal_perm(Mtrue, Mdeep);
    Mdeep = Mdeep(:, perm_deep);
    M_deep = M_deep(:, perm_deep);

    %% ---------------------- Abundance evaluation ------------------------
    % MVSA and Soft-ML keep their original/native abundance definitions.
    % Only DeepMVSA is post-processed with FCLS using its aligned endmembers:
    %
    %   min_A ||Y_proj - M_deep A||_F^2
    %   s.t.  A >= 0,  1^T A = 1^T.

    S_deep_fcls = estimate_abundance_fcls_active_set(M_deep, Y_proj);

    % Numerical feasibility check is only needed for the FCLS result.
    check_fcls_feasibility(S_deep_fcls, 'DeepMVSA FCLS');

    %% ---------------------- Additional statistics ----------------------
    MVSA_ERR   = norm(Mtrue - Mvsa,    'fro') / (norm(Mtrue,'fro') + eps);
    SOFTML_ERR = norm(Mtrue - Msoftml, 'fro') / (norm(Mtrue,'fro') + eps);
    DEEP_ERR   = norm(Mtrue - Mdeep,   'fro') / (norm(Mtrue,'fro') + eps);

    TIME_ALL(trial,:)   = [t_mvsa, t_softml, t_deep];
    RELERR_ALL(trial,:) = [MVSA_ERR, SOFTML_ERR, DEEP_ERR];

    %% ---------------------- D_TV ---------------------------------------
    % Same MC seed within a trial for all methods.
    mc_seed = 100000 + trial;

    rng(mc_seed, 'twister');
    [DTV_mvsa, vol_true, vol_mvsa] = tv_dist_simplex(Mtrue, Mvsa, M_MC);

    rng(mc_seed, 'twister');
    [DTV_softml, ~, vol_softml] = tv_dist_simplex(Mtrue, Msoftml, M_MC);

    rng(mc_seed, 'twister');
    [DTV_deep, ~, vol_deep] = tv_dist_simplex(Mtrue, Mdeep, M_MC);

    DTV_ALL(trial,:) = [DTV_mvsa, DTV_softml, DTV_deep];
    VOL_ALL(trial,:) = [vol_mvsa, vol_softml, vol_deep];

    %% ---------------------- Paper metric 1: Vertex Error --------------
    VERTEX_ALL(trial,:) = [vertex_mvsa, vertex_softml, vertex_deep];

    %% ---------------------- Paper metric 2: Abundance RMSE ------------
    ABUND_RMSE_ALL(trial,:) = [ ...
        abundance_rmse(x, S_mvsa), ...
        abundance_rmse(x, S_softml), ...
        abundance_rmse(x, S_deep_fcls)];

    %% ---------------------- Diagnostic: Mean SAD -----------------------
    SAD_ALL(trial,:) = [ ...
        mean_sad_deg(M, A_est), ...
        mean_sad_deg(M, M_softml), ...
        mean_sad_deg(M, M_deep)];

    %% ---------------------- Trial printout ------------------------------
    fprintf('Times (s)       : MVSA=%.3f | Soft-ML=%.3f | DeepMVSA=%.3f\n', ...
        t_mvsa, t_softml, t_deep);
    fprintf('Rel. Fro. error : MVSA=%.6f | Soft-ML=%.6f | DeepMVSA=%.6f\n', ...
        MVSA_ERR, SOFTML_ERR, DEEP_ERR);
    fprintf('D_TV            : MVSA=%.4f | Soft-ML=%.4f | DeepMVSA=%.4f\n', ...
        DTV_mvsa, DTV_softml, DTV_deep);
    fprintf('Vertex Error    : MVSA=%.6f | Soft-ML=%.6f | DeepMVSA=%.6f\n', ...
        vertex_mvsa, vertex_softml, vertex_deep);
    fprintf('Abundance RMSE  : MVSA=%.6f | Soft-ML=%.6f | DeepMVSA=%.6f  [native/native/FCLS]\n', ...
        ABUND_RMSE_ALL(trial,1), ABUND_RMSE_ALL(trial,2), ABUND_RMSE_ALL(trial,3));
    fprintf('Mean SAD (deg)  : MVSA=%.6f | Soft-ML=%.6f | DeepMVSA=%.6f\n', ...
        SAD_ALL(trial,1), SAD_ALL(trial,2), SAD_ALL(trial,3));
    fprintf('Simplex volume  : true=%.4e | MVSA=%.4e | Soft-ML=%.4e | DeepMVSA=%.4e\n', ...
        vol_true, vol_mvsa, vol_softml, vol_deep);

end

%% ========================== Final paper-style result ==================
fprintf('\n\n');
fprintf('======================================================================================\n');
fprintf('FINAL RESULTS: K=%d, p=%d, N=%d, R=%d independent repetitions\n', K, p, N, R);
fprintf('Each entry is mean (standard deviation). Lower is better.\n');
fprintf('Abundance RMSE: MVSA native | Soft-ML native | DeepMVSA post-hoc FCLS.\n');
fprintf('--------------------------------------------------------------------------------------\n');
fprintf('%-23s | %-19s | %-19s | %-19s\n', ...
    'Metric', 'MVSA', 'Soft-ML', 'DeepMVSA');
fprintf('--------------------------------------------------------------------------------------\n');
print_metric_row('D_TV', DTV_ALL, 4);
print_metric_row('Vertex Error', VERTEX_ALL, 6);
print_metric_row('Abundance RMSE', ABUND_RMSE_ALL, 6);
fprintf('======================================================================================\n');

%% ========================== Additional diagnostics ====================
fprintf('\nAdditional diagnostics (not part of the paper accuracy table):\n');
fprintf('--------------------------------------------------------------------------------------\n');
fprintf('%-23s | %-19s | %-19s | %-19s\n', ...
    'Statistic', 'MVSA', 'Soft-ML', 'DeepMVSA');
fprintf('--------------------------------------------------------------------------------------\n');
print_metric_row('Runtime (sec)', TIME_ALL, 3);
print_metric_row('Rel. Fro. error', RELERR_ALL, 6);
print_metric_row('Simplex volume', VOL_ALL, 6);
print_metric_row('Mean SAD (degree)', SAD_ALL, 6);
fprintf('--------------------------------------------------------------------------------------\n');
fprintf('Condition number of M : %.6f (%.6f)\n', mean(COND_M_ALL), std(COND_M_ALL));
fprintf('Lower-direction SNR   : %.6f (%.6f)\n', mean(LOWER_SNR_ALL), std(LOWER_SNR_ALL));
fprintf('DeepMVSA learned c    : %.6f (%.6f)\n', mean(DEEP_C_ALL), std(DEEP_C_ALL));

%% ========================== Optional last-trial plots ==================
if MAKE_PLOTS
    I = 1; J = 2; E_I = eye(p); v1 = E_I(:,I); v2 = E_I(:,J);
    Y_plot = [v1 v2]' * Y_disp;
    m_true = [v1 v2]' * Mtrue;
    m_vsa = [v1 v2]' * Mvsa;
    m_softml = [v1 v2]' * Msoftml;
    m_deep = [v1 v2]' * Mdeep;

    figure('Name','2D Projection - final repetition');
    plot(Y_plot(1,:),Y_plot(2,:),'.','Color',[0.6 0.6 0.6],'MarkerSize',4); hold on;
    plot(m_true(1,[1:p 1]),m_true(2,[1:p 1]),'k*-','LineWidth',2,'MarkerSize',10);
    plot(m_vsa(1,[1:p 1]),m_vsa(2,[1:p 1]),'ro--','LineWidth',1.5,'MarkerSize',8);
    plot(m_softml(1,[1:p 1]),m_softml(2,[1:p 1]),'bd-.','LineWidth',1.5,'MarkerSize',8);
    plot(m_deep(1,[1:p 1]),m_deep(2,[1:p 1]),'m^-.','LineWidth',1.5,'MarkerSize',8);
    xlabel('v1^T Y'); ylabel('v2^T Y');
    legend('Data','True','MVSA','Soft-ML','DeepMVSA','Location','best');
    title('Endmembers and Data Points (final repetition)'); grid on;

    figure('Name','Signatures - final repetition'); hold on;
    for i = 1:p
        plot(1:L, M(:,i)', 'k', 'LineWidth',1.5);
        plot(1:L, A_est(:,i)', 'r', 'LineWidth',1.0);
        plot(1:L, M_softml(:,i)', 'b', 'LineWidth',1.0);
        plot(1:L, M_deep(:,i)', 'm', 'LineWidth',1.0);
    end
    legend('True','MVSA','Soft-ML','DeepMVSA','Location','best');
    title('Endmember Signatures (final repetition)');
    xlabel('Spectral band'); ylabel('Reflectance'); grid on;
end

%% ========================== Local functions ============================

function check_fcls_feasibility(S, label)
%CHECK_FCLS_FEASIBILITY Verify numerical abundance constraints.
min_a = min(S(:));
max_sum_err = max(abs(sum(S,1) - 1));
if min_a < -1e-8 || max_sum_err > 1e-8
    warning('%s feasibility: min(a)=%.3e, max|sum(a)-1|=%.3e', ...
        label, min_a, max_sum_err);
end
end

function [best_err, best_perm] = vertex_error_optimal_perm(M_T, M_E)
%VERTEX_ERROR_OPTIMAL_PERM
% For K = p-1, compute
%
%   sqrt( min_perm sum_k ||m_k - mhat_perm(k)||_2^2 / (K*(K+1)) ).
%
% The returned permutation is reused for FCLS abundance refitting and SAD.

p_local = size(M_T,2);
K_local = p_local - 1;

if size(M_E,2) ~= p_local
    error('Vertex matrices must have the same number of columns.');
end

% This experiment is explicitly the K=3 / p=4 case, so exhaustive search
% over p! permutations is exact and inexpensive (4! = 24).
Pset = perms(1:p_local);
best_err = inf;
best_perm = 1:p_local;

for r = 1:size(Pset,1)
    perm = Pset(r,:);
    D = M_T - M_E(:,perm);
    err = sqrt(sum(D(:).^2) / (K_local * p_local));
    if err < best_err
        best_err = err;
        best_perm = perm;
    end
end
end

function rmse = abundance_rmse(S_true, S_est)
%ABUNDANCE_RMSE Root mean squared error over all p*N coefficients.
if ~isequal(size(S_true), size(S_est))
    error('Abundance matrices must have identical size.');
end
D = S_true - S_est;
rmse = sqrt(mean(D(:).^2));
end

function sad_mean = mean_sad_deg(M_true, M_est)
%MEAN_SAD_DEG Mean spectral angle distance in degrees, column-wise.
if ~isequal(size(M_true), size(M_est))
    error('Endmember matrices must have identical size for SAD.');
end

num = sum(M_true .* M_est, 1);
den = sqrt(sum(M_true.^2,1)) .* sqrt(sum(M_est.^2,1));
cosang = num ./ max(den, eps);
cosang = max(-1, min(1, cosang));
sad_each = acosd(cosang);
sad_mean = mean(sad_each);
end

function S = orient_abundance(S, p, N, label)
%ORIENT_ABUNDANCE Ensure abundance orientation is p x N.
if isempty(S)
    error('%s is empty.', label);
end
if isequal(size(S), [p, N])
    return;
elseif isequal(size(S), [N, p])
    S = S';
else
    error('%s has size %d x %d; expected %d x %d (or transpose).', ...
        label, size(S,1), size(S,2), p, N);
end
end

function S = estimate_abundance_fcls_active_set(M, Y)
%ESTIMATE_ABUNDANCE_FCLS_ACTIVE_SET Exact FCLS for small p by active sets.
%
% Solves independently for each column y_n:
%       min_a ||y_n - M a||_2^2
%       s.t. a >= 0,  1^T a = 1.
%
% For the current small-p experiment, all 2^p-1 non-empty active subsets
% are enumerated exactly; this avoids requiring Optimization Toolbox or SUNSAL.

[Lm, p_local] = size(M);
[Ly, N_local] = size(Y);
if Lm ~= Ly
    error('M and Y must have the same number of rows.');
end

best_rss = inf(1, N_local);
S = zeros(p_local, N_local);
y2 = sum(Y.^2, 1);
tol = 1e-10;

for mask = 1:(2^p_local - 1)
    idx = find(bitget(mask, 1:p_local));
    Ms = M(:,idx);
    s = numel(idx);

    G = Ms' * Ms;
    B = Ms' * Y;

    % Equality-constrained LS KKT system for all N columns simultaneously.
    KKT = [G + 1e-12*eye(s), ones(s,1); ones(1,s), 0];
    rhs = [B; ones(1,N_local)];
    sol = KKT \ rhs;
    A = sol(1:s,:);

    feasible = all(A >= -tol, 1);
    if ~any(feasible)
        continue;
    end

    % Residual norm without constructing an L x N residual matrix.
    GA = G * A;
    rss = y2 - 2*sum(A .* B, 1) + sum(A .* GA, 1);
    rss = max(rss, 0);

    improve = feasible & (rss < best_rss);
    if any(improve)
        best_rss(improve) = rss(improve);
        S(:,improve) = 0;
        A_use = A(:,improve);
        A_use(abs(A_use) < tol) = 0;
        A_use = max(A_use, 0);
        A_use = A_use ./ max(sum(A_use,1), eps);
        S(idx,improve) = A_use;
    end
end

if any(~isfinite(best_rss))
    error('FCLS active-set solver failed for one or more samples.');
end
end

function print_metric_row(label, X, ndigits)
%PRINT_METRIC_ROW Print mean (sample standard deviation) for all methods.
mu = mean(X,1);
sd = std(X,0,1);
fmt = sprintf('%%.%df (%%.%df)', ndigits, ndigits);

fprintf('%-23s | ', label);
for j = 1:size(X,2)
    s = sprintf(fmt, mu(j), sd(j));
    fprintf('%-19s', s);
    if j < size(X,2)
        fprintf(' | ');
    else
        fprintf('\n');
    end
end
end

function [D_TV, vol_T, vol_E] = tv_dist_simplex(M_T, M_E, M_MC)
%TV_DIST_SIMPLEX Total-variation distance between uniform distributions
%on two K-simplices (K = p-1), using the existing symmetric MC estimator.
%
%   D_TV = 1 - Vol(S_T intersect S_E) / max(Vol(S_T), Vol(S_E)).

p_local = size(M_T, 2);
K_local = p_local - 1;

E_T = M_T(:,2:p_local) - repmat(M_T(:,1), 1, K_local);
E_E = M_E(:,2:p_local) - repmat(M_E(:,1), 1, K_local);
vol_T = sqrt(max(det(E_T'*E_T), 0)) / factorial(K_local);
vol_E = sqrt(max(det(E_E'*E_E), 0)) / factorial(K_local);

G = -log(rand(p_local, M_MC));
alpha = G ./ repmat(sum(G,1), p_local, 1);
r_T = mean(in_simplex(M_T*alpha, M_E));

G = -log(rand(p_local, M_MC));
alpha = G ./ repmat(sum(G,1), p_local, 1);
r_E = mean(in_simplex(M_E*alpha, M_T));

vol_int = 0.5 * (r_T*vol_T + r_E*vol_E);
D_TV = max(1 - vol_int/max(vol_T, vol_E), 0);
end

function inside = in_simplex(X, M)
%IN_SIMPLEX Barycentric membership test for columns of X in conv(M).
tol = 1e-8;
m0 = M(:,1);
E = M(:,2:end) - repmat(m0, 1, size(M,2)-1);
C = E \ (X - repmat(m0, 1, size(X,2)));
inside = all(C >= -tol, 1) & (1 - sum(C,1) >= -tol);
end
