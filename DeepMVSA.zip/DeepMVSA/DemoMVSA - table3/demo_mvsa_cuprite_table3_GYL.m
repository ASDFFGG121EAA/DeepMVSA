%% demo_mvsa_cuprite_table3_MVSA_10runs_mean_std_no_plot
% MVSA on the AVIRIS Cuprite real data set.
%
% Table-3 protocol:
%   1) Follow the original Cuprite MVSA calling pipeline:
%        Cuprite -> HySime -> affineProj -> 30 VCA runs -> inflated simplex
%        -> mvsa_memory_peaklocal_table3(Avca*Xvca,...).
%   2) Repeat the complete stochastic MVSA estimation 10 times.
%   3) For every run compute:
%        - Runtime
%        - Peak Memory = Peak local workspace arrays inside MVSA QP optimization
%        - Vertex matching error (VME)
%        - Reconstruction RMSE
%   4) Report mean +/- sample standard deviation over the 10 runs.
%
% IMPORTANT EVALUATION CONVENTIONS:
%   - Runtime starts before the 30-run VCA initialization and stops after
%     mvsa_memory_peaklocal_table3 returns. It therefore includes 30 VCA
%     runs, the inflated-simplex SUNSAL fit, and MVSA itself.
%   - Runtime does NOT include the separate SUNSAL fit used only to evaluate
%     reconstruction RMSE.
%   - Reconstruction RMSE does NOT use the abundance Sest returned by MVSA.
%     A common SUNSAL abundance refit is computed from the estimated
%     full-spectral endmembers M_mvsa and the original 183-band Y.
%   - VME follows exactly:
%       VME = 1/(K+1) * sum_k min_{m in L}
%             ||m_hat_k - m||_2 / ||m||_2
%     Each estimated endmember is matched independently; duplicate library
%     matches are allowed; no amplitude rescaling is applied.
%   - No plotting is performed.

clear;

%% ===================== Experiment settings =====================
N_RUNS = 20;
BASE_SEED = 1;

VCA_runs = 30;
small = 1e-4;
slack = -0.01;

MVSA_MM_ITERS = 10;
MEMORY_CHECKPOINT_EVERY = 1;

%% ===================== Load Cuprite data =====================
load cuprite_ref.mat

Y = x;
band_initial = 5;
Y = Y(band_initial:end-1, :);
BANDS = BANDS(band_initial:end-1); %#ok<NASGU>
clear x;

[L, np] = size(Y);

%% ===================== HySime + perspective projection =====================
% This deterministic preprocessing is performed once and is outside the
% per-run runtime, matching the agreed Table-3 timing boundary.
[w, Rw] = estNoise(Y);
[kf, Ek, ~, ~] = hysime(Y, w, Rw);
clear w Rw;

p = 10;
Ek = Ek(:, 1:p);
Yp = Ek * Ek' * Y;

% Original real-data MVSA demo uses the dpft perspective projection.
[Yp, Up, my, ~, ~] = affineProj(Yp, p, 'proj_type', 'dpft'); %#ok<ASGLU>

fprintf('\n=======================================================================\n');
fprintf('Cuprite Table 3 experiment: MVSA, %d independent runs\n', N_RUNS);
fprintf('Pixels = %d | Bands = %d | Endmembers = %d\n', np, L, p);
fprintf('VCA runs per repetition = %d\n', VCA_runs);
fprintf('=======================================================================\n');

%% ===================== Load USGS library once =====================
if ~exist('USGU_sublibrary.mat', 'file')
    error('USGU_sublibrary.mat not found. VME cannot be computed.');
end

load USGU_sublibrary.mat
aux_lib = Areal(band_initial:end-1, :);

if size(aux_lib, 1) ~= L
    error('USGS library band count (%d) does not match Cuprite band count (%d).', ...
        size(aux_lib, 1), L);
end

[~, n_sig] = size(aux_lib); %#ok<NASGU>
ref_norms = sqrt(sum(aux_lib.^2, 1));
ref_norms = max(ref_norms, eps);

%% ===================== Storage =====================
runtime_all     = zeros(N_RUNS, 1);
peak_memory_all = zeros(N_RUNS, 1);
vme_all         = zeros(N_RUNS, 1);
rmse_all        = zeros(N_RUNS, 1);

%% ===================== Ten independent runs =====================
for run_idx = 1:N_RUNS

    fprintf('\n---------------- MVSA Run %d / %d ----------------\n', run_idx, N_RUNS);

    current_seed = BASE_SEED + run_idx - 1;
    rng(current_seed, 'twister');

    %% -------- Runtime starts here: VCA + inflated simplex + MVSA --------
    

    % 1) Original Cuprite protocol: run VCA 30 times and retain the simplex
    %    with the largest log-volume surrogate.
    vol_ant = -inf;
    Avca = [];

    for vca_idx = 1:VCA_runs
        Aux = VCA(Yp, 'Endmembers', p, 'SNR', 1, 'verbose', 'off');
        vol = sum(log(svd(Aux) + small));
        if vol > vol_ant
            Avca = Aux;
            vol_ant = vol;
        end
    end

    if isempty(Avca)
        error('VCA initialization failed to produce an initial simplex.');
    end

    % 2) Project the data onto the inflated VCA simplex, exactly following
    %    the real-data MVSA demo. Negative abundances down to -0.01 are
    %    allowed before MVSA so that samples outside the VCA simplex can be
    %    represented by the inflated simplex.
    Xvca = sunsal_mod(Avca, Yp, ...
        'POSITIVITY', slack, ...
        'VERBOSE', 'no', ...
        'ADDONE', 'yes', ...
        'lambda', 0, ...
        'AL_ITERS', 1000, ...
        'TOL', 1e-8);

    % 3) MVSA on the inflated-simplex data. S_mvsa is intentionally not
    %    used for the Table-3 reconstruction RMSE.
    run_tic = tic;
    [Amvsa, S_mvsa, ~, ~, ~, mvsa_memory_stats] = ...
        mvsa_memory_peaklocal_table3(Avca * Xvca, p, ...
        'MM_ITERS', MVSA_MM_ITERS, ...
        'spherize', 'yes', ...
        'verbose', 0, ...
        'MEASURE_OPT_MEMORY', true, ...
        'MEMORY_CHECKPOINT_EVERY', MEMORY_CHECKPOINT_EVERY);

    runtime_all(run_idx) = toc(run_tic);

    % Table-3 Peak Memory = absolute peak local workspace arrays, not delta.
    peak_memory_all(run_idx) = ...
        mvsa_memory_stats.peak_local_workspace_bytes / 1024^2;

    % Restore MVSA endmembers from the p-D perspective coordinates to the
    % original retained spectral space (183 bands for this Cuprite setup).
    M_mvsa = Up * Amvsa;

    % The MVSA-returned abundance is not used in the common reconstruction
    % evaluation protocol.
    clear S_mvsa;

    %% -------- Reconstruction RMSE: common SUNSAL refit --------
    Xmvsa_eval = sunsal_mod(M_mvsa, Y, ...
        'POSITIVITY', 0, ...
        'VERBOSE', 'no', ...
        'ADDONE', 'yes', ...
        'lambda', 0, ...
        'AL_ITERS', 1000, ...
        'TOL', 1e-8);

    Y_recon = M_mvsa * Xmvsa_eval;
    rmse_all(run_idx) = sqrt( ...
        sum((Y_recon - Y).^2, 'all') / numel(Y));

    clear Xmvsa_eval Y_recon;

    %% -------- Vertex matching error (VME) --------
    % VME = mean_k min_m ||m_hat_k-m||_2 / ||m||_2.
    % Independent matching; duplicate matches allowed; no amplitude scaling.
    vme_each = zeros(1, p);

    for k = 1:p
        end_sig = M_mvsa(:, k);
        diffs = aux_lib - end_sig;
        rel_errors = sqrt(sum(diffs.^2, 1)) ./ ref_norms;
        vme_each(k) = min(rel_errors);
    end

    vme_all(run_idx) = mean(vme_each);

    %% -------- Print this run --------
    fprintf('Runtime                    : %.6f s\n', runtime_all(run_idx));
    fprintf('Peak Memory                : %.6f MB\n', peak_memory_all(run_idx));
    fprintf('Vertex matching error (VME): %.10f\n', vme_all(run_idx));
    fprintf('Reconstruction RMSE        : %.10f\n', rmse_all(run_idx));
    fprintf('Peak local checkpoint      : %s\n', ...
        mvsa_memory_stats.peak_local_workspace_label);

    % Avoid carrying run-specific arrays into the next repetition.
    clear Aux Avca Xvca Amvsa M_mvsa mvsa_memory_stats;
    clear vme_each end_sig diffs rel_errors vol vol_ant;
end

%% ===================== Mean and sample standard deviation =====================
mean_runtime     = mean(runtime_all);
mean_peak_memory = mean(peak_memory_all);
mean_vme         = mean(vme_all);
mean_rmse        = mean(rmse_all);

std_runtime      = std(runtime_all, 0);
std_peak_memory  = std(peak_memory_all, 0);
std_vme          = std(vme_all, 0);
std_rmse         = std(rmse_all, 0);

%% ===================== Table 3 result structure =====================
table3_metrics = struct();
table3_metrics.Method = 'MVSA';
table3_metrics.NumRuns = N_RUNS;

% Store all ten repetitions for traceability.
table3_metrics.Runtime_s_runs = runtime_all;
table3_metrics.PeakMemory_MB_runs = peak_memory_all;
table3_metrics.VME_runs = vme_all;
table3_metrics.Reconstruction_RMSE_runs = rmse_all;

% Mean +/- sample SD values to report in Table 3.
table3_metrics.Runtime_s = mean_runtime;
table3_metrics.Runtime_s_SD = std_runtime;

table3_metrics.PeakMemory_MB = mean_peak_memory;
table3_metrics.PeakMemory_MB_SD = std_peak_memory;

table3_metrics.VME = mean_vme;
table3_metrics.VME_SD = std_vme;

table3_metrics.Reconstruction_RMSE = mean_rmse;
table3_metrics.Reconstruction_RMSE_SD = std_rmse;

fprintf('\n=======================================================================\n');
fprintf('TABLE 3 METRICS -- MVSA (MEAN +/- SD OF %d RUNS)\n', N_RUNS);
fprintf('-----------------------------------------------------------------------\n');
fprintf('Runtime                    : %.6f +/- %.6f s\n', ...
    table3_metrics.Runtime_s, table3_metrics.Runtime_s_SD);
fprintf('Peak Memory                : %.6f +/- %.6f MB\n', ...
    table3_metrics.PeakMemory_MB, table3_metrics.PeakMemory_MB_SD);
fprintf('Vertex matching error (VME): %.10f +/- %.10f\n', ...
    table3_metrics.VME, table3_metrics.VME_SD);
fprintf('Reconstruction RMSE        : %.10f +/- %.10f\n', ...
    table3_metrics.Reconstruction_RMSE, table3_metrics.Reconstruction_RMSE_SD);
fprintf('=======================================================================\n');
fprintf(['Runtime includes 30x VCA + inflated-simplex SUNSAL + MVSA, but excludes ' ...
    'the evaluation-only SUNSAL used for reconstruction RMSE.\n']);
fprintf(['Peak Memory is the mean of per-run absolute peak local workspace arrays ' ...
    'during MVSA QP optimization; no process-memory measurement is used.\n']);
