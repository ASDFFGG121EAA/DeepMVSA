%% demo_softml_cuprite_table3_20runs_mean_std_no_plot
% Soft-ML on AVIRIS Cuprite real data.
%
% Table 3 protocol:
%   1) Run Soft-ML independently 20 times using reproducible seeds 1..20.
%   2) For each run compute:
%        - Runtime (Soft-ML model call only)
%        - Peak Memory (Peak local workspace arrays)
%        - Vertex matching error (VME) against the USGS library
%        - Reconstruction RMSE using a common SUNSAL abundance refit
%   3) Report mean +/- sample standard deviation over all runs.
%
% Important evaluation rules:
%   - No plotting is performed.
%   - VME matches each estimated endmember independently to the USGS library.
%     Duplicate library matches are allowed and no amplitude scaling is used.
%   - Reconstruction RMSE does NOT use the S_est returned by Soft-ML.
%     Abundances are re-estimated from M_softml and the original 183-band Y
%     using the same fully constrained SUNSAL evaluation used for DeepMVSA.

clear;

%% ===================== User parameters =====================
N_RUNS = 2;
BASE_SEED = 1;

% Soft-ML settings used for the Cuprite comparison.
MAX_ITER = 300;
GAMMA = [];
ALPHA = [];
USE_CONVEX_HULL_INIT = true;
USE_HULL_GRADIENT = true;
DIAMETER_BLOCK_SIZE = 1000;

% Local-workspace memory checkpoint cadence.
MEMORY_CHECKPOINT_EVERY = 1;

%% ===================== Load Cuprite data =====================
load cuprite_ref.mat

Y = x;
band_initial = 5;
Y = Y(band_initial:end-1, :);
BANDS = BANDS(band_initial:end-1); %#ok<NASGU>
clear x;

[L, np] = size(Y);

%% ===================== HySime: determine p =====================
% Same Cuprite band domain and endmember-count protocol as the other Table-3 methods.
[w, Rw] = estNoise(Y);
[kf, ~, ~, ~] = hysime(Y, w, Rw);
clear w Rw;
p = 5;

%% ===================== External affine projection for Soft-ML =====================
% SoftML_Simplex_2021_v3 explicitly supports reusing dataProj outputs.
% This deterministic preprocessing is done once, outside the per-run model timer.
[Y_proj, Up_soft, my_soft, sing_val_soft] = ...
    dataProj(Y, p, 'proj_type', 'affine'); %#ok<NASGU>

fprintf('\n=======================================================================\n');
fprintf('Cuprite Table 3 experiment: Soft-ML, %d independent runs\n', N_RUNS);
fprintf('Pixels = %d | Bands = %d | Endmembers = %d\n', np, L, p);
fprintf('MaxIter = %d | ConvexHullInit = %d | HullGradient = %d\n', ...
    MAX_ITER, USE_CONVEX_HULL_INIT, USE_HULL_GRADIENT);
fprintf('=======================================================================\n');

%% ===================== Load USGS library once =====================
if ~exist('USGU_sublibrary.mat', 'file')
    error('USGU_sublibrary.mat not found. VME cannot be computed.');
end

load USGU_sublibrary.mat
aux_lib = Areal(band_initial:end-1, :);

if size(aux_lib, 1) ~= L
    error('USGS library band count (%d) does not match Cuprite band count (%d).', ...
        size(aux_lib, 1), L);
end

ref_norms = sqrt(sum(aux_lib.^2, 1));
ref_norms = max(ref_norms, eps);

%% ===================== Storage =====================
runtime_all     = zeros(N_RUNS, 1);
peak_memory_all = zeros(N_RUNS, 1);
vme_all         = zeros(N_RUNS, 1);
rmse_all        = zeros(N_RUNS, 1);

%% ===================== Independent runs =====================
for run_idx = 1:N_RUNS

    fprintf('\n---------------- Run %d / %d ----------------\n', run_idx, N_RUNS);

    current_seed = BASE_SEED + run_idx - 1;

    %% -------- 1. Soft-ML runtime + peak local workspace memory --------
    model_tic = tic;

    % S_softml_model is intentionally NOT used for reconstruction RMSE.
    [M_softml, S_softml_model, softml_out] = ...
        SoftML_Simplex_2021_v3_memory_peaklocal_table3( ...
        Y, p, ...
        'YProj', Y_proj, ...
        'Up', Up_soft, ...
        'my', my_soft, ...
        'MaxIter', MAX_ITER, ...
        'Gamma', GAMMA, ...
        'Alpha', ALPHA, ...
        'UseConvexHullInit', USE_CONVEX_HULL_INIT, ...
        'UseHullGradient', USE_HULL_GRADIENT, ...
        'Seed', current_seed, ...
        'Plot', false, ...
        'Verbose', false, ...
        'DiameterBlockSize', DIAMETER_BLOCK_SIZE, ...
        'MEASURE_OPT_MEMORY', true, ...
        'MEMORY_CHECKPOINT_EVERY', MEMORY_CHECKPOINT_EVERY);

    runtime_all(run_idx) = toc(model_tic);

    if ~isfield(softml_out, 'memory_stats') || ...
            ~isfield(softml_out.memory_stats, 'peak_local_workspace_bytes')
        error('Soft-ML memory statistics are missing peak_local_workspace_bytes.');
    end

    peak_memory_all(run_idx) = ...
        softml_out.memory_stats.peak_local_workspace_bytes / 1024^2;

    % Do not use the model-returned abundance for the common Table-3 RMSE.
    clear S_softml_model;

    %% -------- 2. Reconstruction RMSE --------
    % Common evaluation abundance refit in the original retained-band domain.
    Xsoft_eval = sunsal_mod(M_softml, Y, ...
        'POSITIVITY', 0, ...
        'VERBOSE', 'no', ...
        'ADDONE', 'yes', ...
        'lambda', 0, ...
        'AL_ITERS', 1000, ...
        'TOL', 1e-8);

    Y_recon = M_softml * Xsoft_eval;

    rmse_all(run_idx) = sqrt(sum((Y_recon - Y).^2, 'all') / numel(Y));

    clear Y_recon Xsoft_eval;

    %% -------- 3. Vertex matching error (VME) --------
    % VME = 1/(K+1) * sum_k min_{m in L} ||m_hat_k-m||_2 / ||m||_2
    % Independent per-estimated-vertex matching; duplicate USGS matches allowed;
    % no amplitude/least-squares scaling is applied.
    vme_each = zeros(1, p);

    for k = 1:p
        end_sig = M_softml(:, k);
        diffs = aux_lib - end_sig;
        rel_errors = sqrt(sum(diffs.^2, 1)) ./ ref_norms;
        vme_each(k) = min(rel_errors);
    end

    vme_all(run_idx) = mean(vme_each);

    %% -------- Print this run --------
    fprintf('Runtime                    : %.6f s\n', runtime_all(run_idx));
    fprintf('Peak Memory                : %.6f MB\n', peak_memory_all(run_idx));
    fprintf('Vertex matching error (VME): %.10f\n', vme_all(run_idx));
    fprintf('Reconstruction RMSE        : %.10f\n', rmse_all(run_idx));

    clear M_softml softml_out vme_each diffs rel_errors end_sig;
end

%% ===================== Mean and sample SD =====================
mean_runtime     = mean(runtime_all);
mean_peak_memory = mean(peak_memory_all);
mean_vme         = mean(vme_all);
mean_rmse        = mean(rmse_all);

std_runtime      = std(runtime_all, 0);
std_peak_memory  = std(peak_memory_all, 0);
std_vme          = std(vme_all, 0);
std_rmse         = std(rmse_all, 0);

%% ===================== Table 3 result structure =====================
table3_metrics = struct();
table3_metrics.Method = 'Soft-ML';
table3_metrics.NumRuns = N_RUNS;

table3_metrics.Runtime_s_runs = runtime_all;
table3_metrics.PeakMemory_MB_runs = peak_memory_all;
table3_metrics.VME_runs = vme_all;
table3_metrics.Reconstruction_RMSE_runs = rmse_all;

table3_metrics.Runtime_s = mean_runtime;
table3_metrics.Runtime_s_SD = std_runtime;

table3_metrics.PeakMemory_MB = mean_peak_memory;
table3_metrics.PeakMemory_MB_SD = std_peak_memory;

table3_metrics.VME = mean_vme;
table3_metrics.VME_SD = std_vme;

table3_metrics.Reconstruction_RMSE = mean_rmse;
table3_metrics.Reconstruction_RMSE_SD = std_rmse;

%% ===================== Final Table-3 output =====================
fprintf('\n=======================================================================\n');
fprintf('TABLE 3 METRICS -- Soft-ML (MEAN +/- SD OF %d RUNS)\n', N_RUNS);
fprintf('-----------------------------------------------------------------------\n');
fprintf('Runtime                    : %.6f +/- %.6f s\n', ...
    table3_metrics.Runtime_s, table3_metrics.Runtime_s_SD);
fprintf('Peak Memory                : %.6f +/- %.6f MB\n', ...
    table3_metrics.PeakMemory_MB, table3_metrics.PeakMemory_MB_SD);
fprintf('Vertex matching error (VME): %.10f +/- %.10f\n', ...
    table3_metrics.VME, table3_metrics.VME_SD);
fprintf('Reconstruction RMSE        : %.10f +/- %.10f\n', ...
    table3_metrics.Reconstruction_RMSE, table3_metrics.Reconstruction_RMSE_SD);
fprintf('=======================================================================\n');
fprintf(['Peak Memory definition: mean of the per-run Peak local workspace arrays; ' ...
    'the Soft-ML model records sum([whos.bytes]) only at the existing high-live-set ' ...
    'local-function checkpoints; no process-memory measurement is used.\n']);
