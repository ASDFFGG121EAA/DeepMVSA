function [M_est, Sest, Up, my, theta, memory_stats] = deep_mvsa_invflow_peaklocal_table3(Y, p, varargin)
%% DeepMVSA-InvFlow (mini-batch version): Invertible Coupled Q + Nonlinear Attention
% Q = L * Q0 * R, L: unit lower-tri, R: upper-tri with positive diagonal.
% A_eff = A_base + c * G .* (A_base.^2)
%
% ------------------------- MINI-BATCH TRAINING -------------------------
% Each gradient step draws BATCH_SIZE samples uniformly at random (with
% replacement). Per-sample SUM penalties (nonnegativity, sum-to-one,
% enclosure) are rescaled by N/B so that the stochastic losses and
% gradients are UNBIASED estimates of the original full-batch quantities
% -- all LAMBDA_* hyperparameters keep their original meaning and tuned
% values transfer directly. The reconstruction loss is a per-sample MEAN
% and needs no rescaling.
%
%   - Per-step cost:      O(B * (p^2 + p*h))  instead of O(N * p^2)
%   - Parameter memory:   O(p^2 + p*h), independent of N  (unchanged)
%   - Set BATCH_SIZE >= N to recover the original full-batch behavior
%     exactly (no random sampling, scaling factor N/B = 1).
%
% q_m is a fixed 1xp target vector precomputed in ONE pass over the data
% before training; it does not enter the per-iteration cost.
%
% Optional data-enclosure penalty sum(min(Q*Y,0).^2) (LAMBDA_ENCLOSE).
% Default 0 -> identical to the original version (used for Cuprite).
% For synthetic data with i.i.d. abundances, set LAMBDA_ENCLOSE = 10 to
% anchor Q to the data convex hull and prevent the simplex from
% collapsing inward under the volume term.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @isnumeric);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);   % enclosure term, default off
addParameter(pStruct, 'BATCH_SIZE', 4096, @isnumeric);    % <<< NEW: mini-batch size (>=N => full batch)
addParameter(pStruct, 'SEED', [], @isnumeric);            % <<< NEW: optional rng seed for reproducibility
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'MEASURE_OPT_MEMORY', true, @(x) islogical(x) || isnumeric(x));
parse(pStruct, varargin{:});

if ~isempty(pStruct.Results.SEED)
    rng(pStruct.Results.SEED, 'twister');
end

[L, N] = size(Y);
B = min(pStruct.Results.BATCH_SIZE, N);
full_batch = (B >= N);

%% --------------------- Preprocessing ---------------------
my = mean(Y,2); Yc = Y - repmat(my,1,N);
[Up, D] = svds(Yc*Yc'/N, p-1);
Yp = Up*Up'*Yc + repmat(my,1,N);
my_ortho = my - Up*Up'*my;
Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
Y_proj = Up'*Yp;

if strcmp(pStruct.Results.spherize, 'yes')
    lambda_reg = 1e-10;
    C = diag(1./sqrt(diag(D+lambda_reg*eye(p-1))));
    Ys = C*Up(:,1:p-1)'*(Yp-repmat(my,1,N));
    Ys(p,:) = 1; Ys = Ys/sqrt(p);
    Y_work = Ys;
else
    Y_work = Y_proj; lambda_reg = 0;
end

%% --------------------- Initialization ---------------------
if isempty(pStruct.Results.M0)
    M0 = VCA(Y_work, 'Endmembers', p, 'verbose', 'off');
else
    M0 = pStruct.Results.M0;
    if strcmp(pStruct.Results.spherize, 'yes')
        M0 = M0 - repmat(my,1,p);
        M0 = C*Up(:,1:p-1)'*M0;
        M0(p,:) = 1; M0 = M0/sqrt(p);
    else
        M0 = Up'*M0;
    end
end
Q0 = inv(M0);
qm = ones(1,N)*Y_work'*inv(Y_work*Y_work');   % one pass, O(N*p^2), fixed target thereafter

%% --------------------- Spatial coordinates ---------------------
H = round(sqrt(N)); W = round(N/H);
if H*W == N
    [gx, gy] = meshgrid(linspace(-1,1,W), linspace(-1,1,H));
    coords = [gx(:)'; gy(:)'];
else
    coords = linspace(-1,1,N); coords = coords(:)';
end
coord_dim = size(coords,1);

%% --------------------- Optimization local-workspace memory tracker ---------------------
% TABLE-3 MEMORY DEFINITION (revised):
%   Peak Memory is defined as the maximum "Peak local workspace arrays"
%   observed at explicit checkpoints during the optimization stage.
%   This follows the LOCAL-WORKSPACE checkpoint idea used in the reference
%   instrumented file, but deliberately does NOT use MATLAB process memory,
%   WorkingSet, RSS, or any OS / memory() query.
%
%   What is measured:
%     - the live MATLAB arrays visible inside key optimization routines at
%       checkpoint locations (for example A-Net forward, reconstruction,
%       enclosure, Q-gradient, gradient assembly, and A-Net backward);
%     - measured by sum([whos.bytes]) of the local function workspace at
%       that checkpoint.
%
%   What is NOT used as the main Peak Memory metric:
%     - any process-level MATLAB memory;
%     - any preprocessing-stage memory that is outside these local
%       optimization checkpoints.
%
%   The exact theta + Adam(m,v) bytes are still reported separately as an
%   auxiliary diagnostic, but the Table-3 "Peak Memory" value equals the
%   peak local-workspace arrays metric.
measure_opt_memory = logical(pStruct.Results.MEASURE_OPT_MEMORY);
memory_stats = struct();
memory_stats.definition = ['Peak local workspace arrays at explicit optimization checkpoints; ' ...
    'measured by sum([whos.bytes]) in the local optimization workspace only; ' ...
    'no process-memory measurement is used.'];
memory_stats.main_metric = 'Peak local workspace arrays';
memory_stats.excluded_process_metrics = 'No memory()/WorkingSet/RSS/PrivateMemory queries';
memory_stats.peak_bytes = 0;
memory_stats.peak_mb = 0;
memory_stats.peak_stage = 'not measured';
memory_stats.peak_local_workspace_bytes = 0;
memory_stats.peak_local_workspace_mb = 0;
memory_stats.peak_local_workspace_label = 'not measured';
memory_stats.local_samples = 0;
memory_stats.parameter_optimizer_bytes = 0;
memory_stats.parameter_optimizer_mb = 0;
if measure_opt_memory
    opt_local_memory_monitor('reset');
    opt_local_memory_monitor('start');
end
%% --------------------- A-Net parameters ---------------------
hidden = 32;
theta.W1 = 0.01*randn(hidden, coord_dim); theta.b1 = zeros(hidden,1);
theta.W2 = 0.01*randn(hidden, hidden);    theta.b2 = zeros(hidden,1);
theta.W3 = 0.01*randn(p, hidden);         theta.b3 = zeros(p,1);
theta.Wg1 = 0.01*randn(hidden, coord_dim); theta.bg1 = zeros(hidden,1);
theta.Wg2 = 0.01*randn(p, hidden);         theta.bg2 = zeros(p,1);
theta.c = 0.05;

%% --------------------- Invertible Q: Q = L * Q0 * R ---------------------
theta.L = zeros(p,p);       % strict lower triangular
theta.R = zeros(p,p);       % strict upper triangular
theta.r_log = zeros(p,1);   % R diagonal log

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

if measure_opt_memory
    info_persistent = whos('theta', 'm', 'v', 'lr', 'iter');
    persistent_bytes = sum([info_persistent.bytes]);
    memory_stats.parameter_optimizer_bytes = persistent_bytes;
    memory_stats.parameter_optimizer_mb = persistent_bytes / 1024^2;
    opt_local_memory_monitor('set_state_bytes', 'theta + Adam(m,v)', persistent_bytes);
else
    persistent_bytes = 0;
end

if pStruct.Results.verbose
    fprintf('Mini-batch training: N=%d, batch=%d, steps/epoch=%.1f\n', N, B, N/B);
end

%% --------------------- Warm-up (linear, Q fixed at Q0) ---------------------
if pStruct.Results.verbose, fprintf('Warm-up (linear, fixed Q)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    % Probe only the first warm-up step; tensor shapes are constant.
    measure_this_step = measure_opt_memory && (k == 1);
    if measure_this_step
        opt_local_memory_monitor('arm', sprintf('warm-up iter %d', k));
    end
    [Yb, cb, ~] = next_batch(Y_work, coords, N, B, full_batch, false);
    [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_SUMONE, pStruct.Results.LAMBDA_ENCLOSE, true, N, measure_this_step);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    if measure_this_step
        opt_local_memory_monitor('disarm');
    end
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Warm-up %d/%d, loss=%.6f\n', k, pStruct.Results.WARM_UP, loss);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + nonlinear)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
for k = 1:n_joint
    % Probe only the first joint step; tensor shapes are constant.
    measure_this_step = measure_opt_memory && (k == 1);
    if measure_this_step
        opt_local_memory_monitor('arm', sprintf('joint iter %d', k));
    end
    [Yb, cb, ~] = next_batch(Y_work, coords, N, B, full_batch, false);
    [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, pStruct.Results.LAMBDA_SUMONE, ...
        pStruct.Results.LAMBDA_ENCLOSE, false, N, measure_this_step);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    if measure_this_step
        opt_local_memory_monitor('disarm');
    end
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Joint %d/%d, loss=%.6f, c=%.4f\n', k, n_joint, loss, theta.c);
    end
end

% ---------------- STOP optimization local-workspace memory measurement here ----------------
if measure_opt_memory
    opt_mem_report = opt_local_memory_monitor('stop');
    memory_stats.peak_bytes = opt_mem_report.peak_local_workspace_bytes;
    memory_stats.peak_mb = opt_mem_report.peak_local_workspace_bytes / 1024^2;
    memory_stats.peak_stage = opt_mem_report.peak_local_workspace_label;
    memory_stats.peak_local_workspace_bytes = opt_mem_report.peak_local_workspace_bytes;
    memory_stats.peak_local_workspace_mb = opt_mem_report.peak_local_workspace_bytes / 1024^2;
    memory_stats.peak_local_workspace_label = opt_mem_report.peak_local_workspace_label;
    memory_stats.local_samples = opt_mem_report.local_samples;
    memory_stats.parameter_optimizer_bytes = opt_mem_report.state_bytes;
    memory_stats.parameter_optimizer_mb = opt_mem_report.state_bytes / 1024^2;
    if pStruct.Results.verbose
        fprintf('\n========== OPTIMIZATION PEAK LOCAL WORKSPACE ARRAYS ==========\n');
        fprintf('Peak Memory (Table 3) = %.6f MB\n', memory_stats.peak_mb);
        fprintf('Peak local-workspace checkpoint = %s\n', memory_stats.peak_stage);
        fprintf('Exact theta + Adam state memory = %.6f MB\n', memory_stats.parameter_optimizer_mb);
        fprintf('Local-workspace checkpoints = %d\n', memory_stats.local_samples);
        fprintf(['Definition: Peak Memory equals the maximum sum([whos.bytes]) observed ' ...
            'at explicit optimization checkpoints inside the local MATLAB workspace.\n']);
        fprintf('No process-memory measurement is used.\n');
        fprintf('==============================================================\n\n');
    end
end

%% --------------------- Recover endmembers ---------------------
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M_sub = inv(Q);

% Full-data abundance forward pass in chunks: memory stays O(chunk*p)
% regardless of N (for N >= 1e8 this is also where streaming I/O would go).
CHUNK = min(N, 1048576);   % 2^20
A_eff = zeros(p, N);
for i1 = 1:CHUNK:N
    i2 = min(i1+CHUNK-1, N);
    A_eff(:, i1:i2) = abundance_net_forward_nl(coords(:, i1:i2), theta, false);
end
Sest = A_eff;

if strcmp(pStruct.Results.spherize, 'yes')
    M_sub = M_sub*sqrt(p);
    M_sub = M_sub(1:p-1,:);
    M_est = Up(:,1:p-1)*diag(sqrt(diag(D+lambda_reg*eye(p-1))))*M_sub + repmat(my,1,p);
else
    M_est = Up*M_sub;
end
end

%% ===================== Sub-functions =====================
function [Yb, cb, batch_peak_bytes] = next_batch(Y_work, coords, N, B, full_batch, measure_memory)
%NEXT_BATCH  Uniform random mini-batch (with replacement); full batch if B >= N.
% Retained output batch_peak_bytes for compatibility; not used by the
% revised local-workspace Peak Memory definition.
if full_batch
    Yb = Y_work; cb = coords;
    batch_peak_bytes = 0;
else
    idx = randi(N, 1, B);
    Yb = Y_work(:, idx); cb = coords(:, idx);
    if measure_memory
        info_batch = whos('idx', 'Yb', 'cb');
        batch_peak_bytes = sum([info_batch.bytes]);
    else
        batch_peak_bytes = 0;
    end
end
end

function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)));
end
end

function [A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up)
Z1 = theta.W1*coords + theta.b1; H1 = tanh(Z1);
Z2 = theta.W2*H1 + theta.b2;     H2 = tanh(Z2);
Z3 = theta.W3*H2 + theta.b3;
Z3 = Z3 - max(Z3,[],1); expZ = exp(Z3);
A_base = expZ ./ sum(expZ,1);

Zg1 = theta.Wg1*coords + theta.bg1; Hg1 = tanh(Zg1);
Zg2 = theta.Wg2*Hg1 + theta.bg2;
G = 1./(1+exp(-Zg2));

c = warm_up*0 + (1-warm_up)*theta.c;
A_eff = A_base + c*(G.*(A_base.^2));

cache.Z1=Z1; cache.H1=H1; cache.Z2=Z2; cache.H2=H2; cache.Z3=Z3;
cache.expZ=expZ; cache.coords=coords;
cache.Zg1=Zg1; cache.Hg1=Hg1; cache.Zg2=Zg2; cache.G=G;
cache.A_base=A_base; cache.c=c; cache.warm_up=warm_up;

if opt_local_memory_monitor('is_armed')
    local_info = whos;
    opt_local_memory_monitor('sample_local', 'A-Net forward live set', sum([local_info.bytes]));
end
end

function [grad, local_peak_bytes] = abundance_net_backward_nl(dA_eff, cache, theta, measure_memory)
A_base = cache.A_base; G = cache.G; c = cache.c; warm_up = cache.warm_up;

dA_base = dA_eff + 2*c*G.*A_base.*dA_eff;
dG = c*(A_base.^2).*dA_eff;
dc = sum(sum((G.*(A_base.^2)).*dA_eff));

if warm_up
    grad.Wg1 = zeros(size(theta.Wg1)); grad.bg1 = zeros(size(theta.bg1));
    grad.Wg2 = zeros(size(theta.Wg2)); grad.bg2 = zeros(size(theta.bg2));
    grad.c = 0;
else
    dZg2 = dG.*(G.*(1-G));
    grad.Wg2 = dZg2*cache.Hg1'; grad.bg2 = sum(dZg2,2);
    dHg1 = theta.Wg2'*dZg2;
    dZg1 = dHg1.*(1-tanh(cache.Zg1).^2);
    grad.Wg1 = dZg1*cache.coords'; grad.bg1 = sum(dZg1,2);
    grad.c = dc;
end

A = cache.expZ ./ sum(cache.expZ,1);
dZ3 = A.*(dA_base - sum(A.*dA_base,1));
grad.W3 = dZ3*cache.H2'; grad.b3 = sum(dZ3,2);
dH2 = theta.W3'*dZ3;
dZ2 = dH2.*(1-tanh(cache.Z2).^2);
grad.W2 = dZ2*cache.H1'; grad.b2 = sum(dZ2,2);
dH1 = theta.W2'*dZ2;
dZ1 = dH1.*(1-tanh(cache.Z1).^2);
grad.W1 = dZ1*cache.coords'; grad.b1 = sum(dZ1,2);

if measure_memory && opt_local_memory_monitor('is_armed')
    info_local = whos;
    local_peak_bytes = sum([info_local.bytes]);
    opt_local_memory_monitor('sample_local', 'A-Net backward live set', local_peak_bytes);
else
    local_peak_bytes = 0;
end
end

function [loss, grad, workspace_peak_bytes] = compute_gradients_invflow(theta, Y, coords, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, lambda_enclose, warm_up, N_total, measure_memory)
% Y is a BATCH of Nb columns drawn from the full data set of N_total
% samples. Per-sample SUM penalties are scaled by s = N_total/Nb so that
% all stochastic losses/gradients are unbiased estimates of the original
% full-batch versions (s = 1 recovers them exactly).
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q); % p is small, numerically safe

[A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up);

Nb = size(Y, 2);
s = N_total / Nb;              % unbiased scaling for per-sample SUM penalties

Y_hat = M * A_eff;
diff = Y_hat - Y;
loss_recon = mean(sum(diff.^2,1));         % per-sample MEAN: no rescaling

loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant

if measure_memory && opt_local_memory_monitor('is_armed')
    local_info = whos;
    opt_local_memory_monitor('sample_local', 'reconstruction live set', sum([local_info.bytes]));
end

penalty = min(A_eff,0);
loss_nonneg = s * sum(penalty.^2, 'all');                 % <<< scaled

sum_A = sum(A_eff,1);
loss_sumone = s * sum((sum_A-1).^2, 'all');               % <<< scaled

col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');   % data-free (q_m precomputed)

% --- optional data-enclosure penalty QY >= 0 ---
QY = Q*Y;
pen_enclose = min(QY, 0);
loss_enclose = s * sum(pen_enclose.^2, 'all');            % <<< scaled

if measure_memory && opt_local_memory_monitor('is_armed')
    local_info = whos;
    opt_local_memory_monitor('sample_local', 'enclosure live set', sum([local_info.bytes]));
end

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + lambda_enclose*loss_enclose;

dY_hat = 2*diff/Nb;                        % gradient of the batch MEAN
dM = dY_hat * A_eff';
grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * s * pen_enclose * Y';                % <<< scaled
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

if measure_memory && opt_local_memory_monitor('is_armed')
    local_info = whos;
    opt_local_memory_monitor('sample_local', 'Q-gradient live set', sum([local_info.bytes]));
end

% Map Q-gradients to triangular parameters
grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

% Backprop to abundance network
dA_eff = M' * dY_hat + s * (2*lambda_nonneg*penalty + ...
    2*lambda_sumone*repmat(sum_A-1, p, 1));               % <<< scaled

[grad_net, backward_peak_bytes] = abundance_net_backward_nl(dA_eff, cache, theta, measure_memory);
workspace_peak_bytes = backward_peak_bytes;

grad.W1 = grad_net.W1; grad.b1 = grad_net.b1;
grad.W2 = grad_net.W2; grad.b2 = grad_net.b2;
grad.W3 = grad_net.W3; grad.b3 = grad_net.b3;
grad.Wg1 = grad_net.Wg1; grad.bg1 = grad_net.bg1;
grad.Wg2 = grad_net.Wg2; grad.bg2 = grad_net.bg2;
grad.c = grad_net.c;

if measure_memory && opt_local_memory_monitor('is_armed')
    local_info = whos;
    workspace_peak_bytes = max(workspace_peak_bytes, sum([local_info.bytes]));
    opt_local_memory_monitor('sample_local', 'gradient assembly live set', workspace_peak_bytes);
end
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr)
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*(grad.(f).^2);
    m_hat = m.(f) / (1 - beta1^iter);
    v_hat = v.(f) / (1 - beta2^iter);
    theta.(f) = theta.(f) - lr * m_hat ./ (sqrt(v_hat) + eps);
end
end


function out = opt_local_memory_monitor(action, label, value)
%OPT_LOCAL_MEMORY_MONITOR Track "Peak local workspace arrays" only.
% No process-level memory query is performed.
    persistent S
    if nargin < 2 || isempty(label)
        label = '';
    end
    if nargin < 3
        value = [];
    end

    switch lower(action)
        case 'reset'
            S = [];
            out = [];
        case 'start'
            S = struct();
            S.armed = false;
            S.arm_label = '';
            S.state_bytes = 0;
            S.state_label = '';
            S.peak_local_workspace_bytes = 0;
            S.peak_local_workspace_label = 'not measured';
            S.local_samples = 0;
            out = S;
        case 'arm'
            if isempty(S), out = []; return; end
            S.armed = true;
            S.arm_label = char(label);
            out = [];
        case 'disarm'
            if ~isempty(S)
                S.armed = false;
                S.arm_label = '';
            end
            out = [];
        case 'is_armed'
            out = ~isempty(S) && S.armed;
        case 'set_state_bytes'
            if isempty(S), out = []; return; end
            S.state_bytes = double(value);
            S.state_label = char(label);
            out = [];
        case 'sample_local'
            if isempty(S) || ~S.armed
                out = [];
                return;
            end
            live_bytes = double(value);
            S.local_samples = S.local_samples + 1;
            full_label = compose_local_monitor_label(S, label);
            if live_bytes > S.peak_local_workspace_bytes
                S.peak_local_workspace_bytes = live_bytes;
                S.peak_local_workspace_label = full_label;
            end
            out = live_bytes;
        case 'stop'
            if isempty(S)
                out = struct();
            else
                out = S;
            end
            S = [];
        otherwise
            error('Unknown opt_local_memory_monitor action: %s', action);
    end
end

function label_out = compose_local_monitor_label(S, label_in)
    if isempty(S.arm_label)
        label_out = char(label_in);
    elseif isempty(label_in)
        label_out = S.arm_label;
    else
        label_out = sprintf('%s / %s', S.arm_label, char(label_in));
    end
end
