function [M_est, Sest, Up, my, theta, memory_stats] = deep_mvsa_invflow_memory(Y, p, varargin)
%% DeepMVSA-InvFlow (mini-batch version): Invertible Coupled Q + Nonlinear Attention
% Q = L * Q0 * R, L: unit lower-tri, R: upper-tri with positive diagonal.
% A_eff = A_base + c * G .* (A_base.^2)
%
% ------------------------- MINI-BATCH TRAINING -------------------------
% Each gradient step draws BATCH_SIZE samples uniformly at random (with
% replacement). Per-sample SUM penalties (nonnegativity, sum-to-one,
% enclosure) are rescaled by N/B so that the stochastic losses and
% gradients are UNBIASED estimates of the original full-batch quantities
% -- all LAMBDA_* hyperparameters keep their original meaning and tuned
% values transfer directly. The reconstruction loss is a per-sample MEAN
% and needs no rescaling.
%
%   - Per-step cost:      O(B * (p^2 + p*h))  instead of O(N * p^2)
%   - Parameter memory:   O(p^2 + p*h), independent of N  (unchanged)
%   - Set BATCH_SIZE >= N to recover the original full-batch behavior
%     exactly (no random sampling, scaling factor N/B = 1).
%
% q_m is a fixed 1xp target vector precomputed in ONE pass over the data
% before training; it does not enter the per-iteration cost.
%
% Optional data-enclosure penalty sum(min(Q*Y,0).^2) (LAMBDA_ENCLOSE).
% Default 0 -> identical to the original version (used for Cuprite).
% For synthetic data with i.i.d. abundances, set LAMBDA_ENCLOSE = 10 to
% anchor Q to the data convex hull and prevent the simplex from
% collapsing inward under the volume term.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @isnumeric);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);   % enclosure term, default off
addParameter(pStruct, 'BATCH_SIZE', 4096, @isnumeric);    % <<< NEW: mini-batch size (>=N => full batch)
addParameter(pStruct, 'SEED', [], @isnumeric);            % <<< NEW: optional rng seed for reproducibility
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'MEASURE_OPT_MEMORY', true, @(x) islogical(x) || isnumeric(x));
parse(pStruct, varargin{:});

if ~isempty(pStruct.Results.SEED)
    rng(pStruct.Results.SEED, 'twister');
end

[L, N] = size(Y);
B = min(pStruct.Results.BATCH_SIZE, N);
full_batch = (B >= N);

%% --------------------- Preprocessing ---------------------
my = mean(Y,2); Yc = Y - repmat(my,1,N);
[Up, D] = svds(Yc*Yc'/N, p-1);
Yp = Up*Up'*Yc + repmat(my,1,N);
my_ortho = my - Up*Up'*my;
Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
Y_proj = Up'*Yp;

if strcmp(pStruct.Results.spherize, 'yes')
    lambda_reg = 1e-10;
    C = diag(1./sqrt(diag(D+lambda_reg*eye(p-1))));
    Ys = C*Up(:,1:p-1)'*(Yp-repmat(my,1,N));
    Ys(p,:) = 1; Ys = Ys/sqrt(p);
    Y_work = Ys;
else
    Y_work = Y_proj; lambda_reg = 0;
end

%% --------------------- Initialization ---------------------
if isempty(pStruct.Results.M0)
    M0 = VCA(Y_work, 'Endmembers', p, 'verbose', 'off');
else
    M0 = pStruct.Results.M0;
    if strcmp(pStruct.Results.spherize, 'yes')
        M0 = M0 - repmat(my,1,p);
        M0 = C*Up(:,1:p-1)'*M0;
        M0(p,:) = 1; M0 = M0/sqrt(p);
    else
        M0 = Up'*M0;
    end
end
Q0 = inv(M0);
qm = ones(1,N)*Y_work'*inv(Y_work*Y_work');   % one pass, O(N*p^2), fixed target thereafter

%% --------------------- Spatial coordinates ---------------------
H = round(sqrt(N)); W = round(N/H);
if H*W == N
    [gx, gy] = meshgrid(linspace(-1,1,W), linspace(-1,1,H));
    coords = [gx(:)'; gy(:)'];
else
    coords = linspace(-1,1,N); coords = coords(:)';
end
coord_dim = size(coords,1);

%% --------------------- Optimization-only memory tracker ---------------------
% TABLE-3 MEMORY DEFINITION:
%   Measure ONLY memory allocated for the optimization stage itself.
%   The following objects already exist before optimization and are EXCLUDED:
%     Y, Y_work, Y_proj, Up, D, my, M0, Q0, qm, coords, and all preprocessing data.
%   The measured peak includes:
%     (1) learnable parameters theta,
%     (2) Adam first/second moments m and v,
%     (3) mini-batch copies created during training,
%     (4) gradients, forward/backward activations, and temporary tensors used
%         by compute_gradients_invflow / Adam update.
%   This is NOT process RSS / WorkingSet / PrivateMemory and performs no
%   operating-system process-memory query.  Because tensor shapes are fixed,
%   memory is probed only on the first warm-up and first joint step to avoid
%   contaminating the reported runtime with per-iteration instrumentation.
%   The tracker stops immediately
%   after the joint-optimization loop, so endmember recovery and the final
%   full-data abundance materialization are also excluded.
measure_opt_memory = logical(pStruct.Results.MEASURE_OPT_MEMORY);
memory_stats = struct();
memory_stats.definition = ['Optimization-only MATLAB variable memory: parameters + Adam states + ' ...
    'mini-batch copies + optimization temporaries; excludes all arrays existing before optimization.'];
memory_stats.excluded_preexisting = ...
    'Y/Y_work/Y_proj/Up/D/my/M0/Q0/qm/coords and preprocessing allocations';
memory_stats.peak_bytes = 0;
memory_stats.peak_mb = 0;
memory_stats.peak_stage = 'not measured';
memory_stats.parameter_optimizer_bytes = 0;
memory_stats.parameter_optimizer_mb = 0;
opt_peak_bytes = 0;
opt_peak_stage = 'not measured';

%% --------------------- A-Net parameters ---------------------
hidden = 32;
theta.W1 = 0.01*randn(hidden, coord_dim); theta.b1 = zeros(hidden,1);
theta.W2 = 0.01*randn(hidden, hidden);    theta.b2 = zeros(hidden,1);
theta.W3 = 0.01*randn(p, hidden);         theta.b3 = zeros(p,1);
theta.Wg1 = 0.01*randn(hidden, coord_dim); theta.bg1 = zeros(hidden,1);
theta.Wg2 = 0.01*randn(p, hidden);         theta.bg2 = zeros(p,1);
theta.c = 0.05;

%% --------------------- Invertible Q: Q = L * Q0 * R ---------------------
theta.L = zeros(p,p);       % strict lower triangular
theta.R = zeros(p,p);       % strict upper triangular
theta.r_log = zeros(p,1);   % R diagonal log

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

% The optimization-stage baseline is ZERO by definition.  theta/m/v are
% created after the boundary and therefore ARE counted; all earlier arrays
% are excluded rather than subtracted from process memory.
if measure_opt_memory
    info_persistent = whos('theta', 'm', 'v', 'lr', 'iter');
    persistent_bytes = sum([info_persistent.bytes]);
    memory_stats.parameter_optimizer_bytes = persistent_bytes;
    memory_stats.parameter_optimizer_mb = persistent_bytes / 1024^2;
    opt_peak_bytes = persistent_bytes;
    opt_peak_stage = 'parameters + Adam states';
else
    persistent_bytes = 0;
end

if pStruct.Results.verbose
    fprintf('Mini-batch training: N=%d, batch=%d, steps/epoch=%.1f\n', N, B, N/B);
end

%% --------------------- Warm-up (linear, Q fixed at Q0) ---------------------
if pStruct.Results.verbose, fprintf('Warm-up (linear, fixed Q)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    % Tensor shapes are constant across iterations.  Probe memory only on
    % the first warm-up step so runtime is not distorted by repeated whos().
    measure_this_step = measure_opt_memory && (k == 1);
    [Yb, cb, batch_peak_bytes] = next_batch(Y_work, coords, N, B, full_batch, measure_this_step);
    [loss, grad, grad_workspace_peak_bytes] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_SUMONE, pStruct.Results.LAMBDA_ENCLOSE, true, N, measure_this_step);

    if measure_this_step
        % Peak while forward/backward workspace is alive.
        persistent_now = struct_memory_bytes(theta) + struct_memory_bytes(m) + ...
            struct_memory_bytes(v) + scalar_memory_bytes(lr) + scalar_memory_bytes(iter);
        candidate_compute = persistent_now + batch_peak_bytes + grad_workspace_peak_bytes;
        if candidate_compute > opt_peak_bytes
            opt_peak_bytes = candidate_compute;
            opt_peak_stage = sprintf('warm-up gradient step %d', k);
        end

        % After compute_gradients returns, grad is live while Adam creates
        % m_hat/v_hat and expression temporaries.  Count a conservative
        % field-wise Adam temporary peak without any process-memory query.
        grad_bytes = struct_memory_bytes(grad);
        adam_temp_bytes = adam_update_temp_peak_bytes(theta);
        candidate_adam = persistent_now + batch_peak_bytes + grad_bytes + adam_temp_bytes;
        if candidate_adam > opt_peak_bytes
            opt_peak_bytes = candidate_adam;
            opt_peak_stage = sprintf('warm-up Adam step %d', k);
        end
    end

    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Warm-up %d/%d, loss=%.6f\n', k, pStruct.Results.WARM_UP, loss);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + nonlinear)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
for k = 1:n_joint
    % Probe the first joint step; all later joint steps have identical tensor
    % shapes, so their optimization-memory footprint is the same.
    measure_this_step = measure_opt_memory && (k == 1);
    [Yb, cb, batch_peak_bytes] = next_batch(Y_work, coords, N, B, full_batch, measure_this_step);
    [loss, grad, grad_workspace_peak_bytes] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, pStruct.Results.LAMBDA_SUMONE, ...
        pStruct.Results.LAMBDA_ENCLOSE, false, N, measure_this_step);

    if measure_this_step
        persistent_now = struct_memory_bytes(theta) + struct_memory_bytes(m) + ...
            struct_memory_bytes(v) + scalar_memory_bytes(lr) + scalar_memory_bytes(iter);
        candidate_compute = persistent_now + batch_peak_bytes + grad_workspace_peak_bytes;
        if candidate_compute > opt_peak_bytes
            opt_peak_bytes = candidate_compute;
            opt_peak_stage = sprintf('joint gradient step %d', k);
        end

        grad_bytes = struct_memory_bytes(grad);
        adam_temp_bytes = adam_update_temp_peak_bytes(theta);
        candidate_adam = persistent_now + batch_peak_bytes + grad_bytes + adam_temp_bytes;
        if candidate_adam > opt_peak_bytes
            opt_peak_bytes = candidate_adam;
            opt_peak_stage = sprintf('joint Adam step %d', k);
        end
    end

    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Joint %d/%d, loss=%.6f, c=%.4f\n', k, n_joint, loss, theta.c);
    end
end

% ---------------- STOP optimization-only memory measurement here ----------------
if measure_opt_memory
    memory_stats.peak_bytes = opt_peak_bytes;
    memory_stats.peak_mb = opt_peak_bytes / 1024^2;
    memory_stats.peak_stage = opt_peak_stage;
    if pStruct.Results.verbose
        fprintf('\n========== OPTIMIZATION-ONLY PEAK MEMORY ==========\n');
        fprintf('Peak Memory = %.6f MB\n', memory_stats.peak_mb);
        fprintf('Parameter + Adam state memory = %.6f MB\n', memory_stats.parameter_optimizer_mb);
        fprintf('Peak stage = %s\n', memory_stats.peak_stage);
        fprintf(['Definition: sum of MATLAB variable bytes allocated by optimization only; ' ...
            'pre-existing preprocessing/input arrays are excluded.\n']);
        fprintf('No process RSS/WorkingSet/PrivateMemory measurement is used.\n');
        fprintf('===================================================\n\n');
    end
end

%% --------------------- Recover endmembers ---------------------
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M_sub = inv(Q);

% Full-data abundance forward pass in chunks: memory stays O(chunk*p)
% regardless of N (for N >= 1e8 this is also where streaming I/O would go).
CHUNK = min(N, 1048576);   % 2^20
A_eff = zeros(p, N);
for i1 = 1:CHUNK:N
    i2 = min(i1+CHUNK-1, N);
    A_eff(:, i1:i2) = abundance_net_forward_nl(coords(:, i1:i2), theta, false);
end
Sest = A_eff;

if strcmp(pStruct.Results.spherize, 'yes')
    M_sub = M_sub*sqrt(p);
    M_sub = M_sub(1:p-1,:);
    M_est = Up(:,1:p-1)*diag(sqrt(diag(D+lambda_reg*eye(p-1))))*M_sub + repmat(my,1,p);
else
    M_est = Up*M_sub;
end
end

%% ===================== Sub-functions =====================
function [Yb, cb, batch_peak_bytes] = next_batch(Y_work, coords, N, B, full_batch, measure_memory)
%NEXT_BATCH  Uniform random mini-batch (with replacement); full batch if B >= N.
% batch_peak_bytes counts only NEW allocations made for batch selection.
% The pre-existing full arrays Y_work and coords are never counted.
if full_batch
    Yb = Y_work; cb = coords;
    % Copy-on-write aliases: no new batch payload is allocated here.
    batch_peak_bytes = 0;
else
    idx = randi(N, 1, B);
    Yb = Y_work(:, idx); cb = coords(:, idx);
    if measure_memory
        info_batch = whos('idx', 'Yb', 'cb');
        batch_peak_bytes = sum([info_batch.bytes]);
    else
        batch_peak_bytes = 0;
    end
end
end

function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)));
end
end

function [A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up)
Z1 = theta.W1*coords + theta.b1; H1 = tanh(Z1);
Z2 = theta.W2*H1 + theta.b2;     H2 = tanh(Z2);
Z3 = theta.W3*H2 + theta.b3;
Z3 = Z3 - max(Z3,[],1); expZ = exp(Z3);
A_base = expZ ./ sum(expZ,1);

Zg1 = theta.Wg1*coords + theta.bg1; Hg1 = tanh(Zg1);
Zg2 = theta.Wg2*Hg1 + theta.bg2;
G = 1./(1+exp(-Zg2));

c = warm_up*0 + (1-warm_up)*theta.c;
A_eff = A_base + c*(G.*(A_base.^2));

cache.Z1=Z1; cache.H1=H1; cache.Z2=Z2; cache.H2=H2; cache.Z3=Z3;
cache.expZ=expZ; cache.coords=coords;
cache.Zg1=Zg1; cache.Hg1=Hg1; cache.Zg2=Zg2; cache.G=G;
cache.A_base=A_base; cache.c=c; cache.warm_up=warm_up;
end

function [grad, local_peak_bytes] = abundance_net_backward_nl(dA_eff, cache, theta, measure_memory)
A_base = cache.A_base; G = cache.G; c = cache.c; warm_up = cache.warm_up;

dA_base = dA_eff + 2*c*G.*A_base.*dA_eff;
dG = c*(A_base.^2).*dA_eff;
dc = sum(sum((G.*(A_base.^2)).*dA_eff));

if warm_up
    grad.Wg1 = zeros(size(theta.Wg1)); grad.bg1 = zeros(size(theta.bg1));
    grad.Wg2 = zeros(size(theta.Wg2)); grad.bg2 = zeros(size(theta.bg2));
    grad.c = 0;
else
    dZg2 = dG.*(G.*(1-G));
    grad.Wg2 = dZg2*cache.Hg1'; grad.bg2 = sum(dZg2,2);
    dHg1 = theta.Wg2'*dZg2;
    dZg1 = dHg1.*(1-tanh(cache.Zg1).^2);
    grad.Wg1 = dZg1*cache.coords'; grad.bg1 = sum(dZg1,2);
    grad.c = dc;
end

A = cache.expZ ./ sum(cache.expZ,1);
dZ3 = A.*(dA_base - sum(A.*dA_base,1));
grad.W3 = dZ3*cache.H2'; grad.b3 = sum(dZ3,2);
dH2 = theta.W3'*dZ3;
dZ2 = dH2.*(1-tanh(cache.Z2).^2);
grad.W2 = dZ2*cache.H1'; grad.b2 = sum(dZ2,2);
dH1 = theta.W2'*dZ2;
dZ1 = dH1.*(1-tanh(cache.Z1).^2);
grad.W1 = dZ1*cache.coords'; grad.b1 = sum(dZ1,2);

% Count only variables created inside this backward function.  Inputs
% dA_eff/cache/theta existed in the caller and are therefore excluded.
if measure_memory
    info_local = whos;
    exclude_names = {'dA_eff','cache','theta','measure_memory','local_peak_bytes', ...
        'info_local','exclude_names'};
    local_peak_bytes = sum_whos_excluding(info_local, exclude_names);
else
    local_peak_bytes = 0;
end
end

function [loss, grad, workspace_peak_bytes] = compute_gradients_invflow(theta, Y, coords, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, lambda_enclose, warm_up, N_total, measure_memory)
% Y is a BATCH of Nb columns drawn from the full data set of N_total
% samples. Per-sample SUM penalties are scaled by s = N_total/Nb so that
% all stochastic losses/gradients are unbiased estimates of the original
% full-batch versions (s = 1 recovers them exactly).
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q); % p is small, numerically safe

[A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up);

Nb = size(Y, 2);
s = N_total / Nb;              % unbiased scaling for per-sample SUM penalties

Y_hat = M * A_eff;
diff = Y_hat - Y;
loss_recon = mean(sum(diff.^2,1));         % per-sample MEAN: no rescaling

loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant

penalty = min(A_eff,0);
loss_nonneg = s * sum(penalty.^2, 'all');                 % <<< scaled

sum_A = sum(A_eff,1);
loss_sumone = s * sum((sum_A-1).^2, 'all');               % <<< scaled

col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');   % data-free (q_m precomputed)

% --- optional data-enclosure penalty QY >= 0 ---
QY = Q*Y;
pen_enclose = min(QY, 0);
loss_enclose = s * sum(pen_enclose.^2, 'all');            % <<< scaled

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + lambda_enclose*loss_enclose;

dY_hat = 2*diff/Nb;                        % gradient of the batch MEAN
dM = dY_hat * A_eff';
grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * s * pen_enclose * Y';                % <<< scaled
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

% Map Q-gradients to triangular parameters
grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

% Backprop to abundance network
dA_eff = M' * dY_hat + s * (2*lambda_nonneg*penalty + ...
    2*lambda_sumone*repmat(sum_A-1, p, 1));               % <<< scaled

% Memory just before backpropagation: count only tensors allocated inside
% this function.  Input arguments (theta, Y batch, coords batch, Q0, qm,
% scalar hyperparameters) are excluded.  cache is handled separately so
% its aliased A_base/G/coords fields are not double counted.
if measure_memory
    info_preback = whos;
    exclude_preback = {'theta','Y','coords','Q0','qm','p','lambda_vol', ...
        'lambda_nonneg','lambda_eq','lambda_sumone','lambda_enclose','warm_up', ...
        'N_total','measure_memory','cache','info_preback','exclude_preback', ...
        'workspace_peak_bytes'};
    preback_bytes = sum_whos_excluding(info_preback, exclude_preback) + cache_unique_bytes(cache);
else
    preback_bytes = 0;
end

[grad_net, backward_peak_bytes] = abundance_net_backward_nl(dA_eff, cache, theta, measure_memory);
workspace_peak_bytes = preback_bytes + backward_peak_bytes;

grad.W1 = grad_net.W1; grad.b1 = grad_net.b1;
grad.W2 = grad_net.W2; grad.b2 = grad_net.b2;
grad.W3 = grad_net.W3; grad.b3 = grad_net.b3;
grad.Wg1 = grad_net.Wg1; grad.bg1 = grad_net.bg1;
grad.Wg2 = grad_net.Wg2; grad.bg2 = grad_net.bg2;
grad.c = grad_net.c;

% Also evaluate the live workspace after backprop returns.  grad_net and
% grad share payloads by MATLAB copy-on-write, so grad_net is excluded to
% avoid counting the same gradient arrays twice.
if measure_memory
    info_end = whos;
    exclude_end = {'theta','Y','coords','Q0','qm','p','lambda_vol', ...
        'lambda_nonneg','lambda_eq','lambda_sumone','lambda_enclose','warm_up', ...
        'N_total','measure_memory','cache','grad_net','info_preback','exclude_preback', ...
        'preback_bytes','backward_peak_bytes','workspace_peak_bytes', ...
        'info_end','exclude_end'};
    end_bytes = sum_whos_excluding(info_end, exclude_end) + cache_unique_bytes(cache);
    workspace_peak_bytes = max(workspace_peak_bytes, end_bytes);
end
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr)
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*(grad.(f).^2);
    m_hat = m.(f) / (1 - beta1^iter);
    v_hat = v.(f) / (1 - beta2^iter);
    theta.(f) = theta.(f) - lr * m_hat ./ (sqrt(v_hat) + eps);
end
end

function bytes = struct_memory_bytes(s)
%STRUCT_MEMORY_BYTES Logical MATLAB bytes occupied by a structure payload.
info = whos('s');
bytes = info.bytes;
end

function bytes = scalar_memory_bytes(x)
%SCALAR_MEMORY_BYTES Logical MATLAB bytes for a scalar/small numeric value.
info = whos('x');
bytes = info.bytes;
end

function bytes = adam_update_temp_peak_bytes(theta)
%ADAM_UPDATE_TEMP_PEAK_BYTES Conservative temporary-memory peak for one
% field update.  m_hat and v_hat coexist, and the element-wise update creates
% approximately two additional field-sized temporaries.  Only temporary
% arrays are counted here; theta/m/v/grad are counted by the caller.
fields = fieldnames(theta);
max_field_bytes = 0;
for ii = 1:numel(fields)
    tmp = theta.(fields{ii}); %#ok<NASGU>
    info = whos('tmp');
    max_field_bytes = max(max_field_bytes, info.bytes);
end
bytes = 4 * max_field_bytes;
end

function bytes = cache_unique_bytes(cache)
%CACHE_UNIQUE_BYTES Count unique forward activations retained for backward.
% cache.coords aliases the input batch and is excluded; cache.A_base and
% cache.G alias the separately returned A_base/G arrays and are also excluded.
fields = {'Z1','H1','Z2','H2','Z3','expZ','Zg1','Hg1','Zg2'};
bytes = 0;
for ii = 1:numel(fields)
    tmp = cache.(fields{ii}); %#ok<NASGU>
    info = whos('tmp');
    bytes = bytes + info.bytes;
end
end

function bytes = sum_whos_excluding(info, exclude_names)
%SUM_WHOS_EXCLUDING Sum whos().bytes except explicitly excluded variables.
bytes = 0;
for ii = 1:numel(info)
    if ~ismember(info(ii).name, exclude_names)
        bytes = bytes + info(ii).bytes;
    end
end
end
