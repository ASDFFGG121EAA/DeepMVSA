%% demo_deepmvsa_cuprite_table3_10runs_no_plot
% DeepMVSA-InvFlow on AVIRIS Cuprite real data.
%
% Table 3 protocol:
%   1) Run DeepMVSA independently 10 times.
%   2) For each run compute:
%        - Runtime
%        - Peak Memory (Peak local workspace arrays)
%        - Vertex matching error (VME)
%        - Reconstruction RMSE
%   3) Report the arithmetic mean of the four metrics over 10 runs.
%
% No plotting is performed in this script.

clear;

%% ===================== User parameters =====================
N_RUNS = 20;

MM_ITERS = 1500;
WARM_UP  = 400;
LR = 5e-4;
LAMBDA_VOL = 0.01;
LAMBDA_NONNEG = 3;
LAMBDA_EQ = 100;
LAMBDA_SUMONE = 2;

% Use a different but reproducible random seed for each independent run.
BASE_SEED = 1;

%% ===================== Load Cuprite data =====================
load cuprite_ref.mat

Y = x;
band_initial = 5;
Y = Y(band_initial:end-1, :);
BANDS = BANDS(band_initial:end-1); %#ok<NASGU>
clear x;

[L, np] = size(Y);

%% ===================== HySime: determine number of endmembers =====================
% This preprocessing is deterministic and is performed once.
% Runtime below follows the previous script and times only the DeepMVSA model call.
[w, Rw] = estNoise(Y);
[kf, ~, ~, ~] = hysime(Y, w, Rw);
clear w Rw;

p = kf;

fprintf('\n===============================================================\n');
fprintf('Cuprite Table 3 experiment: DeepMVSA, %d independent runs\n', N_RUNS);
fprintf('Pixels = %d | Bands = %d | Endmembers = %d\n', np, L, p);
fprintf('===============================================================\n');

%% ===================== Load USGS library once =====================
if ~exist('USGU_sublibrary.mat', 'file')
    error('USGU_sublibrary.mat not found. VME cannot be computed.');
end

load USGU_sublibrary.mat
aux_lib = Areal(band_initial:end-1, :);

if size(aux_lib, 1) ~= L
    error('USGS library band count (%d) does not match Cuprite band count (%d).', ...
        size(aux_lib, 1), L);
end

[~, n_sig] = size(aux_lib);

% ||m||_2 for every USGS reference signature.  This is fixed for all runs.
ref_norms = sqrt(sum(aux_lib.^2, 1));
ref_norms = max(ref_norms, eps);

%% ===================== Storage for 10 runs =====================
runtime_all     = zeros(N_RUNS, 1);
peak_memory_all = zeros(N_RUNS, 1);
vme_all         = zeros(N_RUNS, 1);
rmse_all        = zeros(N_RUNS, 1);

%% ===================== Ten independent runs =====================
for run_idx = 1:N_RUNS

    fprintf('\n---------------- Run %d / %d ----------------\n', run_idx, N_RUNS);

    current_seed = BASE_SEED + run_idx - 1;

    %% -------- 1. DeepMVSA runtime + peak local workspace memory --------
    model_tic = tic;

    % Sest_model is returned by the model but is NOT used for reconstruction RMSE.
    [M_est, Sest_model, ~, ~, ~, memory_stats] = ...
        deep_mvsa_invflow_peaklocal_table3(Y, p, ...
        'spherize', 'yes', ...
        'verbose', 0, ...
        'MM_ITERS', MM_ITERS, ...
        'WARM_UP', WARM_UP, ...
        'LR', LR, ...
        'LAMBDA_VOL', LAMBDA_VOL, ...
        'LAMBDA_NONNEG', LAMBDA_NONNEG, ...
        'LAMBDA_EQ', LAMBDA_EQ, ...
        'LAMBDA_SUMONE', LAMBDA_SUMONE, ...
        'SEED', current_seed, ...
        'MEASURE_OPT_MEMORY', true);

    runtime_all(run_idx) = toc(model_tic);

    % Main Table-3 memory metric:
    % maximum "Peak local workspace arrays" measured inside model optimization.
    peak_memory_all(run_idx) = memory_stats.peak_mb;

    % Explicitly discard the model-returned abundance because Table-3
    % reconstruction RMSE uses a common SUNSAL abundance refit instead.
    clear Sest_model;

    %% -------- 2. Reconstruction RMSE --------
    % Refit abundance from the estimated endmembers using the same solver.
    % The model-returned abundance is not used.
    Xdeep = sunsal_mod(M_est, Y, ...
        'POSITIVITY', 0, ...
        'VERBOSE', 'no', ...
        'ADDONE', 'yes', ...
        'lambda', 0, ...
        'AL_ITERS', 1000, ...
        'TOL', 1e-8);

    Y_recon = M_est * Xdeep;

    rmse_all(run_idx) = sqrt( ...
        sum((Y_recon - Y).^2, 'all') / numel(Y));

    clear Y_recon Xdeep;

    %% -------- 3. Vertex matching error (VME) --------
    % Formula:
    %
    %   VME = 1/(K+1) * sum_k min_{m in L}
    %         ||m_hat_k - m||_2 / ||m||_2
    %
    % Each estimated endmember is matched independently.
    % Duplicate USGS matches are allowed.
    % No amplitude rescaling is applied.

    vme_each = zeros(1, p);

    for k = 1:p
        end_sig = M_est(:, k);

        % Relative Euclidean error against every USGS library signature.
        diffs = aux_lib - end_sig;
        rel_errors = sqrt(sum(diffs.^2, 1)) ./ ref_norms;

        vme_each(k) = min(rel_errors);
    end

    vme = mean(vme_each);
    vme_all(run_idx) = vme;

    %% -------- Print this run --------
    fprintf('Runtime                  : %.6f s\n', runtime_all(run_idx));
    fprintf('Peak Memory              : %.6f MB\n', peak_memory_all(run_idx));
    fprintf('Vertex matching error    : %.10f\n', vme_all(run_idx));
    fprintf('Reconstruction RMSE      : %.10f\n', rmse_all(run_idx));

    % Avoid carrying run-specific arrays into the next replication.
    clear M_est memory_stats vme_each vme diffs rel_errors end_sig;
end

%% ===================== Mean and standard deviation over 10 runs =====================
% MATLAB std(x,0) uses the sample standard deviation:
%   sqrt( sum((x-mean(x)).^2) / (N_RUNS-1) )
% This is the conventional SD reported for repeated independent experiments.
mean_runtime     = mean(runtime_all);
mean_peak_memory = mean(peak_memory_all);
mean_vme         = mean(vme_all);
mean_rmse        = mean(rmse_all);

std_runtime      = std(runtime_all, 0);
std_peak_memory  = std(peak_memory_all, 0);
std_vme          = std(vme_all, 0);
std_rmse         = std(rmse_all, 0);

%% ===================== Table 3 result =====================
table3_metrics = struct();
table3_metrics.Method = 'DeepMVSA';
table3_metrics.NumRuns = N_RUNS;

% Store all 10 values for traceability.
table3_metrics.Runtime_s_runs = runtime_all;
table3_metrics.PeakMemory_MB_runs = peak_memory_all;
table3_metrics.VME_runs = vme_all;
table3_metrics.Reconstruction_RMSE_runs = rmse_all;

% Values to place in Table 3: mean and sample standard deviation over 10 runs.
table3_metrics.Runtime_s = mean_runtime;
table3_metrics.Runtime_s_SD = std_runtime;

table3_metrics.PeakMemory_MB = mean_peak_memory;
table3_metrics.PeakMemory_MB_SD = std_peak_memory;

table3_metrics.VME = mean_vme;
table3_metrics.VME_SD = std_vme;

table3_metrics.Reconstruction_RMSE = mean_rmse;
table3_metrics.Reconstruction_RMSE_SD = std_rmse;

fprintf('\n=======================================================================\n');
fprintf('TABLE 3 METRICS -- DeepMVSA (MEAN +/- SD OF %d RUNS)\n', N_RUNS);
fprintf('-----------------------------------------------------------------------\n');
fprintf('Runtime                    : %.6f +/- %.6f s\n', ...
    table3_metrics.Runtime_s, table3_metrics.Runtime_s_SD);
fprintf('Peak Memory                : %.6f +/- %.6f MB\n', ...
    table3_metrics.PeakMemory_MB, table3_metrics.PeakMemory_MB_SD);
fprintf('Vertex matching error (VME): %.10f +/- %.10f\n', ...
    table3_metrics.VME, table3_metrics.VME_SD);
fprintf('Reconstruction RMSE        : %.10f +/- %.10f\n', ...
    table3_metrics.Reconstruction_RMSE, table3_metrics.Reconstruction_RMSE_SD);
fprintf('=======================================================================\n');
fprintf(['Peak Memory definition: mean of the per-run peak local workspace arrays; ' ...
    'each per-run peak is measured by sum([whos.bytes]) at explicit optimization checkpoints; ' ...
    'no process-memory measurement is used.\n']);
