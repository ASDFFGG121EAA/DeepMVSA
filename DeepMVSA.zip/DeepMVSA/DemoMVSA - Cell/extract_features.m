function feat = extract_features(Q, Y, qm, p, N, net)
M = inv(Q);
q = Q(:);
g = -M(:);

S = Q * Y;
viol = max(-S, 0);

mean_viol = mean(viol, 2);
max_viol  = max(viol, [], 2);
sum_viol  = sum(viol(:));

obj_val = -log(abs(det(Q)) + eps);
eq_viol = norm(sum(Q,1)' - qm);

q         = normalize_vec(q);
g         = normalize_vec(g);
mean_viol = normalize_vec(mean_viol);
max_viol  = normalize_vec(max_viol);
sum_viol  = sum_viol / (abs(sum_viol) + 1);
obj_val   = obj_val / (abs(obj_val) + 10);
eq_viol   = eq_viol / (eq_viol + 1);

feat = [q(:); g(:); mean_viol(:); max_viol(:); sum_viol(:); ...
        obj_val(:); eq_viol(:)];
end

function v = normalize_vec(v)
v = v / (norm(v) + 1e-8);
end