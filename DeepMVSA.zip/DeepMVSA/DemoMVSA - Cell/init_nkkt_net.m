function net = init_nkkt_net(p)
feat_dim = 2*p^2 + 2*p + 3;
h1 = 512;
h2 = 256;
out_dim = p^2;

rng(42);
net.W1 = randn(h1, feat_dim) * sqrt(2/feat_dim);
net.b1 = zeros(h1, 1);
net.W2 = randn(h2, h1) * sqrt(2/h1);
net.b2 = zeros(h2, 1);
net.W3 = randn(out_dim, h2) * sqrt(2/h2);
net.b3 = zeros(out_dim, 1);

% Adam
net.mW1 = zeros(size(net.W1)); net.vW1 = zeros(size(net.W1));
net.mb1 = zeros(size(net.b1)); net.vb1 = zeros(size(net.b1));
net.mW2 = zeros(size(net.W2)); net.vW2 = zeros(size(net.W2));
net.mb2 = zeros(size(net.b2)); net.vb2 = zeros(size(net.b2));
net.mW3 = zeros(size(net.W3)); net.vW3 = zeros(size(net.W3));
net.mb3 = zeros(size(net.b3)); net.vb3 = zeros(size(net.b3));
net.t = 0;
end
