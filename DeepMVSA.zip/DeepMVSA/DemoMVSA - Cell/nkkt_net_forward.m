function [y, cache] = nkkt_net_forward(x, net)
if size(x, 2) > 1, x = x(:); end

z1 = net.W1 * x + net.b1;
h1 = max(z1, 0);
z2 = net.W2 * h1 + net.b2;
h2 = max(z2, 0);
z3 = net.W3 * h2 + net.b3;
y = z3;

if nargout > 1
    cache.z1 = z1; cache.h1 = h1;
    cache.z2 = z2; cache.h2 = h2;
    cache.x = x;
end
end