function data = collect_mvsa_trajectories(p, num_scenes, L, varargin)
% COLLECT_MVSA_TRAJECTORIES  Use REAL MVSA (quadProg1) on N=10000 scenes.
% Records Q at every accepted stage. Total time ~1-2 minutes for 50 scenes.

ip = inputParser;
addParameter(ip, 'SNR_min', 20);
addParameter(ip, 'SNR_max', 90);
addParameter(ip, 'max_purity', 0.8);
addParameter(ip, 'N', 100*100);     % SAME as test size
addParameter(ip, 'SHAPE_PARAMETER', 1);
parse(ip, varargin{:});

all_traj = cell(num_scenes, 1);
scene_count = 0;

fprintf('Collecting real MVSA trajectories (N=%d, p=%d)...\n', ip.Results.N, p);
tic;

for s = 1:num_scenes
    % Generate scene
    M_full = rand(L, p);
    SNR = ip.Results.SNR_min + (ip.Results.SNR_max - ip.Results.SNR_min)*rand();
    
    [Y_noisy, ~, ~] = spectMixGen(M_full, ip.Results.N, ...
        'Source_pdf', 'Diri_id', 'pdf_pars', ip.Results.SHAPE_PARAMETER, ...
        'max_purity', ip.Results.max_purity*ones(1,p), ...
        'snr', SNR, 'noise_shape', 'uniform');
    
    % Preprocess exactly as du_mvsa / mvsa
    [L2, N2] = size(Y_noisy);
    my = mean(Y_noisy, 2);
    Yc = Y_noisy - repmat(my, 1, N2);
    [Up, D] = svds(Yc*Yc'/N2, p-1);
    my_ortho = my - Up*Up'*my;
    Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
    
    Y_proj = Up' * Y_noisy;
    
    lambda = 1e-10;
    C = diag(1./sqrt(diag(D + lambda*eye(p-1))));
    Y_spher = C * Up(:, 1:p-1)' * (Up*Y_proj - repmat(my, 1, N2));
    Y_spher(p, :) = 1;
    Y_spher = Y_spher / sqrt(p);
    
    qm = sum((Y_spher*Y_spher' + 1e-6*eye(p)) \ Y_spher, 2);
    
    % Run real MVSA and record trajectory
    try
        traj = mvsa_record_real(Y_spher, p, qm);
    catch
        continue;
    end
    
    if length(traj) >= 2
        scene_count = scene_count + 1;
        all_traj{scene_count} = traj;
    end
    
    if mod(s, 10) == 0
        fprintf('  Finished %d/%d scenes (valid %d), elapsed %.1fs\n', s, num_scenes, scene_count, toc);
    end
end

all_traj = all_traj(1:scene_count);
fprintf('Valid scenes: %d. Building balanced dataset...\n', scene_count);

% Stage-balanced sampling: equal samples from early, middle, late stages
data = [];
count = 0;
samples_per_stage = 500;  % target per stage bin

for s = 1:scene_count
    traj = all_traj{s};
    K = length(traj);
    if K < 2, continue; end
    
    % Bins: early (1:K/3), middle (K/3:2K/3), late (2K/3:K)
    bins = {[1, floor(K/3)], [floor(K/3), floor(2*K/3)], [floor(2*K/3), K]};
    
    for b = 1:3
        range = bins{b};
        for k = range(1):range(2)-1
            if k >= K, break; end
            count = count + 1;
            data(count).feat = extract_features(traj(k).Q, Y_spher, qm, p, N2, []);
            data(count).step = traj(k+1).Q(:) - traj(k).Q(:);
            data(count).stage = k;
            data(count).total_stages = K;
        end
    end
end

fprintf('Total state-step pairs: %d\n', count);
end