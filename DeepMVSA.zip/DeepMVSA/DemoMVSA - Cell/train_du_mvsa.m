function train_du_mvsa(p, out_name, traj_data)
if nargin < 3 || isempty(traj_data)
    error('Please provide trajectory data');
end
num_samples = length(traj_data);
fprintf('Training DU-MVSA: p=%d, samples=%d\n', p, num_samples);

epochs = 200; batch_size = 128; lr = 1e-3;
beta1 = 0.9; beta2 = 0.999; eps_adam = 1e-8;
grad_clip = 1.0; val_split = 0.1;

% Deeper network: 4 layers
feat_dim = 2*p^2 + 2*p + 3;
h1 = 512; h2 = 512; h3 = 256; out_dim = p^2;

rng(42);
net.W1 = randn(h1, feat_dim) * sqrt(2/feat_dim); net.b1 = zeros(h1,1);
net.W2 = randn(h2, h1) * sqrt(2/h1); net.b2 = zeros(h2,1);
net.W3 = randn(h3, h2) * sqrt(2/h2); net.b3 = zeros(h3,1);
net.W4 = randn(out_dim, h3) * sqrt(2/h3); net.b4 = zeros(out_dim,1);

% Adam buffers
fields = {'W1','b1','W2','b2','W3','b3','W4','b4'};
for f = 1:length(fields)
    net.(['m' fields{f}]) = zeros(size(net.(fields{f})));
    net.(['v' fields{f}]) = zeros(size(net.(fields{f})));
end
net.t = 0;

n_val = floor(num_samples * val_split);
idx = randperm(num_samples);
val_idx = idx(1:n_val); train_idx = idx(n_val+1:end);
best_val_loss = inf;

for ep = 1:epochs
    train_idx = train_idx(randperm(length(train_idx)));
    total_loss = 0; num_batches = 0;
    
    for b = 1:batch_size:length(train_idx)
        batch_idx = train_idx(b:min(b+batch_size-1, length(train_idx)));
        n_batch = length(batch_idx);
        
        gW1 = zeros(size(net.W1)); gb1 = zeros(size(net.b1));
        gW2 = zeros(size(net.W2)); gb2 = zeros(size(net.b2));
        gW3 = zeros(size(net.W3)); gb3 = zeros(size(net.b3));
        gW4 = zeros(size(net.W4)); gb4 = zeros(size(net.b4));
        batch_loss = 0;
        
        for j = 1:n_batch
            i = batch_idx(j);
            feat = traj_data(i).feat;
            target = traj_data(i).step;
            
            % Forward
            z1 = net.W1 * feat + net.b1; h1 = max(z1, 0);
            z2 = net.W2 * h1 + net.b2;   h2 = max(z2, 0);
            z3 = net.W3 * h2 + net.b3;   h3 = max(z3, 0);
            pred = net.W4 * h3 + net.b4;
            
            % Loss: weighted by stage (early stages get higher weight)
            stage_weight = 1.0 + 2.0 * (1 - traj_data(i).stage / max(traj_data(i).total_stages, 2));
            diff = pred - target;
            loss_j = stage_weight * mean(diff.^2);
            batch_loss = batch_loss + loss_j;
            
            % Back-prop
            dy = 2*diff / length(diff);
            dW4 = dy * h3'; db4 = dy;
            dh3 = net.W4' * dy;
            dz3 = dh3 .* (z3 > 0);
            dW3 = dz3 * h2'; db3 = dz3;
            dh2 = net.W3' * dz3;
            dz2 = dh2 .* (z2 > 0);
            dW2 = dz2 * h1'; db2 = dz2;
            dh1 = net.W2' * dz2;
            dz1 = dh1 .* (z1 > 0);
            dW1 = dz1 * feat'; db1 = dz1;
            
            gW1 = gW1 + dW1; gb1 = gb1 + db1;
            gW2 = gW2 + dW2; gb2 = gb2 + db2;
            gW3 = gW3 + dW3; gb3 = gb3 + db3;
            gW4 = gW4 + dW4; gb4 = gb4 + db4;
        end
        
        % Average and clip
        gW1 = max(min(gW1/n_batch, grad_clip), -grad_clip);
        gb1 = max(min(gb1/n_batch, grad_clip), -grad_clip);
        gW2 = max(min(gW2/n_batch, grad_clip), -grad_clip);
        gb2 = max(min(gb2/n_batch, grad_clip), -grad_clip);
        gW3 = max(min(gW3/n_batch, grad_clip), -grad_clip);
        gb3 = max(min(gb3/n_batch, grad_clip), -grad_clip);
        gW4 = max(min(gW4/n_batch, grad_clip), -grad_clip);
        gb4 = max(min(gb4/n_batch, grad_clip), -grad_clip);
        
        batch_loss = batch_loss / n_batch;
        total_loss = total_loss + batch_loss;
        num_batches = num_batches + 1;
        
        % Adam
        net.t = net.t + 1; t = net.t;
        [net.mW1, net.vW1, mhat, vhat] = adam_step(net.mW1, net.vW1, gW1, t, beta1, beta2, eps_adam);
        net.W1 = net.W1 - lr * mhat ./ (sqrt(vhat) + eps_adam);
        [net.mb1, net.vb1, mhat, vhat] = adam_step(net.mb1, net.vb1, gb1, t, beta1, beta2, eps_adam);
        net.b1 = net.b1 - lr * mhat ./ (sqrt(vhat) + eps_adam);
        [net.mW2, net.vW2, mhat, vhat] = adam_step(net.mW2, net.vW2, gW2, t, beta1, beta2, eps_adam);
        net.W2 = net.W2 - lr * mhat ./ (sqrt(vhat) + eps_adam);
        [net.mb2, net.vb2, mhat, vhat] = adam_step(net.mb2, net.vb2, gb2, t, beta1, beta2, eps_adam);
        net.b2 = net.b2 - lr * mhat ./ (sqrt(vhat) + eps_adam);
        [net.mW3, net.vW3, mhat, vhat] = adam_step(net.mW3, net.vW3, gW3, t, beta1, beta2, eps_adam);
        net.W3 = net.W3 - lr * mhat ./ (sqrt(vhat) + eps_adam);
        [net.mb3, net.vb3, mhat, vhat] = adam_step(net.mb3, net.vb3, gb3, t, beta1, beta2, eps_adam);
        net.b3 = net.b3 - lr * mhat ./ (sqrt(vhat) + eps_adam);
        [net.mW4, net.vW4, mhat, vhat] = adam_step(net.mW4, net.vW4, gW4, t, beta1, beta2, eps_adam);
        net.W4 = net.W4 - lr * mhat ./ (sqrt(vhat) + eps_adam);
        [net.mb4, net.vb4, mhat, vhat] = adam_step(net.mb4, net.vb4, gb4, t, beta1, beta2, eps_adam);
        net.b4 = net.b4 - lr * mhat ./ (sqrt(vhat) + eps_adam);
    end
    
    avg_train_loss = total_loss / num_batches;
    
    val_loss = 0;
    for i = 1:length(val_idx)
        feat = traj_data(val_idx(i)).feat;
        target = traj_data(val_idx(i)).step;
        z1 = net.W1 * feat + net.b1; h1 = max(z1, 0);
        z2 = net.W2 * h1 + net.b2;   h2 = max(z2, 0);
        z3 = net.W3 * h2 + net.b3;   h3 = max(z3, 0);
        pred = net.W4 * h3 + net.b4;
        val_loss = val_loss + mean((pred - target).^2);
    end
    val_loss = val_loss / length(val_idx);
    
    if mod(ep, 20) == 0 || ep == 1
        fprintf('Epoch %3d: train_loss=%.4f, val_loss=%.4f\n', ep, avg_train_loss, val_loss);
    end
    if val_loss < best_val_loss, best_val_loss = val_loss; best_net = net; end
end

net = best_net;
save(out_name, 'net');
fprintf('Saved best network (val_loss=%.4f) to: %s\n', best_val_loss, out_name);
end

function [m, v, mhat, vhat] = adam_step(m, v, g, t, beta1, beta2, eps)
    m = beta1*m + (1-beta1)*g;
    v = beta2*v + (1-beta2)*(g.^2);
    mhat = m / (1-beta1^t);
    vhat = v / (1-beta2^t);
end