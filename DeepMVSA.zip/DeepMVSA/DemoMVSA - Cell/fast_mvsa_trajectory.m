function traj = fast_mvsa_trajectory(Y, p, qm, max_iters)
% FAST_MVSA_TRAJECTORY  Generate optimization trajectory using MVSA's
% diagonal Hessian approximation + line search.  No quadprog needed.
%
% This reproduces MVSA's optimization dynamics at ~100x speed.

if nargin < 4, max_iters = 10; end

% VCA initialization + expansion (identical to MVSA)
M_vca = VCA(Y, 'Endmembers', p);
Ym = mean(M_vca, 2);
M = M_vca + p*(M_vca - repmat(Ym, 1, p));
Q = inv(M);

traj(1).Q = Q;
traj(1).f = -log(abs(det(Q)));

mu = 1e-6;

for iter = 1:max_iters
    M = inv(Q);
    g = -M(:);                      % gradient of -log|det(Q)|
    H = mu*eye(p^2) + diag(g.^2);   % diagonal Hessian approx (from MVSA paper)
    
    % Unconstrained Newton step (solving H*d = -g is O(p^6), trivial for p<=20)
    d = - (H \ g);
    
    % Line search with feasibility enforcement
    q = Q(:);
    alphas = [1.0, 0.8, 0.6, 0.4, 0.2, 0.1, 0.05];
    accepted = false;
    
    for a = 1:length(alphas)
        q_new = q + alphas(a) * d;
        Q_new = reshape(q_new, p, p);
        
        if abs(det(Q_new)) > 1e-8
            feasible = all(all(Q_new * Y >= -1e-3));
            f_new = -log(abs(det(Q_new)));
            if feasible && f_new < traj(end).f
                traj(end+1).Q = Q_new;
                traj(end).f = f_new;
                Q = Q_new;
                accepted = true;
                break;
            end
        end
    end
    
    % If Newton step infeasible, expand simplex until feasible (MVSA-style)
    if ~accepted
        Q_test = reshape(q + d, p, p);
        if abs(det(Q_test)) > 1e-8
            M_new = inv(Q_test);
            Ym = mean(M_new, 2);
            dW = M_new - repmat(Ym, 1, p);
            count = 0;
            while sum(sum((inv(M_new)*Y) < 0)) > 0 && count < 200
                M_new = M_new + 0.02*dW;
                count = count + 1;
            end
            Q_new = inv(M_new);
            if abs(det(Q_new)) > 1e-8
                f_new = -log(abs(det(Q_new)));
                if f_new < traj(end).f
                    traj(end+1).Q = Q_new;
                    traj(end).f = f_new;
                    Q = Q_new;
                    accepted = true;
                end
            end
        end
    end
    
    % Termination
    if length(traj) > 1
        rel_change = abs((traj(end-1).f - traj(end).f) / traj(end).f);
        if rel_change < 1e-2 || ~accepted
            break;
        end
    end
end
end