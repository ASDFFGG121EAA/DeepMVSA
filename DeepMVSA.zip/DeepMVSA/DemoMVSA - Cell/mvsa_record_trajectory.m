function traj = mvsa_record_trajectory(Y, p, qm)
% Run a simplified MVSA and record Q at each accepted stage.
% Returns struct array with .Q and .f fields.

[L, N] = size(Y);
my = mean(Y, 2); Yc = Y - repmat(my, 1, N);
[Up, D] = svds(Yc*Yc'/N, p-1);
my_ortho = my - Up*Up'*my;
Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
Y = Up'*Y;

% Spherize
lambda = 1e-10;
C = diag(1./sqrt(diag(D + lambda*eye(p-1))));
Y_tmp = Up*Y - repmat(my, 1, N);
Y = C * Up(:, 1:p-1)' * Y_tmp;
Y(p, :) = 1; Y = Y / sqrt(p);

% VCA init
Mvca = VCA(Y, 'Endmembers', p);
M = Mvca; Ym = mean(M, 2);
M = M + p*(M - repmat(Ym, 1, p));
Q = inv(M);

traj(1).Q = Q;
traj(1).f = -log(abs(det(Q)));

mu = 1e-6;
for iter = 1:10
    M = inv(Q);
    g = -M(:);
    H = mu*eye(p^2) + diag(g.^2);
    q0 = Q(:);
    f = g - H*q0;
    
    % Solve QP (use quadprog if available, else simple gradient step)
    try
        q = quadprog(H, f, -kron(Y', eye(p)), zeros(p*N,1), ...
            kron(eye(p), ones(1,p)), qm, [], [], q0, ...
            optimset('Display', 'off', 'MaxIter', 100));
    catch
        % Fallback: gradient descent
        q = q0 - 0.01 * g;
    end
    
    Q_new = reshape(q, p, p);
    
    % Check feasibility and monotonicity
    if all(all(Q_new * Y >= -1e-3))
        f_new = -log(abs(det(Q_new)));
        if f_new < traj(end).f
            traj(end+1).Q = Q_new;
            traj(end).f = f_new;
            Q = Q_new;
        end
    end
    
    % Termination
    if length(traj) > 1
        if abs((traj(end-1).f - traj(end).f)/traj(end).f) < 1e-2
            break;
        end
    end
end
end