function traj = mvsa_record_real(Y, p, qm)
% MVSA_RECORD_REAL  Run actual MVSA optimization and record trajectory.
% Uses the same diagonal-Hessian + quadProg1 as the original mvsa.m.

[L, N] = size(Y);
mu = 1e-6;
slack = 1e-3;

% VCA init + expansion
M_vca = VCA(Y, 'Endmembers', p);
Ym = mean(M_vca, 2);
M = M_vca + p*(M_vca - repmat(Ym, 1, p));
Q = inv(M);

% Build equality constraint matrix
E = kron(eye(p), ones(1,p));

traj(1).Q = Q;
traj(1).f = -log(abs(det(Q)));

for iter = 1:10
    % Make feasible
    M = inv(Q);
    Ym = mean(M, 2); dW = M - repmat(Ym, 1, p);
    count = 0;
    while sum(sum((inv(M)*Y) < 0)) > 0 && count < 100
        M = M + 0.01*dW; count = count + 1;
    end
    Q = inv(M);
    
    % Gradient and Hessian (identical to mvsa.m)
    g = -M';
    g = g(:);
    H = mu*eye(p^2) + diag(g.^2);
    q0 = Q(:);
    f = g - H*q0;
    
    % Solve QP using MVSA's fast interior point solver
    q = quadProg1(H, f, Y, zeros(p*N,1), E, qm, q0, 0);
    
    Q_new = reshape(q, p, p);
    
    % Check feasibility and monotonicity (identical to mvsa.m)
    feasible = all(all(Q_new * Y >= -slack));
    f_new = -log(abs(det(Q_new)));
    f_old = -log(abs(det(Q)));
    
    if feasible && f_new < f_old
        traj(end+1).Q = Q_new;
        traj(end).f = f_new;
        Q = Q_new;
    else
        % Line search: halve step
        for halve = 1:5
            q = (q + q0) / 2;
            Q_new = reshape(q, p, p);
            feasible = all(all(Q_new * Y >= -slack));
            f_new = -log(abs(det(Q_new)));
            if feasible && f_new < f_old
                traj(end+1).Q = Q_new;
                traj(end).f = f_new;
                Q = Q_new;
                break;
            end
        end
    end
    
    % Termination
    if length(traj) > 1
        rel_change = abs((traj(end-1).f - traj(end).f) / traj(end).f);
        if rel_change < 1e-2
            break;
        end
    end
end
end