function [M, Sest, Up, my, sing_values] = du_mvsa(Y, p, varargin)
if (nargin - length(varargin)) ~= 2, error('Wrong number of required parameters'); end
[L, N] = size(Y); if (L < p), error('Insufficient number of columns in Y'); end

MMiters = 8; spherize = 'yes'; verbose = 1; lambda = 1e-10;
tol_f = 1e-2; M0 = 0; net_weights_path = '';

if (rem(length(varargin), 2) == 1), error('Optional parameters should always go by pairs');
else
    for i = 1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case 'MM_ITERS', MMiters = varargin{i+1};
            case 'SPHERIZE', spherize = varargin{i+1};
            case 'LAMBDA', lambda = varargin{i+1};
            case 'TOLF', tol_f = varargin{i+1};
            case 'M0', M0 = varargin{i+1};
            case 'VERBOSE', verbose = varargin{i+1};
            case 'NET_WEIGHTS', net_weights_path = varargin{i+1};
            otherwise, error(['Unrecognized option: ''' varargin{i} '''']);
        end
    end
end

if (verbose == 0) || (verbose == 1), warning('off', 'all'); else, warning('on', 'all'); end

% Preprocessing
my = mean(Y, 2); Y = Y - repmat(my, 1, N);
[Up, D] = svds(Y*Y'/N, p-1); Y = Up*Up'*Y;
Y = Y + repmat(my, 1, N);
my_ortho = my - Up*Up'*my; Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
sing_values = diag(D); Y = Up'*Y;

if strcmp(spherize, 'yes')
    Y_tmp = Up*Y - repmat(my, 1, N);
    C = diag(1./sqrt(diag(D + lambda*eye(p-1))));
    Y = C * Up(:, 1:p-1)' * Y_tmp; Y(p, :) = 1; Y = Y / sqrt(p);
end

% Initialization
if M0 == 0
    Mvca = VCA(Y, 'Endmembers', p); M = Mvca;
    Ym = mean(M, 2); dQ = M - repmat(Ym, 1, p); M = M + p*dQ;
else
    M = M0 - repmat(my, 1, p);
    M = Up(:, 1:p-1)*Up(:, 1:p-1)'*M + repmat(my, 1, p); M = Up'*M;
    if strcmp(spherize, 'yes')
        M = Up*M - repmat(my, 1, p); M = C*Up(:, 1:p-1)'*M;
        M(p, :) = 1; M = M / sqrt(p);
    end
end

Q = inv(M);
qm = sum((Y*Y' + 1e-6*eye(p)) \ Y, 2);

% Load network
if ~isempty(net_weights_path) && exist(net_weights_path, 'file')
    tmp = load(net_weights_path);
    if isfield(tmp, 'net'), net = tmp.net;
        if verbose, fprintf(' Loaded trained NKKT-Net: %s\n', net_weights_path); end
    else, error('Saved file must contain a struct named "net".'); end
else, error('No trained weights found. Run train_du_mvsa() first.'); end

% Unfolding loop
f_val_back = inf; any_decrease = 0;

for k = 1:MMiters
    feat = extract_features(Q, Y, qm, p, N, net);
    delta_q = nkkt_net_forward(feat, net);
    
    q = Q(:);
    f_old = -log(abs(det(Q)));
    
    % Try neural step with fine-grained line search
    step_sizes = [1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1];
    accepted = false; best_f = inf; best_Q = Q;
    
    for s = 1:length(step_sizes)
        q_new = q + step_sizes(s) * delta_q;
        Q_new = reshape(q_new, p, p);
        if abs(det(Q_new)) > 1e-8
            feasible = all(all(Q_new * Y >= -1e-2));
            f_new = -log(abs(det(Q_new)));
            if feasible && f_new < f_old && f_new < best_f
                best_f = f_new; best_Q = Q_new; accepted = true;
            end
        end
    end
    
    % If neural step fails, expand simplex to enforce feasibility (MVSA-style)
    if ~accepted
        Q_new = reshape(q + delta_q, p, p);
        if abs(det(Q_new)) > 1e-8
            M_new = inv(Q_new);
            Ym = mean(M_new, 2); dW = M_new - repmat(Ym, 1, p);
            count = 0;
            while sum(sum((inv(M_new)*Y) < 0)) > 0 && count < 200
                M_new = M_new + 0.01*dW; count = count + 1;
            end
            Q_new = inv(M_new);
            f_new = -log(abs(det(Q_new)));
            if f_new < f_old
                best_Q = Q_new; accepted = true;
                if verbose > 1, fprintf(' Stage %d: expanded to feasible\n', k); end
            end
        end
    end
    
    % Last resort: gradient fallback
    if ~accepted
        M_tmp = inv(Q); grad = -M_tmp(:); grad = grad / (norm(grad) + eps);
        for alpha = [0.1, 0.05, 0.02, 0.01]
            q_new = q - alpha * grad;
            Q_new = reshape(q_new, p, p);
            if abs(det(Q_new)) > 1e-8 && all(all(Q_new * Y >= -1e-3))
                f_new = -log(abs(det(Q_new)));
                if f_new < f_old
                    best_Q = Q_new; accepted = true;
                    if verbose > 1, fprintf(' Stage %d: grad fallback a=%.2f\n', k, alpha); end
                    break;
                end
            end
        end
    end
    
    if accepted
        Q = best_Q; any_decrease = 1;
    end
    
    f_val = -log(abs(det(Q)));
    if any_decrease && k > 1
        if abs((f_val_back - f_val)/f_val) < tol_f
            if verbose, fprintf(' Termination test PASSED at stage %d\n', k); end
            break;
        end
    end
    f_val_back = f_val;
    if verbose, fprintf(' Stage %d: f = %.6f\n', k, f_val); end
end

% Post-processing
if strcmp(spherize, 'yes')
    M = inv(Q); M = M * sqrt(p); M = M(1:p-1, :);
    M = Up(:, 1:p-1) * diag(sqrt(diag(D + lambda*eye(p-1)))) * M;
    M = M + repmat(my, 1, p); Sest = Q * Y;
else
    M = inv(Q); M = Up * M; Sest = Q * Y;
end
if verbose == 0 || verbose == 1, warning('on', 'all'); end
end
