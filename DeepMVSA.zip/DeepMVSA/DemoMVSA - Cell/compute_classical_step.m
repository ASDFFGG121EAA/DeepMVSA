function d_classical = compute_classical_step(Q, mu)
% Classical MVSA diagonal-Newton step (unconstrained)
% H = mu*I + diag(g^2), g = -M(:), M = inv(Q)
% d = -H^{-1} * g = M(:) ./ (mu + M(:).^2)

M = inv(Q);
m_vec = M(:);
d_classical = m_vec ./ (mu + m_vec.^2 + 1e-8);
end
