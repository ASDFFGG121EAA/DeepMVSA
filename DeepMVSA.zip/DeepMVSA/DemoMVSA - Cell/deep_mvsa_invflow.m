function [M_est, Sest, Up, my, theta] = deep_mvsa_invflow(Y, p, varargin)
%% DeepMVSA-InvFlow (mini-batch version): Invertible Coupled Q + Nonlinear Attention
% Q = L * Q0 * R, L: unit lower-tri, R: upper-tri with positive diagonal.
% A_eff = A_base + c * G .* (A_base.^2)
%
% ------------------------- MINI-BATCH TRAINING -------------------------
% Each gradient step draws BATCH_SIZE samples uniformly at random (with
% replacement). Per-sample SUM penalties (nonnegativity, sum-to-one,
% enclosure) are rescaled by N/B so that the stochastic losses and
% gradients are UNBIASED estimates of the original full-batch quantities
% -- all LAMBDA_* hyperparameters keep their original meaning and tuned
% values transfer directly. The reconstruction loss is a per-sample MEAN
% and needs no rescaling.
%
%   - Per-step cost:      O(B * (p^2 + p*h))  instead of O(N * p^2)
%   - Parameter memory:   O(p^2 + p*h), independent of N  (unchanged)
%   - Set BATCH_SIZE >= N to recover the original full-batch behavior
%     exactly (no random sampling, scaling factor N/B = 1).
%
% q_m is a fixed 1xp target vector precomputed in ONE pass over the data
% before training; it does not enter the per-iteration cost.
%
% Optional data-enclosure penalty sum(min(Q*Y,0).^2) (LAMBDA_ENCLOSE).
% Default 0 -> identical to the original version (used for Cuprite).
% For synthetic data with i.i.d. abundances, set LAMBDA_ENCLOSE = 10 to
% anchor Q to the data convex hull and prevent the simplex from
% collapsing inward under the volume term.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @isnumeric);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);   % enclosure term, default off
addParameter(pStruct, 'BATCH_SIZE', 4096, @isnumeric);    % <<< NEW: mini-batch size (>=N => full batch)
addParameter(pStruct, 'SEED', [], @isnumeric);            % <<< NEW: optional rng seed for reproducibility
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'MEASURE_OPT_MEMORY', false, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
addParameter(pStruct, 'MEMORY_SAMPLE_INTERVAL_MS', 30, @(x) isnumeric(x) && isscalar(x) && x >= 1);
addParameter(pStruct, 'MEMORY_BASELINE_SAMPLES', 3, @(x) isnumeric(x) && isscalar(x) && x >= 1);
parse(pStruct, varargin{:});

if ~isempty(pStruct.Results.SEED)
    rng(pStruct.Results.SEED, 'twister');
end

[L, N] = size(Y);
B = min(pStruct.Results.BATCH_SIZE, N);
full_batch = (B >= N);

%% --------------------- Preprocessing ---------------------
my = mean(Y,2); Yc = Y - repmat(my,1,N);
[Up, D] = svds(Yc*Yc'/N, p-1);
Yp = Up*Up'*Yc + repmat(my,1,N);
my_ortho = my - Up*Up'*my;
Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
Y_proj = Up'*Yp;

if strcmp(pStruct.Results.spherize, 'yes')
    lambda_reg = 1e-10;
    C = diag(1./sqrt(diag(D+lambda_reg*eye(p-1))));
    Ys = C*Up(:,1:p-1)'*(Yp-repmat(my,1,N));
    Ys(p,:) = 1; Ys = Ys/sqrt(p);
    Y_work = Ys;
else
    Y_work = Y_proj; lambda_reg = 0;
end

%% --------------------- Initialization ---------------------
if isempty(pStruct.Results.M0)
    M0 = VCA(Y_work, 'Endmembers', p, 'verbose', 'off');
else
    M0 = pStruct.Results.M0;
    if strcmp(pStruct.Results.spherize, 'yes')
        M0 = M0 - repmat(my,1,p);
        M0 = C*Up(:,1:p-1)'*M0;
        M0(p,:) = 1; M0 = M0/sqrt(p);
    else
        M0 = Up'*M0;
    end
end
Q0 = inv(M0);
qm = ones(1,N)*Y_work'*inv(Y_work*Y_work');   % one pass, O(N*p^2), fixed target thereafter

%% --------------------- Spatial coordinates ---------------------
H = round(sqrt(N)); W = round(N/H);
if H*W == N
    [gx, gy] = meshgrid(linspace(-1,1,W), linspace(-1,1,H));
    coords = [gx(:)'; gy(:)'];
else
    coords = linspace(-1,1,N); coords = coords(:)';
end
coord_dim = size(coords,1);

%% -------- Theorem 3.2 optimization-memory measurement (optional) --------
% Measurement interval:
%   START: immediately before allocating learnable parameters / Adam states
%   STOP : immediately after the joint optimization loop
% Therefore preprocessing, VCA initialization, q_m/coords construction, and
% final full-data abundance materialization are excluded from this metric.
% The mathematical model and all five return values are unchanged.
measure_opt_memory = logical(pStruct.Results.MEASURE_OPT_MEMORY);
opt_mem_monitor = struct();
opt_mem_guard = [];
opt_baseline_ws_mb = NaN;
opt_baseline_private_mb = NaN;
opt_tic = [];

if measure_opt_memory
    if ~ispc
        error(['MEASURE_OPT_MEMORY=true currently requires Windows because ' ...
               'the monitor uses PowerShell Get-Process.']);
    end

    matlab_pid = feature('getpid');
    opt_mem_monitor = start_process_memory_monitor( ...
        matlab_pid, round(pStruct.Results.MEMORY_SAMPLE_INTERVAL_MS), 10);
    opt_mem_guard = onCleanup(@() cleanup_monitor_files(opt_mem_monitor)); %#ok<NASGU>

    [opt_baseline_ws_mb, opt_baseline_private_mb] = ...
        measure_process_memory_snapshot( ...
        matlab_pid, round(pStruct.Results.MEMORY_BASELINE_SAMPLES), 0.03);

    % Release the already-ready external sampler immediately before the
    % learnable parameters are allocated.
    signal_process_memory_monitor_go(opt_mem_monitor);
    opt_tic = tic;
end

%% --------------------- A-Net parameters ---------------------
hidden = 32;
theta.W1 = 0.01*randn(hidden, coord_dim); theta.b1 = zeros(hidden,1);
theta.W2 = 0.01*randn(hidden, hidden);    theta.b2 = zeros(hidden,1);
theta.W3 = 0.01*randn(p, hidden);         theta.b3 = zeros(p,1);
theta.Wg1 = 0.01*randn(hidden, coord_dim); theta.bg1 = zeros(hidden,1);
theta.Wg2 = 0.01*randn(p, hidden);         theta.bg2 = zeros(p,1);
theta.c = 0.05;

%% --------------------- Invertible Q: Q = L * Q0 * R ---------------------
theta.L = zeros(p,p);       % strict lower triangular
theta.R = zeros(p,p);       % strict upper triangular
theta.r_log = zeros(p,1);   % R diagonal log

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

if pStruct.Results.verbose
    fprintf('Mini-batch training: N=%d, batch=%d, steps/epoch=%.1f\n', N, B, N/B);
end

%% --------------------- Warm-up (linear, Q fixed at Q0) ---------------------
if pStruct.Results.verbose, fprintf('Warm-up (linear, fixed Q)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    [Yb, cb] = next_batch(Y_work, coords, N, B, full_batch);              % <<< mini-batch
    [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_SUMONE, pStruct.Results.LAMBDA_ENCLOSE, true, N);   % <<< N passed for scaling
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Warm-up %d/%d, loss=%.6f\n', k, pStruct.Results.WARM_UP, loss);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + nonlinear)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
for k = 1:n_joint
    [Yb, cb] = next_batch(Y_work, coords, N, B, full_batch);              % <<< mini-batch
    [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, pStruct.Results.LAMBDA_SUMONE, ...
        pStruct.Results.LAMBDA_ENCLOSE, false, N);                         % <<< N passed for scaling
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Joint %d/%d, loss=%.6f, c=%.4f\n', k, n_joint, loss, theta.c);
    end
end

%% -------- End Theorem 3.2 optimization-memory measurement --------
if measure_opt_memory
    optimization_runtime_sec = toc(opt_tic);
    [opt_peak_ws_mb, opt_peak_private_mb, opt_monitor_samples] = ...
        stop_process_memory_monitor(opt_mem_monitor, 10);

    opt_working_memory_mb = max(opt_peak_ws_mb - opt_baseline_ws_mb, 0);
    opt_delta_private_mb = max(opt_peak_private_mb - opt_baseline_private_mb, 0);

    fprintf('\n===============================================================\n');
    fprintf('THEOREM 3.2 OPTIMIZATION-MEMORY MEASUREMENT\n');
    fprintf('---------------------------------------------------------------\n');
    fprintf('N                              : %d\n', N);
    fprintf('K                              : %d\n', p - 1);
    fprintf('p = K+1                        : %d\n', p);
    fprintf('Batch size                     : %d\n', B);
    fprintf('Baseline WorkingSet            : %.2f MB\n', opt_baseline_ws_mb);
    fprintf('Peak WorkingSet (optimization) : %.2f MB\n', opt_peak_ws_mb);
    fprintf('Optimization Working Memory    : %.2f MB   <-- Table 1 memory\n', opt_working_memory_mb);
    fprintf('Baseline Private Mem           : %.2f MB\n', opt_baseline_private_mb);
    fprintf('Peak Private Mem               : %.2f MB\n', opt_peak_private_mb);
    fprintf('Delta Private Mem              : %.2f MB\n', opt_delta_private_mb);
    fprintf('Optimization runtime           : %.6f sec\n', optimization_runtime_sec);
    fprintf('Monitor samples                : %d\n', round(opt_monitor_samples));
    fprintf('Monitor interval               : %d ms\n', round(pStruct.Results.MEMORY_SAMPLE_INTERVAL_MS));
    fprintf('===============================================================\n\n');

    % The result has already been parsed; clearing the guard removes all
    % temporary synchronization/PowerShell files.
    clear opt_mem_guard
end

%% --------------------- Recover endmembers ---------------------
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M_sub = inv(Q);

% Full-data abundance forward pass in chunks: memory stays O(chunk*p)
% regardless of N (for N >= 1e8 this is also where streaming I/O would go).
CHUNK = min(N, 1048576);   % 2^20
A_eff = zeros(p, N);
for i1 = 1:CHUNK:N
    i2 = min(i1+CHUNK-1, N);
    A_eff(:, i1:i2) = abundance_net_forward_nl(coords(:, i1:i2), theta, false);
end
Sest = A_eff;

if strcmp(pStruct.Results.spherize, 'yes')
    M_sub = M_sub*sqrt(p);
    M_sub = M_sub(1:p-1,:);
    M_est = Up(:,1:p-1)*diag(sqrt(diag(D+lambda_reg*eye(p-1))))*M_sub + repmat(my,1,p);
else
    M_est = Up*M_sub;
end
end

%% ===================== Sub-functions =====================
function [Yb, cb] = next_batch(Y_work, coords, N, B, full_batch)
%NEXT_BATCH  Uniform random mini-batch (with replacement); full batch if B >= N.
if full_batch
    Yb = Y_work; cb = coords;
else
    idx = randi(N, 1, B);
    Yb = Y_work(:, idx); cb = coords(:, idx);
end
end

function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)));
end
end

function [A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up)
Z1 = theta.W1*coords + theta.b1; H1 = tanh(Z1);
Z2 = theta.W2*H1 + theta.b2;     H2 = tanh(Z2);
Z3 = theta.W3*H2 + theta.b3;
Z3 = Z3 - max(Z3,[],1); expZ = exp(Z3);
A_base = expZ ./ sum(expZ,1);

Zg1 = theta.Wg1*coords + theta.bg1; Hg1 = tanh(Zg1);
Zg2 = theta.Wg2*Hg1 + theta.bg2;
G = 1./(1+exp(-Zg2));

c = warm_up*0 + (1-warm_up)*theta.c;
A_eff = A_base + c*(G.*(A_base.^2));

cache.Z1=Z1; cache.H1=H1; cache.Z2=Z2; cache.H2=H2; cache.Z3=Z3;
cache.expZ=expZ; cache.coords=coords;
cache.Zg1=Zg1; cache.Hg1=Hg1; cache.Zg2=Zg2; cache.G=G;
cache.A_base=A_base; cache.c=c; cache.warm_up=warm_up;
end

function grad = abundance_net_backward_nl(dA_eff, cache, theta)
A_base = cache.A_base; G = cache.G; c = cache.c; warm_up = cache.warm_up;

dA_base = dA_eff + 2*c*G.*A_base.*dA_eff;
dG = c*(A_base.^2).*dA_eff;
dc = sum(sum((G.*(A_base.^2)).*dA_eff));

if warm_up
    grad.Wg1 = zeros(size(theta.Wg1)); grad.bg1 = zeros(size(theta.bg1));
    grad.Wg2 = zeros(size(theta.Wg2)); grad.bg2 = zeros(size(theta.bg2));
    grad.c = 0;
else
    dZg2 = dG.*(G.*(1-G));
    grad.Wg2 = dZg2*cache.Hg1'; grad.bg2 = sum(dZg2,2);
    dHg1 = theta.Wg2'*dZg2;
    dZg1 = dHg1.*(1-tanh(cache.Zg1).^2);
    grad.Wg1 = dZg1*cache.coords'; grad.bg1 = sum(dZg1,2);
    grad.c = dc;
end

A = cache.expZ ./ sum(cache.expZ,1);
dZ3 = A.*(dA_base - sum(A.*dA_base,1));
grad.W3 = dZ3*cache.H2'; grad.b3 = sum(dZ3,2);
dH2 = theta.W3'*dZ3;
dZ2 = dH2.*(1-tanh(cache.Z2).^2);
grad.W2 = dZ2*cache.H1'; grad.b2 = sum(dZ2,2);
dH1 = theta.W2'*dZ2;
dZ1 = dH1.*(1-tanh(cache.Z1).^2);
grad.W1 = dZ1*cache.coords'; grad.b1 = sum(dZ1,2);
end

function [loss, grad] = compute_gradients_invflow(theta, Y, coords, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, lambda_enclose, warm_up, N_total)
% Y is a BATCH of Nb columns drawn from the full data set of N_total
% samples. Per-sample SUM penalties are scaled by s = N_total/Nb so that
% all stochastic losses/gradients are unbiased estimates of the original
% full-batch versions (s = 1 recovers them exactly).
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q); % p is small, numerically safe

[A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up);

Nb = size(Y, 2);
s = N_total / Nb;              % unbiased scaling for per-sample SUM penalties

Y_hat = M * A_eff;
diff = Y_hat - Y;
loss_recon = mean(sum(diff.^2,1));         % per-sample MEAN: no rescaling

loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant

penalty = min(A_eff,0);
loss_nonneg = s * sum(penalty.^2, 'all');                 % <<< scaled

sum_A = sum(A_eff,1);
loss_sumone = s * sum((sum_A-1).^2, 'all');               % <<< scaled

col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');   % data-free (q_m precomputed)

% --- optional data-enclosure penalty QY >= 0 ---
QY = Q*Y;
pen_enclose = min(QY, 0);
loss_enclose = s * sum(pen_enclose.^2, 'all');            % <<< scaled

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + lambda_enclose*loss_enclose;

dY_hat = 2*diff/Nb;                        % gradient of the batch MEAN
dM = dY_hat * A_eff';
grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * s * pen_enclose * Y';                % <<< scaled
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

% Map Q-gradients to triangular parameters
grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

% Backprop to abundance network
dA_eff = M' * dY_hat + s * (2*lambda_nonneg*penalty + ...
    2*lambda_sumone*repmat(sum_A-1, p, 1));               % <<< scaled
grad_net = abundance_net_backward_nl(dA_eff, cache, theta);
grad.W1 = grad_net.W1; grad.b1 = grad_net.b1;
grad.W2 = grad_net.W2; grad.b2 = grad_net.b2;
grad.W3 = grad_net.W3; grad.b3 = grad_net.b3;
grad.Wg1 = grad_net.Wg1; grad.bg1 = grad_net.bg1;
grad.Wg2 = grad_net.Wg2; grad.bg2 = grad_net.bg2;
grad.c = grad_net.c;
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr)
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*(grad.(f).^2);
    m_hat = m.(f) / (1 - beta1^iter);
    v_hat = v.(f) / (1 - beta2^iter);
    theta.(f) = theta.(f) - lr * m_hat ./ (sqrt(v_hat) + eps);
end
end

%% ===================== Theorem 3.2 memory-monitor helpers =====================
function monitor = start_process_memory_monitor(target_pid, interval_ms, timeout_sec)
%START_PROCESS_MEMORY_MONITOR Launch an asynchronous PowerShell sampler.
% The sampler waits for a GO file, so preprocessing/initialization are not
% included in the measured optimization interval.

    token = char(java.util.UUID.randomUUID);
    base = fullfile(tempdir, ['dmvsa_t32_mem_' token]);

    monitor.script_file = [base '.ps1'];
    monitor.ready_file = [base '_ready.flag'];
    monitor.go_file = [base '_go.flag'];
    monitor.stop_file = [base '_stop.flag'];
    monitor.out_file = [base '_result.txt'];

    cleanup_monitor_files(monitor);

    fid = fopen(monitor.script_file, 'w');
    if fid < 0
        error('Could not create temporary PowerShell monitor script.');
    end
    script_guard = onCleanup(@() fclose_if_open(fid)); %#ok<NASGU>

    fprintf(fid, 'param([int]$TargetPid,[string]$ReadyFile,[string]$GoFile,[string]$StopFile,[string]$OutFile,[int]$IntervalMs)\r\n');
    fprintf(fid, '$peakWS = [int64]0\r\n');
    fprintf(fid, '$peakPrivate = [int64]0\r\n');
    fprintf(fid, '$count = 0\r\n');
    fprintf(fid, 'Set-Content -LiteralPath $ReadyFile -Value "ready" -Encoding ascii\r\n');
    fprintf(fid, 'while ((-not (Test-Path -LiteralPath $GoFile)) -and (-not (Test-Path -LiteralPath $StopFile))) { Start-Sleep -Milliseconds 5 }\r\n');
    fprintf(fid, 'while (-not (Test-Path -LiteralPath $StopFile)) {\r\n');
    fprintf(fid, '  try {\r\n');
    fprintf(fid, '    $proc = Get-Process -Id $TargetPid -ErrorAction Stop\r\n');
    fprintf(fid, '    $ws = [int64]$proc.WorkingSet64\r\n');
    fprintf(fid, '    $pr = [int64]$proc.PrivateMemorySize64\r\n');
    fprintf(fid, '    if ($ws -gt $peakWS) { $peakWS = $ws }\r\n');
    fprintf(fid, '    if ($pr -gt $peakPrivate) { $peakPrivate = $pr }\r\n');
    fprintf(fid, '    $count++\r\n');
    fprintf(fid, '  } catch { break }\r\n');
    fprintf(fid, '  Start-Sleep -Milliseconds $IntervalMs\r\n');
    fprintf(fid, '}\r\n');
    fprintf(fid, 'try {\r\n');
    fprintf(fid, '  $proc = Get-Process -Id $TargetPid -ErrorAction Stop\r\n');
    fprintf(fid, '  $ws = [int64]$proc.WorkingSet64\r\n');
    fprintf(fid, '  $pr = [int64]$proc.PrivateMemorySize64\r\n');
    fprintf(fid, '  if ($ws -gt $peakWS) { $peakWS = $ws }\r\n');
    fprintf(fid, '  if ($pr -gt $peakPrivate) { $peakPrivate = $pr }\r\n');
    fprintf(fid, '  $count++\r\n');
    fprintf(fid, '} catch {}\r\n');
    fprintf(fid, 'Set-Content -LiteralPath $OutFile -Value (("{0},{1},{2}" -f $peakWS,$peakPrivate,$count)) -Encoding ascii\r\n');

    fclose(fid);
    fid = -1;

    cmd = sprintf(['start "" /B powershell.exe -NoProfile -WindowStyle Hidden ' ...
        '-ExecutionPolicy Bypass -File "%s" -TargetPid %d -ReadyFile "%s" ' ...
        '-GoFile "%s" -StopFile "%s" -OutFile "%s" -IntervalMs %d'], ...
        monitor.script_file, target_pid, monitor.ready_file, monitor.go_file, ...
        monitor.stop_file, monitor.out_file, interval_ms);

    [status, cmdout] = system(cmd);
    if status ~= 0
        cleanup_monitor_files(monitor);
        error('Could not start PowerShell memory monitor: %s', strtrim(cmdout));
    end

    wait_for_file(monitor.ready_file, timeout_sec, ...
        'PowerShell memory monitor did not become ready in time.');
end

function signal_process_memory_monitor_go(monitor)
%SIGNAL_PROCESS_MEMORY_MONITOR_GO Start sampling the optimization interval.
    fid = fopen(monitor.go_file, 'w');
    if fid < 0
        error('Could not create monitor GO signal file.');
    end
    fprintf(fid, 'go\n');
    fclose(fid);
end

function [peak_ws_mb, peak_private_mb, count] = stop_process_memory_monitor(monitor, timeout_sec)
%STOP_PROCESS_MEMORY_MONITOR Stop sampler and parse peak process memory.
    fid = fopen(monitor.stop_file, 'w');
    if fid < 0
        error('Could not create monitor STOP signal file.');
    end
    fprintf(fid, 'stop\n');
    fclose(fid);

    wait_for_file(monitor.out_file, timeout_sec, ...
        'PowerShell memory monitor did not return a result in time.');

    raw = strtrim(fileread(monitor.out_file));
    vals = sscanf(raw, '%f,%f,%f');
    if numel(vals) ~= 3
        error('Unexpected monitor result: %s', raw);
    end

    peak_ws_mb = vals(1) / (1024^2);
    peak_private_mb = vals(2) / (1024^2);
    count = vals(3);

    if count < 1
        error('The memory monitor returned zero samples.');
    end
end

function [ws_mb, private_mb] = measure_process_memory_snapshot(target_pid, n_samples, pause_sec)
%MEASURE_PROCESS_MEMORY_SNAPSHOT Median baseline from OS process snapshots.
    ws = zeros(1, n_samples);
    pr = zeros(1, n_samples);

    for i = 1:n_samples
        [ws(i), pr(i)] = query_process_memory_bytes(target_pid);
        if i < n_samples
            pause(pause_sec);
        end
    end

    ws_mb = median(ws) / (1024^2);
    private_mb = median(pr) / (1024^2);
end

function [ws_bytes, private_bytes] = query_process_memory_bytes(target_pid)
%QUERY_PROCESS_MEMORY_BYTES Current WorkingSet64 and PrivateMemorySize64.
    cmd = sprintf(['powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ' ...
        '"$proc=Get-Process -Id %d -ErrorAction Stop; ' ...
        'Write-Output (((''{0},{1}'') -f $proc.WorkingSet64,$proc.PrivateMemorySize64))"'], ...
        target_pid);

    [status, out] = system(cmd);
    if status ~= 0
        error('PowerShell baseline memory query failed: %s', strtrim(out));
    end

    vals = sscanf(strtrim(out), '%f,%f');
    if numel(vals) ~= 2
        error('Unexpected PowerShell baseline output: %s', strtrim(out));
    end

    ws_bytes = vals(1);
    private_bytes = vals(2);
end

function wait_for_file(file_name, timeout_sec, err_msg)
%WAIT_FOR_FILE Wait for monitor synchronization/result file.
    t0 = tic;
    while ~exist(file_name, 'file')
        pause(0.02);
        if toc(t0) > timeout_sec
            error('%s', err_msg);
        end
    end
end

function cleanup_monitor_files(monitor)
%CLEANUP_MONITOR_FILES Best-effort stop and removal of temporary files.
    if isfield(monitor, 'stop_file') && ~exist(monitor.stop_file, 'file')
        fid = fopen(monitor.stop_file, 'w');
        if fid >= 0
            fprintf(fid, 'stop\n');
            fclose(fid);
        end
    end

    fields = {'ready_file','go_file','out_file','script_file','stop_file'};
    for i = 1:numel(fields)
        f = fields{i};
        if isfield(monitor, f)
            file_name = monitor.(f);
            if exist(file_name, 'file')
                try
                    delete(file_name);
                catch
                    % Best-effort cleanup only.
                end
            end
        end
    end
end

function fclose_if_open(fid)
%FCLOSE_IF_OPEN Best-effort file-handle cleanup on error paths.
    if isnumeric(fid) && isscalar(fid) && fid >= 0
        try
            fclose(fid);
        catch
        end
    end
end

