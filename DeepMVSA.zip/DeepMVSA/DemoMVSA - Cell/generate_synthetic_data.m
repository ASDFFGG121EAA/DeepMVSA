function data = generate_du_mvsa_trainset(p, num_samples, L, varargin)
% GENERATE_DU_MVSA_TRAINSET  Create training data via spectMixGen + MVSA preprocessing.
%
% Each sample is preprocessed (affine projection + spherization) exactly
% as du_mvsa does internally, so the network learns in the correct domain.

ip = inputParser;
addParameter(ip, 'SNR_min', 20);
addParameter(ip, 'SNR_max', 90);
addParameter(ip, 'max_purity', 0.8);
addParameter(ip, 'N', 100*100);
addParameter(ip, 'SHAPE_PARAMETER', 1);
parse(ip, varargin{:});

data(num_samples) = struct('Y', [], 'M', [], 'A', [], 'Q_opt', [], 'qm', []);

for i = 1:num_samples
    % Random endmembers (same family as demo case 3)
    M_full = rand(L, p);
    
    % Random SNR in [20, 90] dB
    SNR = ip.Results.SNR_min + (ip.Results.SNR_max - ip.Results.SNR_min)*rand();
    
    % Generate mixture using your existing function
    [Y_noisy, A_true, ~] = spectMixGen(M_full, ip.Results.N, ...
        'Source_pdf', 'Diri_id', ...
        'pdf_pars', ip.Results.SHAPE_PARAMETER, ...
        'max_purity', ip.Results.max_purity*ones(1,p), ...
        'snr', SNR, 'noise_shape', 'uniform');
    
    % --- Preprocess exactly as du_mvsa / mvsa ---
    [L2, N2] = size(Y_noisy);
    my = mean(Y_noisy, 2);
    Yc = Y_noisy - repmat(my, 1, N2);
    [Up, D] = svds(Yc*Yc'/N2, p-1);
    my_ortho = my - Up*Up'*my;
    Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
    
    % Project to p-dim subspace
    Y_proj = Up' * Y_noisy;     % p x N
    M_proj = Up' * M_full;      % p x p
    
    % Spherize (same as du_mvsa default)
    lambda = 1e-10;
    C = diag(1./sqrt(diag(D + lambda*eye(p-1))));
    Y_spher = C * Up(:, 1:p-1)' * (Up*Y_proj - repmat(my, 1, N2));
    Y_spher(p, :) = 1;
    Y_spher = Y_spher / sqrt(p);
    
    M_spher = C * Up(:, 1:p-1)' * (Up*M_proj - repmat(my, 1, p));
    M_spher(p, :) = 1;
    M_spher = M_spher / sqrt(p);
    
    % Ground-truth Q and equality rhs
    Q_opt = inv(M_spher);
    qm = sum((Y_spher*Y_spher' + 1e-6*eye(p)) \ Y_spher, 2);
    
    data(i).Y = Y_spher;
    data(i).M = M_spher;
    data(i).A = A_true;
    data(i).Q_opt = Q_opt;
    data(i).qm = qm;
    
    if mod(i, 500) == 0
        fprintf('  Generated %d/%d training samples\n', i, num_samples);
    end
end
end