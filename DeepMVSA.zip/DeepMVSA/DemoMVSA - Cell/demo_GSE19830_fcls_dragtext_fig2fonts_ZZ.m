%% Copy_of_demo_deepmvsa_GSE19830_compare
% =========================================================================
% GSE19830 生物数据上的多方法 simplex 对比实验
%
% 基于：
%   1) demo_deepmvsa_GSE19830_figure6.m
%   2) Copy_of_demo_deepmvsa_usgs_invflow1.m
%
% 对比方法：
%   - Ground Truth (measured pure tissues)
%   - MVSA            (仍计算，但不显示在2D散点图中)
%   - VCA             (仍计算，但不显示在2D散点图中)
%   - Soft-ML (2021)  (显示在2D散点图中)
%   - DeepMVSA-InvFlow(显示在2D散点图中)
%
% 主要输出：
%   1) Soft-ML / DeepMVSA 各独立运行 20 次；每次先与真实组织顺序做全局最优对齐。
%   2) Figure 1：显示 20 次对齐后 simplex 顶点的平均位置，并标注 20 次平均 SAD；
%      横纵轴自动显示 PC1 / PC2 的 explained-variance percentage。
%   3) Figure 2：DeepMVSA / Soft-ML 各显示一条 20 次平均 LOESS 曲线，并分别绘制
%      基于 20 条 run-level LOESS 曲线 bootstrap 得到的 95% pointwise CI 背景带；
%      Figure 2 使用两个独立图例：主图例显示曲线/样本，第二图例显示两种 95% bootstrap CI 且可鼠标拖动。
%   4) 仅在 MATLAB 窗口显示图形和命令行指标；不保存任何图片或数据文件。
%
% 数据：
%   GSE19830_DeepMVSA_ready.mat
%       Y      : 31099 x 42
%       S_true : 3 x 42
%
% 需要路径中存在：
%   dataProj.m
%   mvsa.m
%   VCA.m
%   SoftML_Simplex_2021_v3.m
%   deep_mvsa_invflow.m
% =========================================================================

clear; clc; close all;

%% ========================== 0. Required files ===========================
required_files = { ...
    'GSE19830_DeepMVSA_ready.mat', ...
    'dataProj.m', ...
    'mvsa.m', ...
    'VCA.m', ...
    'SoftML_Simplex_2021_v3.m', ...
    'deep_mvsa_invflow.m'};

for ii = 1:numel(required_files)
    if exist(required_files{ii}, 'file') ~= 2
        error('Required file not found on MATLAB path: %s', required_files{ii});
    end
end

%% ========================== 1. Load GSE19830 ============================
DATA_FILE = 'GSE19830_DeepMVSA_ready.mat';
load(DATA_FILE);

% Desired orientation:
%   Y      = features x samples
%   S_true = tissues  x samples
if size(S_true,1) ~= 3 && size(S_true,2) == 3
    S_true = S_true';
end

if size(Y,2) ~= size(S_true,2) && size(Y,1) == size(S_true,2)
    Y = Y';
end

[L_raw, N] = size(Y);
p = size(S_true,1);

if p ~= 3
    error('GSE19830 Figure-6 experiment expects p=3 tissues.');
end

if N ~= 42
    warning('Expected N=42 samples, but current N=%d.', N);
end

if any(~isfinite(Y(:))) || any(~isfinite(S_true(:)))
    error('Y or S_true contains NaN/Inf.');
end

if exist('tissue_names','var')
    if isstring(tissue_names)
        tissue_names = cellstr(tissue_names);
    elseif ischar(tissue_names)
        tissue_names = cellstr(tissue_names);
    end
else
    tissue_names = {'Liver','Brain','Kidney'};
end

% This dataset corresponds to Liver / Brain / Kidney.  Some earlier local
% versions used the display label "Lung"; normalize that label here without
% changing the row order of S_true.
for k = 1:numel(tissue_names)
    if strcmpi(strtrim(tissue_names{k}), 'Lung')
        tissue_names{k} = 'Kidney';
    end
end

fprintf('\n============================================================\n');
fprintf('GSE19830 multi-method simplex comparison\n');
fprintf('Raw data: %d probes x %d samples\n', L_raw, N);
fprintf('Tissues : %s / %s / %s\n', ...
    tissue_names{1}, tissue_names{2}, tissue_names{3});
fprintf('============================================================\n');

%% ========================== 2. Ground-truth tissue profiles =============
% 用每一种组织的纯样本重复测量均值作为真实 tissue profile。

M_true_raw = zeros(L_raw, p);
pure_counts = zeros(1,p);

for k = 1:p

    other_idx = setdiff(1:p, k);

    pure_idx = find( ...
        abs(S_true(k,:) - 1) < 1e-12 & ...
        sum(S_true(other_idx,:),1) < 1e-12);

    pure_counts(k) = numel(pure_idx);

    if isempty(pure_idx)
        error('No pure sample found for tissue %s.', tissue_names{k});
    end

    M_true_raw(:,k) = mean(Y(:,pure_idx), 2);

    fprintf('Pure samples for %-8s: %d\n', ...
        tissue_names{k}, pure_counts(k));
end

%% ========================== 3. PCA: 31099 -> 41 ========================
% 与已经能运行的 demo_deepmvsa_GSE19830_figure6 保持一致。
%
% 注意：
% 这里先利用中心化数据计算 PCA 基。
% 为了让 MVSA / VCA / Soft-ML 的 affine projection 不因“均值严格为0”
% 而退化，算法输入采用未中心化的 PCA 坐标：
%
%   Y_pca = U41' * Y
%
% 真正用于 Figure 6(a) 显示的 PC score 则再减去 PCA-space mean。
%
% 这样所有方法使用同一个 41-D 表示，并且最终画图仍然是标准的
% centered PC1 / PC2 score。

mu_raw = mean(Y,2);
Yc_raw = Y - mu_raw;

PCA_DIM = min(41, N-1);

fprintf('\nComputing economy PCA: %d -> %d ...\n', ...
    L_raw, PCA_DIM);

[U_pca, S_pca, ~] = svd(Yc_raw, 'econ');
U41 = U_pca(:,1:PCA_DIM);

% 统一的 41-D 算法输入（保留 PCA-space mean）
Y_pca = U41' * Y;                       % 41 x 42
M_true_pca = U41' * M_true_raw;         % 41 x 3
mu_pca = mean(Y_pca,2);                 % 41 x 1

% centered PCA scores，只用于误差和 2-D 可视化
Y_score = Y_pca - mu_pca;
Mtrue_score = M_true_pca - mu_pca;

explained_energy = diag(S_pca).^2;
explained_energy = explained_energy / ...
    (sum(explained_energy) + eps);

energy_retained = sum( ...
    explained_energy(1:min(PCA_DIM,numel(explained_energy))));

fprintf('PCA data size   : %d x %d\n', ...
    size(Y_pca,1), size(Y_pca,2));
fprintf('Energy retained : %.10f\n', energy_retained);

%% ========================== 4. Common affine projection =================
% 传统 simplex 方法按照原 USGS comparison demo 的流程，先 dataProj。

[Y_proj, Up, my, sing_val] = ...
    dataProj(Y_pca, p, 'proj_type', 'affine'); %#ok<ASGLU>

%% ========================== 5. MVSA =====================================
fprintf('\nRunning MVSA...\n');
tic;

M_mvsa_pca = mvsa( ...
    Y_proj, p, ...
    'spherize', 'yes', ...
    'verbose', 0);

t_mvsa = toc;

fprintf('MVSA finished in %.3f s\n', t_mvsa);

%% ========================== 6. VCA ======================================
fprintf('\nRunning VCA...\n');
tic;

[M_vca_pca, ~, ~] = VCA( ...
    Y_proj, ...
    'Endmembers', p, ...
    'verbose', 'off');

t_vca = toc;

fprintf('VCA finished in %.3f s\n', t_vca);

%% ========================== 7. Twenty-run experiment ====================
% Figure 1 and Figure 2 are both based on 20 independent runs of Soft-ML
% and DeepMVSA.  The PCA basis, ground truth, MVSA/VCA reference results,
% and observed biological samples are fixed across runs.
%
% Each run is independently aligned to the ground-truth tissue ordering
% before averaging.  This is essential because simplex vertices are
% permutation invariant.

N_RUNS = 50;

% Soft-ML settings (same optimization settings as the single-run version).
SOFTML_MAX_ITER = 150;

% DeepMVSA settings (unchanged from the previous single-run experiment).
MM_ITERS = 20000;
WARM_UP = 5000;
LR = 3e-4;

LAMBDA_VOL = 0.01;
LAMBDA_NONNEG = 5;
LAMBDA_EQ = 80;
LAMBDA_SUMONE = 5;
LAMBDA_ENCLOSE = 10;

% LOESS settings.  Keep the same neighborhood setting used in the current
% figure.  Each run produces one local-quadratic LOESS curve.
LOESS_SPAN = 15;
x_grid = linspace(0,1,200);

% Bootstrap the 20 independent run-level LOESS curves to obtain a 95%
% pointwise confidence interval for the MEAN LOESS trend of each method.
BOOTSTRAP_REPEATS = 500;
BOOTSTRAP_SEED_DEEP = 2026;
BOOTSTRAP_SEED_SOFTML = 2027;

% ---------------- Align deterministic MVSA/VCA references once -----------
M_mvsa_score = M_mvsa_pca - mu_pca;
M_vca_score = M_vca_pca - mu_pca;

[MVSA_ERR, perm_mvsa] = ...
    best_relative_endmember_error(Mtrue_score, M_mvsa_score);
M_mvsa_score = M_mvsa_score(:,perm_mvsa);
M_mvsa_pca = M_mvsa_pca(:,perm_mvsa);

[VCA_ERR, perm_vca] = ...
    best_relative_endmember_error(Mtrue_score, M_vca_score);
M_vca_score = M_vca_score(:,perm_vca);
M_vca_pca = M_vca_pca(:,perm_vca);

% ---------------- Preallocate 20-run storage ------------------------------
M_softml_pca_runs   = zeros(PCA_DIM,p,N_RUNS);
M_deep_pca_runs     = zeros(PCA_DIM,p,N_RUNS);
M_softml_score_runs = zeros(PCA_DIM,p,N_RUNS);
M_deep_score_runs   = zeros(PCA_DIM,p,N_RUNS);

SOFTML_ERR_RUNS = zeros(N_RUNS,1);
DEEP_ERR_RUNS   = zeros(N_RUNS,1);
SOFTML_SAD_DEG_RUNS = zeros(N_RUNS,p);
DEEP_SAD_DEG_RUNS   = zeros(N_RUNS,p);

% Figure-2 run-level abundance metrics.  These are required for reporting
% the variability (SD) across the same 20 independent runs.
SOFTML_PEARSON_RUNS = zeros(N_RUNS,1);
SOFTML_MSE_RUNS     = zeros(N_RUNS,1);
DEEP_PEARSON_RUNS = zeros(N_RUNS,1);
DEEP_MSE_RUNS     = zeros(N_RUNS,1);

S_softml_fcls_runs = zeros(p,N,N_RUNS);
S_deep_fcls_runs   = zeros(p,N,N_RUNS);

loess_softml_runs = zeros(N_RUNS,numel(x_grid));
loess_deep_runs   = zeros(N_RUNS,numel(x_grid));

t_softml_runs = zeros(N_RUNS,1);
t_deep_runs   = zeros(N_RUNS,1);
theta_c_runs  = NaN(N_RUNS,1);

perm_softml_runs = zeros(N_RUNS,p);
perm_deep_runs   = zeros(N_RUNS,p);

Mtrue_affine3 = Up' * M_true_pca;
if size(Mtrue_affine3,1) ~= 3
    error('Expected the affine SAD representation to have 3 rows, but got %d.', ...
        size(Mtrue_affine3,1));
end

fprintf('\n============================================================\n');
fprintf('Running Soft-ML and DeepMVSA for %d independent runs\n', N_RUNS);
fprintf('============================================================\n');

for run_idx = 1:N_RUNS

    fprintf('\n------------------------- Run %02d / %02d -------------------------\n', ...
        run_idx, N_RUNS);

    %% ------------------------ Soft-ML run -------------------------------
    % Preserve the original first-run seed (=1) and use a distinct,
    % reproducible seed for every subsequent run.
    softml_seed = run_idx;

    fprintf('Running Soft-ML (seed=%d)...\n', softml_seed);
    tic;

    [M_softml_run, ~, ~] = ...
        SoftML_Simplex_2021_v3( ...
        Y_pca, p, ...
        'YProj', Y_proj, ...
        'Up', Up, ...
        'my', my, ...
        'MTrue', M_true_pca, ...
        'MaxIter', SOFTML_MAX_ITER, ...
        'Gamma', [], ...
        'Alpha', [], ...
        'UseConvexHullInit', true, ...
        'UseHullGradient', true, ...
        'Seed', softml_seed, ...
        'Plot', false, ...
        'Verbose', false);

    t_softml_runs(run_idx) = toc;

    %% ------------------------ DeepMVSA run ------------------------------
    % Run 1 reproduces the previous seeds (shuffle=1, model=10).  The
    % remaining runs use different deterministic seeds.
    shuffle_seed = run_idx;
    model_seed = 9 + run_idx;

    rng(shuffle_seed, 'twister');
    sample_order = randperm(N);
    Y_deep = Y_pca(:,sample_order);

    rng(model_seed, 'twister');

    fprintf('Running DeepMVSA (shuffle seed=%d, model seed=%d)...\n', ...
        shuffle_seed, model_seed);
    tic;

    [M_deep_run, Sest_model, ~, ~, theta] = ...
        deep_mvsa_invflow( ...
        Y_deep, p, ...
        'spherize', 'yes', ...
        'verbose', 1, ...
        'MM_ITERS', MM_ITERS, ...
        'WARM_UP', WARM_UP, ...
        'LR', LR, ...
        'LAMBDA_VOL', LAMBDA_VOL, ...
        'LAMBDA_NONNEG', LAMBDA_NONNEG, ...
        'LAMBDA_EQ', LAMBDA_EQ, ...
        'LAMBDA_SUMONE', LAMBDA_SUMONE, ...
        'LAMBDA_ENCLOSE', LAMBDA_ENCLOSE);

    t_deep_runs(run_idx) = toc;
    if isfield(theta,'c')
        theta_c_runs(run_idx) = theta.c;
    end

    % Restore the A-Net abundance output to the original biological sample
    % order.  It is retained only for consistency with the training pipeline;
    % Figure 2 uses FCLS for both methods to ensure a fair comparison.
    Sest_raw_run = zeros(size(Sest_model));
    Sest_raw_run(:,sample_order) = Sest_model;

    %% ---------------------- Center and align ----------------------------
    M_softml_score_run = M_softml_run - mu_pca;
    M_deep_score_run   = M_deep_run - mu_pca;

    [SOFTML_ERR_RUNS(run_idx), perm_softml] = ...
        best_relative_endmember_error(Mtrue_score, M_softml_score_run);
    M_softml_score_run = M_softml_score_run(:,perm_softml);
    M_softml_run       = M_softml_run(:,perm_softml);

    [DEEP_ERR_RUNS(run_idx), perm_deep] = ...
        best_relative_endmember_error(Mtrue_score, M_deep_score_run);
    M_deep_score_run = M_deep_score_run(:,perm_deep);
    M_deep_run       = M_deep_run(:,perm_deep);
    Sest_raw_run     = Sest_raw_run(perm_deep,:); %#ok<NASGU>

    perm_softml_runs(run_idx,:) = perm_softml;
    perm_deep_runs(run_idx,:)   = perm_deep;

    %% ---------------------- Per-run projected SAD -----------------------
    Msoftml_affine3 = Up' * M_softml_run;
    Mdeep_affine3   = Up' * M_deep_run;

    if size(Msoftml_affine3,1) ~= 3 || size(Mdeep_affine3,1) ~= 3
        error('Run %d: expected 3-D affine SAD coordinates.', run_idx);
    end

    for k = 1:p
        mt = Mtrue_affine3(:,k);

        ms = Msoftml_affine3(:,k);
        cos_soft = (mt' * ms) / max(norm(mt,2) * norm(ms,2), eps);
        cos_soft = max(-1, min(1, cos_soft));
        SOFTML_SAD_DEG_RUNS(run_idx,k) = acosd(cos_soft);

        md = Mdeep_affine3(:,k);
        cos_deep = (mt' * md) / max(norm(mt,2) * norm(md,2), eps);
        cos_deep = max(-1, min(1, cos_deep));
        DEEP_SAD_DEG_RUNS(run_idx,k) = acosd(cos_deep);
    end

    %% ---------------------- Per-run FCLS + LOESS ------------------------
    % Both methods use exactly the same FCLS post-processing in the same
    % 41-D PCA space before the LOESS trend is computed.
    S_softml_fcls_run = fcls_active_set(M_softml_run, Y_pca);
    S_deep_fcls_run   = fcls_active_set(M_deep_run, Y_pca);

    if any(S_softml_fcls_run(:) < -1e-10) || ...
       max(abs(sum(S_softml_fcls_run,1)-1)) > 1e-8
        error('Run %d: invalid Soft-ML FCLS abundance.', run_idx);
    end
    if any(S_deep_fcls_run(:) < -1e-10) || ...
       max(abs(sum(S_deep_fcls_run,1)-1)) > 1e-8
        error('Run %d: invalid DeepMVSA FCLS abundance.', run_idx);
    end

    all_true_run   = S_true(:);
    all_softml_run = S_softml_fcls_run(:);
    all_deep_run   = S_deep_fcls_run(:);

    % Per-run Pearson correlation and MSE.  Their mean and SD across the
    % 20 independent runs are reported after aggregation.
    SOFTML_MSE_RUNS(run_idx) = mean((all_softml_run-all_true_run).^2);
    R_softml_run = corrcoef(all_true_run,all_softml_run);
    if numel(R_softml_run) >= 4
        SOFTML_PEARSON_RUNS(run_idx) = R_softml_run(1,2);
    else
        SOFTML_PEARSON_RUNS(run_idx) = NaN;
    end

    DEEP_MSE_RUNS(run_idx) = mean((all_deep_run-all_true_run).^2);
    R_deep_run = corrcoef(all_true_run,all_deep_run);
    if numel(R_deep_run) >= 4
        DEEP_PEARSON_RUNS(run_idx) = R_deep_run(1,2);
    else
        DEEP_PEARSON_RUNS(run_idx) = NaN;
    end

    loess_softml_runs(run_idx,:) = local_quadratic_loess( ...
        all_true_run, all_softml_run, x_grid, LOESS_SPAN);
    loess_deep_runs(run_idx,:) = local_quadratic_loess( ...
        all_true_run, all_deep_run, x_grid, LOESS_SPAN);

    %% ---------------------- Store aligned run ---------------------------
    M_softml_pca_runs(:,:,run_idx)   = M_softml_run;
    M_deep_pca_runs(:,:,run_idx)     = M_deep_run;
    M_softml_score_runs(:,:,run_idx) = M_softml_score_run;
    M_deep_score_runs(:,:,run_idx)   = M_deep_score_run;

    S_softml_fcls_runs(:,:,run_idx) = S_softml_fcls_run;
    S_deep_fcls_runs(:,:,run_idx)   = S_deep_fcls_run;

    fprintf('Run %02d finished: Soft-ML %.3f s, DeepMVSA %.3f s\n', ...
        run_idx, t_softml_runs(run_idx), t_deep_runs(run_idx));
end

%% ========================== 8. Aggregate 20 runs ========================
% Figure 1 uses the mean aligned simplex and the mean per-endmember SAD over
% the 20 independent runs.
M_softml_pca = mean(M_softml_pca_runs, 3);
M_deep_pca   = mean(M_deep_pca_runs, 3);
M_softml_score = mean(M_softml_score_runs, 3);
M_deep_score   = mean(M_deep_score_runs, 3);

SOFTML_ERR = mean(SOFTML_ERR_RUNS);
DEEP_ERR   = mean(DEEP_ERR_RUNS);
SOFTML_SAD_DEG = mean(SOFTML_SAD_DEG_RUNS, 1);
DEEP_SAD_DEG   = mean(DEEP_SAD_DEG_RUNS, 1);
SOFTML_SAD_SD = std(SOFTML_SAD_DEG_RUNS, 0, 1);
DEEP_SAD_SD   = std(DEEP_SAD_DEG_RUNS, 0, 1);

% Figure-2 run-level metric summaries (mean +/- sample SD over 20 runs).
SOFTML_PEARSON_MEAN = mean(SOFTML_PEARSON_RUNS);
SOFTML_PEARSON_SD   = std(SOFTML_PEARSON_RUNS,0);
SOFTML_MSE_MEAN     = mean(SOFTML_MSE_RUNS);
SOFTML_MSE_SD       = std(SOFTML_MSE_RUNS,0);
DEEP_PEARSON_MEAN   = mean(DEEP_PEARSON_RUNS);
DEEP_PEARSON_SD     = std(DEEP_PEARSON_RUNS,0);
DEEP_MSE_MEAN       = mean(DEEP_MSE_RUNS);
DEEP_MSE_SD         = std(DEEP_MSE_RUNS,0);

t_softml = mean(t_softml_runs);
t_deep   = mean(t_deep_runs);

% Figure 2 scatter uses the run-wise mean FCLS abundance of DeepMVSA, while
% the two center lines are the pointwise mean of the 20 run-level LOESS
% curves.  The same aggregation is used for Soft-ML's mean LOESS line.
S_softml_fcls = mean(S_softml_fcls_runs, 3);
S_deep_fcls   = mean(S_deep_fcls_runs, 3);

all_true   = S_true(:);
all_softml = S_softml_fcls(:);
all_deep   = S_deep_fcls(:);

% Figure-2 quantitative metrics computed from exactly the same 20-run mean
% FCLS abundances used by the plotted scatter/trends.
DEEP_FCLS_MSE = mean((all_deep - all_true).^2);
R_deep_fcls = corrcoef(all_true, all_deep);
if numel(R_deep_fcls) >= 4
    DEEP_FCLS_PEARSON_R = R_deep_fcls(1,2);
else
    DEEP_FCLS_PEARSON_R = NaN;
end

SOFTML_FCLS_MSE = mean((all_softml - all_true).^2);
R_softml_fcls = corrcoef(all_true, all_softml);
if numel(R_softml_fcls) >= 4
    SOFTML_FCLS_PEARSON_R = R_softml_fcls(1,2);
else
    SOFTML_FCLS_PEARSON_R = NaN;
end

y_loess_deep = mean(loess_deep_runs, 1);
y_loess_softml = mean(loess_softml_runs, 1);

% 95% pointwise bootstrap CI of the mean LOESS curve.  The bootstrap unit is
% one complete independent experimental run (one row of loess_*_runs).
[deep_ci_low, deep_ci_high] = bootstrap_mean_curve_ci( ...
    loess_deep_runs, BOOTSTRAP_REPEATS, BOOTSTRAP_SEED_DEEP);
[softml_ci_low, softml_ci_high] = bootstrap_mean_curve_ci( ...
    loess_softml_runs, BOOTSTRAP_REPEATS, BOOTSTRAP_SEED_SOFTML);

%% ========================== 9. Print 20-run summary =====================
fprintf('\n=======================================================================\n');
fprintf('GSE19830 20-RUN END-MEMBER / TISSUE PROFILE COMPARISON\n');
fprintf('Relative error is computed after per-run global permutation alignment.\n');
fprintf('-----------------------------------------------------------------------\n');
fprintf('MVSA     (single deterministic run): Rel. error = %.6e, time = %.3f s\n', ...
    MVSA_ERR, t_mvsa);
fprintf('VCA      (single deterministic run): Rel. error = %.6e, time = %.3f s\n', ...
    VCA_ERR, t_vca);
fprintf('Soft-ML  (20 runs): Rel. error = %.6e +/- %.6e, time = %.3f +/- %.3f s\n', ...
    mean(SOFTML_ERR_RUNS), std(SOFTML_ERR_RUNS), ...
    mean(t_softml_runs), std(t_softml_runs));
fprintf('DeepMVSA (20 runs): Rel. error = %.6e +/- %.6e, time = %.3f +/- %.3f s\n', ...
    mean(DEEP_ERR_RUNS), std(DEEP_ERR_RUNS), ...
    mean(t_deep_runs), std(t_deep_runs));
fprintf('-----------------------------------------------------------------------\n');
fprintf('Mean +/- SD projected SAD over 20 runs (degree):\n');
fprintf('Soft-ML vertex errors:\n');
for k = 1:p
    fprintf('  %-8s: %.4f +/- %.4f\n', ...
        tissue_names{k}, SOFTML_SAD_DEG(k), SOFTML_SAD_SD(k));
end
fprintf('DeepMVSA vertex errors:\n');
for k = 1:p
    fprintf('  %-8s: %.4f +/- %.4f\n', ...
        tissue_names{k}, DEEP_SAD_DEG(k), DEEP_SAD_SD(k));
end
fprintf('-----------------------------------------------------------------------\n');
fprintf('Figure 2 abundance metrics over 20 independent runs (mean +/- SD):\n');
fprintf('DeepMVSA:\n');
fprintf('  Pearson correlation = %.6f +/- %.6f\n', ...
    DEEP_PEARSON_MEAN, DEEP_PEARSON_SD);
fprintf('  MSE                 = %.6e +/- %.6e\n', ...
    DEEP_MSE_MEAN, DEEP_MSE_SD);
fprintf('Soft-ML:\n');
fprintf('  Pearson correlation = %.6f +/- %.6f\n', ...
    SOFTML_PEARSON_MEAN, SOFTML_PEARSON_SD);
fprintf('  MSE                 = %.6e +/- %.6e\n', ...
    SOFTML_MSE_MEAN, SOFTML_MSE_SD);
fprintf('-----------------------------------------------------------------------\n');
fprintf('Aggregate metric from 20-run mean abundance (reported separately):\n');
fprintf('DeepMVSA: Pearson correlation = %.6f, MSE = %.6e\n', ...
    DEEP_FCLS_PEARSON_R, DEEP_FCLS_MSE);
fprintf('Soft-ML : Pearson correlation = %.6f, MSE = %.6e\n', ...
    SOFTML_FCLS_PEARSON_R, SOFTML_FCLS_MSE);
fprintf('=======================================================================\n');

%% ========================================================================
% Figure 1: 20-run mean simplex in the common 2-D PCA visualization
% ========================================================================
% Soft-ML and DeepMVSA vertices shown below are the pointwise means of their
% aligned vertices over 20 independent runs.  The numeric labels are the
% corresponding mean projected SAD values over those 20 runs.

% ---------------- Figure 1 display controls ----------------
SAD_LABEL_FONTSIZE    = 20;
TISSUE_LABEL_FONTSIZE = 20;
LEGEND_FONTSIZE       = 18;
AXIS_LABEL_FONTSIZE   = 21;
AXIS_TICK_FONTSIZE    = 21;
AXIS_PADDING           = 0.10;
Y_TICK_STEP            = 100;

PDF_MARGIN_IN = 0.12;

% Figure 2 font controls.
FIG2_AXIS_LABEL_FONTSIZE = AXIS_LABEL_FONTSIZE;
FIG2_AXIS_TICK_FONTSIZE  = AXIS_TICK_FONTSIZE;
FIG2_LEGEND_FONTSIZE     = LEGEND_FONTSIZE;
FIG2_TITLE_FONTSIZE      = AXIS_LABEL_FONTSIZE;

% Common method colors used consistently in BOTH figures.
% DeepMVSA = blue; Soft-ML = magenta.
DEEP_COLOR    = [0 0 1];
SOFTML_COLOR  = [1 0 1];
CI_FACE_ALPHA = 0.12;

Y2 = Y_score(1:2,:);
Mtrue2 = Mtrue_score(1:2,:);
Mvsa2 = M_mvsa_score(1:2,:); %#ok<NASGU>
Mvca2 = M_vca_score(1:2,:); %#ok<NASGU>
Msoftml2 = M_softml_score(1:2,:);
Mdeep2 = M_deep_score(1:2,:);

closed_idx = [1 2 3 1];

fig_compare = figure( ...
    'Name','GSE19830: 20-run mean 2D simplex comparison', ...
    'Color','w', ...
    'Position',[120 80 900 720]);

configure_pdf_safe_page(fig_compare, PDF_MARGIN_IN);

h_data = plot( ...
    Y2(1,:), Y2(2,:), '.', ...
    'Color',[0.65 0.65 0.65], ...
    'MarkerSize',14);
hold on;

h_true = plot( ...
    Mtrue2(1,closed_idx), ...
    Mtrue2(2,closed_idx), ...
    'k*-', ...
    'LineWidth',2.2, ...
    'MarkerSize',10);

h_softml = plot( ...
    Msoftml2(1,closed_idx), ...
    Msoftml2(2,closed_idx), ...
    '-.', ...
    'Color',SOFTML_COLOR, ...
    'Marker','d', ...
    'LineWidth',1.7, ...
    'MarkerSize',8);

h_deep = plot( ...
    Mdeep2(1,closed_idx), ...
    Mdeep2(2,closed_idx), ...
    '-', ...
    'Color',DEEP_COLOR, ...
    'Marker','^', ...
    'LineWidth',2.4, ...
    'MarkerSize',9, ...
    'MarkerFaceColor',DEEP_COLOR);

all_x_for_label = [Y2(1,:), Mtrue2(1,:), Msoftml2(1,:), Mdeep2(1,:)];
all_y_for_label = [Y2(2,:), Mtrue2(2,:), Msoftml2(2,:), Mdeep2(2,:)];
label_dx = 0.012 * max(max(all_x_for_label)-min(all_x_for_label), 1);
label_dy = 0.012 * max(max(all_y_for_label)-min(all_y_for_label), 1);

h_softml_sad = gobjects(1,p);
h_deep_sad   = gobjects(1,p);

for k = 1:p
    h_softml_sad(k) = text( ...
        Msoftml2(1,k)-label_dx, ...
        Msoftml2(2,k)+label_dy, ...
        sprintf('%.2f', SOFTML_SAD_DEG(k)), ...
        'Interpreter','none', ...
        'FontSize',SAD_LABEL_FONTSIZE, ...
        'FontWeight','bold', ...
        'Color',SOFTML_COLOR, ...
        'HorizontalAlignment','right', ...
        'VerticalAlignment','bottom', ...
        'HitTest','on', ...
        'PickableParts','all', ...
        'ButtonDownFcn',@start_drag_figure1_label);

    h_deep_sad(k) = text( ...
        Mdeep2(1,k)+label_dx, ...
        Mdeep2(2,k)-label_dy, ...
        sprintf('%.2f', DEEP_SAD_DEG(k)), ...
        'Interpreter','none', ...
        'FontSize',SAD_LABEL_FONTSIZE, ...
        'FontWeight','bold', ...
        'Color',DEEP_COLOR, ...
        'HorizontalAlignment','left', ...
        'VerticalAlignment','top', ...
        'HitTest','on', ...
        'PickableParts','all', ...
        'ButtonDownFcn',@start_drag_figure1_label);
end

h_tissue = gobjects(1,p);
for k = 1:p
    h_tissue(k) = text( ...
        Mtrue2(1,k), ...
        Mtrue2(2,k), ...
        ['  ' tissue_names{k}], ...
        'FontSize',TISSUE_LABEL_FONTSIZE, ...
        'FontWeight','bold', ...
        'Color','k', ...
        'Interpreter','none', ...
        'HitTest','on', ...
        'PickableParts','all', ...
        'ButtonDownFcn',@start_drag_figure1_label);
end

xlabel(sprintf('PC1 (%.1f%%)', 100*explained_energy(1)), ...
    'FontSize', AXIS_LABEL_FONTSIZE);
ylabel(sprintf('PC2 (%.1f%%)', 100*explained_energy(2)), ...
    'FontSize', AXIS_LABEL_FONTSIZE);
title(sprintf('GSE19830: mean tissue simplexes over %d runs', N_RUNS));

h_legend = legend( ...
    [h_data,h_true,h_softml,h_deep], ...
    {'Data','Ground Truth','Soft-ML','DeepMVSA'}, ...
    'Location','best');
set(h_legend, 'FontSize', LEGEND_FONTSIZE);

ax = gca;
ax.FontSize = AXIS_TICK_FONTSIZE;
ax.XAxisLocation = 'bottom';
ax.YAxisLocation = 'left';

grid on;
box on;
axis equal;

all_x_axis = [Y2(1,:), Mtrue2(1,:), Msoftml2(1,:), Mdeep2(1,:)];
all_y_axis = [Y2(2,:), Mtrue2(2,:), Msoftml2(2,:), Mdeep2(2,:)];

x_min = min(all_x_axis);
x_max = max(all_x_axis);
y_min = min(all_y_axis);
y_max = max(all_y_axis);

x_range = x_max - x_min;
y_range = y_max - y_min;
if x_range <= eps
    x_range = max(max(abs(all_x_axis)), 1);
end
if y_range <= eps
    y_range = max(max(abs(all_y_axis)), 1);
end

xlim([x_min - AXIS_PADDING*x_range, x_max + AXIS_PADDING*x_range]);
ylim([y_min - AXIS_PADDING*y_range, y_max + AXIS_PADDING*y_range]);

yl = ylim;
y_tick_start = ceil(yl(1)/Y_TICK_STEP) * Y_TICK_STEP;
y_tick_end   = floor(yl(2)/Y_TICK_STEP) * Y_TICK_STEP;
if y_tick_start <= y_tick_end
    yticks(y_tick_start:Y_TICK_STEP:y_tick_end);
end
hold off;

%% ========================================================================
% Figure 2: 20-run mean LOESS trends with 95% bootstrap confidence bands
% ========================================================================
% Two center lines are retained: DeepMVSA and Soft-ML mean LOESS trends.
% Each shaded band is a 95% pointwise bootstrap CI for the corresponding
% mean LOESS trend, obtained by resampling the 20 independent run-level
% LOESS curves with replacement.  Figure 2 uses two independent legends:
% one for samples/curves and one dedicated to the two CI bands.

% Figure-2-specific method colors. Keep Figure 1 unchanged.
FIG2_DEEP_COLOR = [0 0 0.45];  % dark navy blue for stronger line/band contrast

fig_weight = figure( ...
    'Name','GSE19830: 20-run mean LOESS comparison', ...
    'Color','w', ...
    'Position',[1050 120 720 650]);
configure_pdf_safe_page(fig_weight, PDF_MARGIN_IN);

hold on;

% Same hue as each center line; low alpha makes the band much lighter.
h_ci_deep = fill( ...
    [x_grid, fliplr(x_grid)], ...
    [deep_ci_low, fliplr(deep_ci_high)], ...
    FIG2_DEEP_COLOR, ...
    'FaceAlpha', CI_FACE_ALPHA, ...
    'EdgeColor','none', ...
    'HandleVisibility','off'); %#ok<NASGU>

h_ci_softml = fill( ...
    [x_grid, fliplr(x_grid)], ...
    [softml_ci_low, fliplr(softml_ci_high)], ...
    SOFTML_COLOR, ...
    'FaceAlpha', CI_FACE_ALPHA, ...
    'EdgeColor','none', ...
    'HandleVisibility','off'); %#ok<NASGU>

h_identity = plot( ...
    [0 1],[0 1], ...
    'r-', ...
    'LineWidth',2);

h_loess_deep = plot( ...
    x_grid, y_loess_deep, ...
    '-', ...
    'Color',FIG2_DEEP_COLOR, ...
    'LineWidth',0.7);

h_loess_softml = plot( ...
    x_grid, y_loess_softml, ...
    '--', ...
    'Color',SOFTML_COLOR, ...
    'LineWidth',0.7);

% Scatter points use the 20-run mean DeepMVSA FCLS abundance.  Keeping one
% scatter layer avoids obscuring the two LOESS curves and their CI bands.
h_scatter = scatter( ...
    all_true, all_deep, ...
    34, 'k', 'filled');

xlabel('Real weights', 'FontSize', FIG2_AXIS_LABEL_FONTSIZE);
ylabel('Estimated weights', 'FontSize', FIG2_AXIS_LABEL_FONTSIZE);
title(sprintf('Mean LOESS trends over %d runs', N_RUNS), ...
    'FontSize', FIG2_TITLE_FONTSIZE);

ax2 = gca;
ax2.FontSize = FIG2_AXIS_TICK_FONTSIZE;

xlim([0 1]);
ylim([0 1]);
axis square;
grid on;
box on;

% Reserve space below the main axes for a SECOND, independent legend that
% identifies the two 95% bootstrap confidence bands.
ax2_pos = ax2.Position;
ax2.Position = [ax2_pos(1), ax2_pos(2)+0.075, ...
                ax2_pos(3), max(ax2_pos(4)-0.075,0.1)];

% Legend 1: samples, identity line, and the two mean LOESS curves.
% The CI fills themselves remain excluded from this legend.
h_legend2 = legend( ...
    ax2, ...
    [h_scatter,h_identity,h_loess_deep,h_loess_softml], ...
    {'Samples (DeepMVSA mean)','Y = X', ...
     'DeepMVSA mean LOESS','Soft-ML mean LOESS'}, ...
    'Location','best');
set(h_legend2, 'FontSize', FIG2_LEGEND_FONTSIZE);

% Legend 2: a separate CI legend. MATLAB permits only one legend per axes,
% so use a transparent overlay axes containing two dummy patches.  The
% legend itself is made independently draggable with a figure-level mouse
% callback; dragging changes only h_legend_ci.Position and never the data.
ax_ci_legend = axes( ...
    'Parent',fig_weight, ...
    'Position',ax2.Position, ...
    'Color','none', ...
    'XColor','none', ...
    'YColor','none', ...
    'XTick',[], ...
    'YTick',[], ...
    'XLim',[0 1], ...
    'YLim',[0 1], ...
    'XLimMode','manual', ...
    'YLimMode','manual', ...
    'Box','off', ...
    'HitTest','off', ...
    'PickableParts','none');
hold(ax_ci_legend,'on');

% Finite dummy patches are placed outside the overlay-axes limits.  They are
% therefore invisible in the plot but reliably generate colored legend keys
% across MATLAB releases.
h_ci_legend_deep = patch( ...
    ax_ci_legend, ...
    [2 3 3 2], [2 2 3 3], FIG2_DEEP_COLOR, ...
    'FaceAlpha',CI_FACE_ALPHA, ...
    'EdgeColor','none');

h_ci_legend_softml = patch( ...
    ax_ci_legend, ...
    [2 3 3 2], [2 2 3 3], SOFTML_COLOR, ...
    'FaceAlpha',CI_FACE_ALPHA, ...
    'EdgeColor','none');

h_legend_ci = legend( ...
    ax_ci_legend, ...
    [h_ci_legend_deep,h_ci_legend_softml], ...
    {'DeepMVSA 95% bootstrap CI','Soft-ML 95% bootstrap CI'}, ...
    'Orientation','vertical', ...
    'NumColumns',1);
set(h_legend_ci, ...
    'FontSize',max(FIG2_LEGEND_FONTSIZE-2,8), ...
    'Box','on', ...
    'Units','normalized');

% Give the second legend a visible initial position inside the figure while
% preserving the automatically computed legend width and height.  The user
% can subsequently drag it anywhere in the figure with the mouse.
drawnow;
ci_legend_pos = h_legend_ci.Position;
ci_legend_pos(1) = 0.53;
ci_legend_pos(2) = 0.12;
h_legend_ci.Position = ci_legend_pos;

% Keep the transparent axes (and therefore its legend) above the main axes.
hold(ax_ci_legend,'off');
uistack(ax_ci_legend,'top');

% Make CI legend draggable.  The callback first checks whether the mouse-down
% point lies inside h_legend_ci, so normal interaction with the rest of the
% figure and the native main legend is unaffected.
fig_weight.WindowButtonDownFcn = ...
    @(fig,event) start_drag_ci_legend(fig,event,h_legend_ci);

hold(ax2,'off');

%% ========================== 10. Finish ==================================
fprintf('\n================ Experiment finished =================\n');
fprintf('Figure 1: 20-run mean aligned simplexes and mean SAD labels.\n');
fprintf('Figure 2: 20-run mean LOESS curves with run-level 95%% bootstrap CIs.\n');
fprintf('Figures are displayed only; no images or data files were saved.\n');
fprintf('======================================================\n');

%% ========================================================================
% Local function 0: manually drag Figure-1 text labels
% ========================================================================
function start_drag_figure1_label(h_text, ~)
%START_DRAG_FIGURE1_LABEL
% Mouse-down callback shared by Liver/Brain/Kidney labels and all SAD
% numeric labels.  Only the selected text object's Position changes.

fig = ancestor(h_text, 'figure');
if isempty(fig) || ~isgraphics(fig)
    return;
end

% Preserve any pre-existing figure mouse callbacks and restore them after
% this drag operation finishes.
setappdata(fig, 'Figure1TextDragOldMotionFcn', fig.WindowButtonMotionFcn);
setappdata(fig, 'Figure1TextDragOldUpFcn', fig.WindowButtonUpFcn);
setappdata(fig, 'Figure1TextDragHandle', h_text);

fig.WindowButtonMotionFcn = @drag_figure1_label;
fig.WindowButtonUpFcn = @stop_drag_figure1_label;
end

function drag_figure1_label(fig, ~)
%DRAG_FIGURE1_LABEL Move the active text label to the mouse position.

if ~isgraphics(fig)
    return;
end

if ~isappdata(fig, 'Figure1TextDragHandle')
    return;
end

h_text = getappdata(fig, 'Figure1TextDragHandle');
if isempty(h_text) || ~isgraphics(h_text)
    return;
end

ax = ancestor(h_text, 'axes');
if isempty(ax) || ~isgraphics(ax)
    return;
end

cp = ax.CurrentPoint;
pos = h_text.Position;
pos(1) = cp(1,1);
pos(2) = cp(1,2);
h_text.Position = pos;
end

function stop_drag_figure1_label(fig, ~)
%STOP_DRAG_FIGURE1_LABEL Finish dragging and restore old callbacks.

if isempty(fig) || ~isgraphics(fig)
    return;
end

old_motion = [];
old_up = [];

if isappdata(fig, 'Figure1TextDragOldMotionFcn')
    old_motion = getappdata(fig, 'Figure1TextDragOldMotionFcn');
end
if isappdata(fig, 'Figure1TextDragOldUpFcn')
    old_up = getappdata(fig, 'Figure1TextDragOldUpFcn');
end

fig.WindowButtonMotionFcn = old_motion;
fig.WindowButtonUpFcn = old_up;

if isappdata(fig, 'Figure1TextDragHandle')
    rmappdata(fig, 'Figure1TextDragHandle');
end
if isappdata(fig, 'Figure1TextDragOldMotionFcn')
    rmappdata(fig, 'Figure1TextDragOldMotionFcn');
end
if isappdata(fig, 'Figure1TextDragOldUpFcn')
    rmappdata(fig, 'Figure1TextDragOldUpFcn');
end
end


%% ========================================================================
% Local function 0b: manually drag Figure-2 CI legend
% ========================================================================
function start_drag_ci_legend(fig, ~, h_legend)
%START_DRAG_CI_LEGEND Start dragging the second (bootstrap-CI) legend.
% The legend position is stored in normalized figure coordinates, so the
% interaction remains well behaved if the figure is resized.

if isempty(fig) || ~isgraphics(fig) || ...
        isempty(h_legend) || ~isgraphics(h_legend)
    return;
end

% Figure CurrentPoint is reported in pixels.  Convert it to normalized
% coordinates to compare directly with the legend's normalized Position.
cp_px = fig.CurrentPoint;
fig_px = getpixelposition(fig);
if fig_px(3) <= 0 || fig_px(4) <= 0
    return;
end
cp = [cp_px(1)/fig_px(3), cp_px(2)/fig_px(4)];

old_units = h_legend.Units;
h_legend.Units = 'normalized';
pos = h_legend.Position;
h_legend.Units = old_units;

inside = cp(1) >= pos(1) && cp(1) <= pos(1)+pos(3) && ...
         cp(2) >= pos(2) && cp(2) <= pos(2)+pos(4);
if ~inside
    return;
end

% Preserve any callbacks that were already installed on the figure.
setappdata(fig,'CILegendDragOldMotionFcn',fig.WindowButtonMotionFcn);
setappdata(fig,'CILegendDragOldUpFcn',fig.WindowButtonUpFcn);
setappdata(fig,'CILegendDragHandle',h_legend);
setappdata(fig,'CILegendDragOffset',[cp(1)-pos(1), cp(2)-pos(2)]);

fig.WindowButtonMotionFcn = @drag_ci_legend;
fig.WindowButtonUpFcn = @stop_drag_ci_legend;
end

function drag_ci_legend(fig, ~)
%DRAG_CI_LEGEND Move the CI legend while the mouse button is held down.

if isempty(fig) || ~isgraphics(fig) || ...
        ~isappdata(fig,'CILegendDragHandle') || ...
        ~isappdata(fig,'CILegendDragOffset')
    return;
end

h_legend = getappdata(fig,'CILegendDragHandle');
if isempty(h_legend) || ~isgraphics(h_legend)
    return;
end

offset = getappdata(fig,'CILegendDragOffset');
cp_px = fig.CurrentPoint;
fig_px = getpixelposition(fig);
if fig_px(3) <= 0 || fig_px(4) <= 0
    return;
end
cp = [cp_px(1)/fig_px(3), cp_px(2)/fig_px(4)];

old_units = h_legend.Units;
h_legend.Units = 'normalized';
pos = h_legend.Position;

% Clamp the legend to the visible figure area while preserving its size.
pos(1) = min(max(cp(1)-offset(1),0), max(1-pos(3),0));
pos(2) = min(max(cp(2)-offset(2),0), max(1-pos(4),0));
h_legend.Position = pos;
h_legend.Units = old_units;

drawnow limitrate;
end

function stop_drag_ci_legend(fig, ~)
%STOP_DRAG_CI_LEGEND Finish dragging and restore the previous callbacks.

if isempty(fig) || ~isgraphics(fig)
    return;
end

old_motion = [];
old_up = [];
if isappdata(fig,'CILegendDragOldMotionFcn')
    old_motion = getappdata(fig,'CILegendDragOldMotionFcn');
end
if isappdata(fig,'CILegendDragOldUpFcn')
    old_up = getappdata(fig,'CILegendDragOldUpFcn');
end

fig.WindowButtonMotionFcn = old_motion;
fig.WindowButtonUpFcn = old_up;

keys = {'CILegendDragHandle','CILegendDragOffset', ...
        'CILegendDragOldMotionFcn','CILegendDragOldUpFcn'};
for ii = 1:numel(keys)
    if isappdata(fig,keys{ii})
        rmappdata(fig,keys{ii});
    end
end
end

%% ========================================================================
% Local function 1: global optimal endmember permutation
% ========================================================================
function [best_err,best_perm] = ...
    best_relative_endmember_error(Mtrue,Mest)

p_local = size(Mtrue,2);

if size(Mest,2) ~= p_local
    error('Mtrue and Mest must have the same number of columns.');
end

Pset = perms(1:p_local);

best_err = inf;
best_perm = 1:p_local;

denom = norm(Mtrue,'fro') + eps;

for r = 1:size(Pset,1)

    perm = Pset(r,:);

    err = ...
        norm(Mtrue-Mest(:,perm),'fro') / denom;

    if err < best_err
        best_err = err;
        best_perm = perm;
    end
end
end

%% ========================================================================
% Local function 2: toolbox-independent active-set FCLS
% ========================================================================
function S = fcls_active_set(M,Y)
% Solve, column by column,
%   min_s ||y-Ms||_2^2  s.t. s>=0 and 1^T s=1.
%
% For the present p=3 problem, enumerating all nonempty active supports is
% exact, inexpensive, and does not require Optimization Toolbox.  The same
% implementation is also valid for other small p.

[L_local,p_local] = size(M);
[L_y,N_local] = size(Y);
if L_y ~= L_local
    error('M and Y must have the same number of rows.');
end

S = zeros(p_local,N_local);
tol = 1e-10;

for n = 1:N_local
    y = Y(:,n);
    best_obj = inf;
    best_a = [];

    for mask = 1:(2^p_local-1)
        idx = find(bitget(mask,1:p_local));
        MS = M(:,idx);

        % Equality-constrained LS on the current active face:
        %   min ||y-MS*aS||^2,  subject to 1^T aS = 1.
        G = MS' * MS;
        c = MS' * y;
        Aeq = ones(1,numel(idx));
        KKT = [G, Aeq'; Aeq, 0];
        rhs = [c; 1];

        if rcond(KKT) < 1e-12
            sol = pinv(KKT) * rhs;
        else
            sol = KKT \ rhs;
        end

        aS = sol(1:numel(idx));

        % The optimum for this face is feasible only if active weights are
        % nonnegative (up to numerical tolerance).
        if all(aS >= -tol)
            aS = max(aS,0);
            suma = sum(aS);
            if suma <= eps
                continue;
            end
            aS = aS / suma;

            a = zeros(p_local,1);
            a(idx) = aS;
            obj = norm(y - M*a, 2)^2;

            if obj < best_obj
                best_obj = obj;
                best_a = a;
            end
        end
    end

    % A singleton support is always feasible, so this branch should never
    % be reached unless the input contains invalid numerical values.
    if isempty(best_a)
        error('FCLS failed to find a feasible abundance for sample %d.', n);
    end

    S(:,n) = best_a;
end
end

%% ========================================================================
% Local function 3: toolbox-independent LOESS fit (local quadratic)
% ========================================================================
function yq = local_quadratic_loess(x,y,xq,span)

x = x(:);
y = y(:);
xq = xq(:);

n = numel(x);
k_neigh = max(4,ceil(span*n));

yq = zeros(size(xq));

for i = 1:numel(xq)

    x0 = xq(i);

    d = abs(x-x0);
    ds = sort(d);

    h = ds(min(k_neigh,n));

    if h <= eps
        h = max(d);
    end

    if h <= eps
        yq(i) = mean(y);
        continue;
    end

    r = d/h;

    w = zeros(n,1);
    inside = r < 1;

    w(inside) = ...
        (1-r(inside).^3).^3;

    if sum(w) <= eps
        [~,idx] = min(d);
        yq(i) = y(idx);
        continue;
    end

    % LOESS local quadratic model around x0:
    %   y ~= beta0 + beta1*(x-x0) + beta2*(x-x0)^2.
    % The fitted value at x0 is beta0.
    dx = x-x0;
    X = [ones(n,1), dx, dx.^2];
    W = diag(w);

    beta = ...
        (X'*W*X + 1e-10*eye(3)) \ ...
        (X'*W*y);

    yq(i) = beta(1);
end

yq = max(0,min(1,yq));
yq = yq(:)';
end

%% ========================================================================
% Local function 4: bootstrap CI for a mean run-level LOESS curve
% ========================================================================
function [ci_low,ci_high] = ...
    bootstrap_mean_curve_ci(curves,n_boot,seed)
%BOOTSTRAP_MEAN_CURVE_CI
% curves is N_RUNS x N_GRID.  One entire row is one independent experiment.
% Resample rows with replacement, compute the mean curve for each bootstrap
% sample, then take the 2.5th and 97.5th pointwise percentiles.

if ndims(curves) ~= 2 || isempty(curves)
    error('curves must be a nonempty N_RUNS-by-N_GRID matrix.');
end
if n_boot < 1 || n_boot ~= floor(n_boot)
    error('n_boot must be a positive integer.');
end

[n_runs,n_grid] = size(curves);
boot_mean_curves = zeros(n_boot,n_grid);

rng_state_before_bootstrap = rng;
rng(seed,'twister');

for b = 1:n_boot
    idx = randi(n_runs,1,n_runs);
    boot_mean_curves(b,:) = mean(curves(idx,:),1);
end

rng(rng_state_before_bootstrap);

ci_low = empirical_percentile_columns(boot_mean_curves,2.5);
ci_high = empirical_percentile_columns(boot_mean_curves,97.5);

ci_low = max(0,min(1,ci_low));
ci_high = max(0,min(1,ci_high));
end

%% ========================================================================
% Local function 5: percentile across rows, toolbox-independent
% ========================================================================
function q = empirical_percentile_columns(X,pct)

if pct < 0 || pct > 100
    error('Percentile must be between 0 and 100.');
end

Xs = sort(X,1);
n = size(Xs,1);

if n == 0
    error('Cannot compute a percentile of an empty matrix.');
end

if n == 1
    q = Xs(1,:);
    return;
end

pos = 1 + (n-1)*(pct/100);
lo = floor(pos);
hi = ceil(pos);
w = pos-lo;

if lo == hi
    q = Xs(lo,:);
else
    q = (1-w)*Xs(lo,:) + w*Xs(hi,:);
end
end

%% ========================================================================
% Local function 6: PDF-safe paper geometry for Save As / print -dpdf
% ========================================================================
function configure_pdf_safe_page(fig, margin_in)
%CONFIGURE_PDF_SAFE_PAGE Prevent edge clipping when saving a MATLAB figure
% as PDF through File -> Save As or print(...,'-dpdf').
%
% The on-screen figure size is preserved.  We only make the PDF paper size
% match the current figure's physical width/height and add a small symmetric
% safety margin, so PaperPosition never starts at a negative x/y location.

if nargin < 2 || isempty(margin_in)
    margin_in = 0.12;
end

if ~isgraphics(fig, 'figure')
    error('configure_pdf_safe_page expects a valid figure handle.');
end

if ~isscalar(margin_in) || ~isfinite(margin_in) || margin_in < 0
    error('margin_in must be a finite nonnegative scalar.');
end

% Convert the current on-screen figure size to inches without changing how
% the figure appears on screen.
old_units = fig.Units;
fig.Units = 'inches';
pos_in = fig.Position;
fig.Units = old_units;

fig_w = pos_in(3);
fig_h = pos_in(4);

% Explicit custom PDF page.  In particular, PaperPosition(1:2) are positive,
% which avoids the negative-left-edge situation that causes clipping.
fig.PaperUnits = 'inches';
fig.PaperPositionMode = 'manual';
fig.PaperSize = [fig_w + 2*margin_in, fig_h + 2*margin_in];
fig.PaperPosition = [margin_in, margin_in, fig_w, fig_h];
end
