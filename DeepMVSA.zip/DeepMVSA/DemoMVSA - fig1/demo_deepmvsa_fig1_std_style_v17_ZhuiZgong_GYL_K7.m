%% demo_deepmvsa_figure1_singleK_dtv_scaling_v5
% Figure 1: single-K statistical convergence experiment for DeepMVSA.
%
% MANUAL CONTROL
%   This script runs ONE simplex dimension K per execution.
%   Change only K below when you want to run another case, e.g.
%       K = 2;   % 3 vertices
%       K = 5;   % 6 vertices
%       K = 10;  % 11 vertices
%
% Experimental design
%   p = K+1 simplex vertices.
%   One fixed regular ground-truth K-simplex for the selected K.
%   N in {1e2,1e3,1e4,1e5,1e6,1e7,1e8}.
%   R = 10 independent paired repetitions.
%   Within each repetition, all N values use one conceptual master random
%   sequence. Re-seeding with the SAME data seed before each N means that
%   the smaller dataset is exactly the prefix of the larger dataset:
%       Y_N1 = Y_N2(:,1:N1),  for N1 < N2.
%   Thus, within a repetition, the true simplex, sampled observations already
%   present, model seed, and D_TV Monte-Carlo seed are held fixed; only N grows.
%   Noiseless uniform simplex sampling:
%       a_j ~ Dirichlet(1,...,1), y_j = M_true*a_j.
%   DeepMVSA: 400 warm-up + 1100 joint = 1500 iterations, LR=1e-3,
%             LAMBDA_ENCLOSE=10.
%
% IMPORTANT MEMORY NOTE
%   The script does NOT materialize a full N_max=1e8 master dataset. For each
%   requested N it regenerates only the first N samples from the same seeded
%   random sequence. This is mathematically equivalent to taking prefixes of
%   one conceptual master dataset, while avoiding storage of Y_max.
%
% D_TV evaluation
%   IMPORTANT: D_TV is not redesigned here. The local functions
%   tv_dist_simplex() and in_simplex() at the end of this file retain the
%   executable statements from the user-provided
%   demo_deepmvsa_usgs_invflow_tv.m. For each trial, dataProj(...,'affine')
%   supplies the common evaluation coordinates, followed by
%       Mtrue = Up_eval' * M_true;
%       Mdeep = Up_eval' * M_est;
%
% Output
%   One figure for the selected K only: mean D_TV versus N (no error bars),
%   fitted log-log slope, and an N^{-1/2} reference line.
%   No .mat or .csv files are written.

clearvars; clc; close all;

%% ===================== Manual experiment setting =====================
K = 7;                              % <<< MANUALLY change to 5 or 10
p = K + 1;
%N_VALUES = [1e2 1e3 1e4 1e5 1e6 1e7 1e8];
N_VALUES = [1e7];
N_REPEATS = 10;
DTV_MC_SAMPLES = 1e5;

%% ===================== Figure appearance =====================
% Publication-style color theme. Change only this string to switch styles:
%   'cyan'     : pale cyan / blue-green background (default)
%   'lavender' : pale lavender / purple background
PLOT_THEME = 'cyan';

% ---------------- Figure font controls ----------------
% Match demo_deepmvsa_figure1_dtv_SE_v17_GYL.m.
AXIS_TICK_FONTSIZE  = 30;   % 横纵轴刻度字体
AXIS_LABEL_FONTSIZE = 30;   % 横纵轴标题字体
LEGEND_FONTSIZE     = 28;   % 图例字体
TITLE_FONTSIZE      = 16;   % figure title
% ------------------------------------------------------

if ~isscalar(K) || K < 2 || K ~= floor(K)
    error('K must be an integer >= 2.');
end

% Reproducibility seeds. Each repetition gets one data/model/MC seed.
% The same three seeds are reused for every N within that repetition so the
% comparison is paired across sample sizes.
DATA_SEED_BASE  = 310000;
MODEL_SEED_BASE = 750000;
MC_SEED_BASE    = 910000;

%% ===================== DeepMVSA settings =====================
DEEP_MM_ITERS       = 4000;
DEEP_WARM_UP        = 400;
DEEP_LR             = 1e-3;
DEEP_LAMBDA_VOL     = 0.01;
DEEP_LAMBDA_NONNEG  = 5;
DEEP_LAMBDA_EQ      = 80;
DEEP_LAMBDA_SUMONE  = 2;
DEEP_LAMBDA_ENCLOSE = 2.5;

%% ===================== Dependency checks =====================
required_functions = {'deep_mvsa_invflow','VCA','dataProj'};
for ii = 1:numel(required_functions)
    if isempty(which(required_functions{ii}))
        error('Required function not found on MATLAB path: %s', required_functions{ii});
    end
end

fprintf('Using DeepMVSA : %s\n', which('deep_mvsa_invflow'));
fprintf('Using VCA      : %s\n', which('VCA'));
fprintf('Using dataProj : %s\n', which('dataProj'));

fprintf('\n=====================================================================\n');
fprintf('FIGURE 1: SINGLE-K DEEPMVSA D_TV SCALING EXPERIMENT\n');
fprintf('=====================================================================\n');
fprintf('Selected K                  : %d\n', K);
fprintf('Number of vertices p        : %d\n', p);
fprintf('N values                    : %s\n', mat2str(N_VALUES));
fprintf('Independent repetitions     : %d\n', N_REPEATS);
fprintf('D_TV MC samples per simplex : %d\n', DTV_MC_SAMPLES);
fprintf('Data model                   : noiseless Uniform(S_T)\n');
fprintf('Sampling across N            : nested prefixes, paired by repetition\n');
fprintf('DeepMVSA iterations          : %d (%d warm-up + %d joint)\n', ...
    DEEP_MM_ITERS, DEEP_WARM_UP, DEEP_MM_ITERS-DEEP_WARM_UP);
fprintf('=====================================================================\n\n');

%% ===================== Ground-truth simplex =====================
% Standard regular K-simplex embedded in R^(K+1).
% Columns e_1,...,e_p are equidistant, and the affine hull has intrinsic
% dimension K=p-1. The same M_true is used for every N and repetition.
M_true = eye(p);

fprintf('Ground truth: fixed regular simplex M_true = eye(%d)\n', p);
fprintf('Ambient dimension L = %d\n\n', p);

%% ===================== Allocate in-memory results =====================
nN = numel(N_VALUES);

% Rows are independent repetitions; columns are sample sizes N_VALUES.
% This layout makes the paired/nested design explicit.
dtv_matrix = nan(N_REPEATS,nN);
runtime_matrix = nan(N_REPEATS,nN);

dtv_mean = nan(1,nN);
dtv_std = nan(1,nN);
dtv_all = cell(1,nN);
runtime_mean = nan(1,nN);
runtime_std = nan(1,nN);

n_total_runs = nN*N_REPEATS;
n_completed_runs = 0;
experiment_tic = tic;

%% ===================== Main paired/nested single-K experiment =====================
% Each repetition represents one conceptual master sample sequence up to
% N_max=max(N_VALUES). We do not store that master sequence. Instead, for
% every N we reset to the same data seed and regenerate only its first N
% samples. Therefore, within a repetition, datasets are exact nested prefixes.
for ir = 1:N_REPEATS
    data_seed  = DATA_SEED_BASE  + ir;
    model_seed = MODEL_SEED_BASE + ir;
    mc_seed    = MC_SEED_BASE    + ir;

    fprintf('\n=====================================================================\n');
    fprintf('PAIRED REPETITION %d/%d | K=%d | p=%d\n', ir, N_REPEATS, K, p);
    fprintf('data/model/MC seeds = %d / %d / %d\n', ...
        data_seed, model_seed, mc_seed);
    fprintf('=====================================================================\n');

    for in = 1:nN
        N = N_VALUES(in);
        trial_tic = tic;

        %% -------- Nested prefix from one conceptual master dataset --------
        % Reusing data_seed for every N is intentional. MATLAB's deterministic
        % random stream then guarantees that rand(p,N1) reproduces the first
        % N1 columns of rand(p,N2) whenever N1 < N2. Thus no new realization
        % replaces the old samples when N increases; only additional samples
        % are appended conceptually.
        rng(data_seed,'twister');
        G = -log(rand(p, N));
        A_true = G ./ repmat(sum(G, 1), p, 1);
        Y = M_true * A_true;

        %% -------- Common affine evaluation coordinates --------
        % Match demo_deepmvsa_usgs_invflow_tv.m for D_TV evaluation.
        [~, Up_eval, ~, ~] = dataProj(Y, p, 'proj_type', 'affine');

        %% -------- DeepMVSA estimation with paired model seed --------
        % The same model seed is reused at all N within this repetition so
        % initialization randomness is paired; the data size is the intended
        % changing factor.
        rng(model_seed,'twister');
        [M_est, ~, ~, ~, ~] = deep_mvsa_invflow( ...
            Y, p, ...
            'spherize', 'yes', ...
            'verbose', 0, ...
            'MM_ITERS', DEEP_MM_ITERS, ...
            'WARM_UP', DEEP_WARM_UP, ...
            'LR', DEEP_LR, ...
            'LAMBDA_VOL', DEEP_LAMBDA_VOL, ...
            'LAMBDA_NONNEG', DEEP_LAMBDA_NONNEG, ...
            'LAMBDA_EQ', DEEP_LAMBDA_EQ, ...
            'LAMBDA_SUMONE', DEEP_LAMBDA_SUMONE, ...
            'LAMBDA_ENCLOSE', DEEP_LAMBDA_ENCLOSE,...
            'BATCH_SIZE', 4096);

        if any(~isfinite(M_est(:)))
            error('DeepMVSA returned NaN/Inf at K=%d, N=%d, repeat=%d.', ...
                K, N, ir);
        end

        %% -------- D_TV: user-provided evaluation protocol --------
        Mtrue = Up_eval' * M_true;
        Mdeep = Up_eval' * M_est;

        % Reuse the same MC seed across N within the repetition. This keeps the
        % Monte-Carlo evaluation paired as well; the D_TV formula itself is
        % unchanged.
        rng(mc_seed,'twister');
        dtv_matrix(ir,in) = tv_dist_simplex(Mtrue, Mdeep, DTV_MC_SAMPLES);
        runtime_matrix(ir,in) = toc(trial_tic);

        if ~isfinite(dtv_matrix(ir,in)) || ...
                dtv_matrix(ir,in) < 0 || dtv_matrix(ir,in) > 1
            error('Invalid D_TV at K=%d, N=%d, repeat=%d: %.8g', ...
                K, N, ir, dtv_matrix(ir,in));
        end

        clear A_true G Y M_est Mtrue Mdeep Up_eval;

        n_completed_runs = n_completed_runs + 1;
        elapsed_sec = toc(experiment_tic);
        eta_sec = elapsed_sec/n_completed_runs * ...
            (n_total_runs-n_completed_runs);

        fprintf(['  N=%-10d | D_TV=%.6f | time=%.2f s | ' ...
                 'overall %d/%d | ETA %.2f h\n'], ...
            N, dtv_matrix(ir,in), runtime_matrix(ir,in), ...
            n_completed_runs, n_total_runs, eta_sec/3600);
    end
end

%% ===================== Aggregate paired repetitions =====================
dtv_mean = mean(dtv_matrix,1);
dtv_std = std(dtv_matrix,0,1);
runtime_mean = mean(runtime_matrix,1);
runtime_std = std(runtime_matrix,0,1);

for in = 1:nN
    dtv_all{in} = dtv_matrix(:,in).';
    fprintf('\nN=%d | Mean D_TV=%.6f | Std=%.6f | Mean runtime=%.2f s | Std=%.2f s\n', ...
        N_VALUES(in), dtv_mean(in), dtv_std(in), ...
        runtime_mean(in), runtime_std(in));
end

%% ===================== Log-log slope fit =====================
% Exact MC zeros cannot be logged. A half-count floor is used only for
% fitting and plotting; the original dtv_mean values remain unchanged.
dtv_floor = 0.5/DTV_MC_SAMPLES;
y_fit = max(dtv_mean,dtv_floor);

coeff = polyfit(log10(N_VALUES),log10(y_fit),1);
fitted_slope = coeff(1);

y_hat = polyval(coeff,log10(N_VALUES));
y_obs = log10(y_fit);
ss_res = sum((y_obs-y_hat).^2);
ss_tot = sum((y_obs-mean(y_obs)).^2);
if ss_tot > 0
    fitted_r2 = 1-ss_res/ss_tot;
else
    fitted_r2 = NaN;
end

%% ===================== Command-window summary =====================
total_experiment_sec = toc(experiment_tic);

fprintf('\n\n=====================================================================\n');
fprintf('FIGURE 1: SINGLE-K D_TV SCALING SUMMARY\n');
fprintf('=====================================================================\n');
fprintf('K              : %d\n', K);
fprintf('p              : %d\n', p);
fprintf('Sampling design: fixed simplex + nested prefixes + paired seeds\n');
fprintf('N values       : %s\n', mat2str(N_VALUES));
fprintf('Mean D_TV      : %s\n', mat2str(dtv_mean,6));
fprintf('Std D_TV       : %s\n', mat2str(dtv_std,6));
fprintf('Fitted slope   : %.6f\n', fitted_slope);
fprintf('Fit R^2        : %.6f\n', fitted_r2);
fprintf('Reference slope: -0.500000\n');
fprintf('Total experiment time: %.2f s (%.2f h)\n', ...
    total_experiment_sec,total_experiment_sec/3600);
fprintf('No .mat or .csv files were written.\n');
fprintf('=====================================================================\n\n');

%% ===================== Figure 1: selected K only =====================
% Publication-style white background with a pale-cyan transparent
% Mean +/- 1 std band. Only the appearance changes; all plotted values,
% fitted slopes, axis scales, and D_TV calculations are unchanged.
switch lower(strtrim(PLOT_THEME))
    case 'cyan'
        fig_bg       = [1.000 1.000 1.000];   % white figure background
        axes_bg      = [1.000 1.000 1.000];   % white plotting-area background
        data_color   = [0.080 0.390 0.520];   % deep cyan-blue mean curve
        marker_face  = [0.820 0.940 0.955];   % light cyan marker fill
        std_color    = [0.650 0.900 0.930];   % pale cyan std band
        ref_color    = [0.340 0.350 0.390];   % soft charcoal
        axis_color   = [0.250 0.300 0.330];   % muted dark blue-gray
        border_color = [0.780 0.820 0.830];   % subtle neutral border
        legend_bg    = [1.000 1.000 1.000];   % white legend background

    case 'lavender'
        fig_bg       = [1.000 1.000 1.000];   % white figure background
        axes_bg      = [1.000 1.000 1.000];   % white plotting-area background
        data_color   = [0.350 0.255 0.590];   % deep muted violet mean curve
        marker_face  = [0.900 0.855 0.970];   % light lavender marker fill
        std_color    = [0.650 0.900 0.930];   % keep std band pale cyan as requested
        ref_color    = [0.350 0.350 0.390];   % soft charcoal
        axis_color   = [0.300 0.275 0.340];   % muted purple-gray
        border_color = [0.800 0.800 0.840];   % subtle neutral border
        legend_bg    = [1.000 1.000 1.000];   % white legend background

    otherwise
        error('Unknown PLOT_THEME="%s". Use ''cyan'' or ''lavender''.', PLOT_THEME);
end

% OpenGL is used so FaceAlpha is rendered for the transparent std band.
fig = figure('Name',sprintf('Figure 1 - K=%d DTV scaling',K), ...
       'Color',fig_bg,'Renderer','opengl','Position',[120 100 900 650]);
ax = axes('Parent',fig,'Color',axes_bg);
hold(ax,'on');
box(ax,'off');  % bottom/left native axes only; top/right borders drawn manually below
grid(ax,'off');

% D_TV values used only for display on the logarithmic axis.
dtv_plot_floor = 0.5/DTV_MC_SAMPLES;
y_plot = max(dtv_mean,dtv_plot_floor);

% Mean +/- 1 std envelope. D_TV is bounded by [0,1], and the lower edge
% must stay strictly positive on a logarithmic y-axis.
std_lower = max(dtv_mean - dtv_std, dtv_plot_floor);
std_upper = min(dtv_mean + dtv_std, 1);
std_upper = max(std_upper, std_lower);

% Draw the transparent std band first so the mean curve remains on top.
h_std = fill(ax, ...
    [N_VALUES fliplr(N_VALUES)], ...
    [std_upper fliplr(std_lower)], ...
    std_color, ...
    'FaceAlpha',0.30, ...
    'EdgeColor','none', ...
    'DisplayName','Mean \pm 1 std');

% Main experimental curve: mean D_TV.
% The underlying dtv_mean values are not modified.
h_data = plot(ax,N_VALUES, y_plot, '-o', ...
    'Color',data_color, ...
    'LineWidth',2.5, ...
    'MarkerSize',8.5, ...
    'MarkerEdgeColor',data_color, ...
    'MarkerFaceColor',marker_face);

% N^{-1/2} theoretical reference. Its vertical offset is arbitrary; only
% its slope is relevant for comparison with the experimental curve.
ref_N = logspace(log10(min(N_VALUES)),log10(max(N_VALUES)),250);
anchor_N = 10^(mean(log10(N_VALUES)));
valid_D = y_plot(isfinite(y_plot) & y_plot>0);
anchor_D = 10^(median(log10(valid_D)));
ref_D = anchor_D * (ref_N/anchor_N).^(-0.5);
h_ref = plot(ax,ref_N,ref_D,'--', ...
    'Color',ref_color,'LineWidth',1.8);

% Publication-style axes: log-log representation for the fitted slope.
set(ax, 'XScale','log', 'YScale','log', ...
    'XGrid','off','YGrid','off', ...
    'XMinorGrid','off','YMinorGrid','off', ...
    'XMinorTick','off','YMinorTick','off', ...
    'TickDir','in','TickLength',[0.015 0.015], ...
    'FontSize',AXIS_TICK_FONTSIZE,'LineWidth',1.15, ...
    'FontName','Times New Roman', ...
    'XColor',axis_color,'YColor',axis_color, ...
    'Layer','top');

% Keep both the figure and plotting area white.
set(ax,'Color',axes_bg);
set(fig,'Color',fig_bg);

% Y-axis design. Since D_TV lies in [0,1], keep the objective upper bound
% at 1 while making sure the full standard-deviation band is visible.
y_lower = 10^floor(log10(min([valid_D std_lower])));
y_upper = max(1, 1.05*max(std_upper));
if ~isfinite(y_lower) || y_lower <= 0
    y_lower = dtv_plot_floor;
end
if y_lower >= y_upper
    y_lower = y_upper/10;
end
ylim(ax,[y_lower y_upper]);
xlim(ax,[min(N_VALUES) max(N_VALUES)]);

% Show only the requested logarithmic x-axis major ticks.
xticks(ax,[1e2 1e4 1e6 1e8]);
xticklabels(ax,{'10^{2}','10^{4}','10^{6}','10^{8}'});
ax.TickLabelInterpreter = 'tex';

% Draw only the top and right frame edges manually. This preserves the
% rectangular frame while preventing MATLAB from mirroring tick marks onto
% the top x-edge and right y-edge. Native ticks remain only on the bottom
% and left axes, and TickDir='in' keeps them inside the plotting box.
xl = xlim(ax);
yl = ylim(ax);
h_top = line(ax, xl, [yl(2) yl(2)], ...
    'Color',axis_color,'LineWidth',1.15,'HandleVisibility','off', ...
    'Clipping','off'); %#ok<NASGU>
h_right = line(ax, [xl(2) xl(2)], yl, ...
    'Color',axis_color,'LineWidth',1.15,'HandleVisibility','off', ...
    'Clipping','off'); %#ok<NASGU>

xlabel(ax,'Sample size N', ...
    'FontSize',AXIS_LABEL_FONTSIZE,'FontName','Times New Roman','Color',axis_color);
ylabel(ax,'D_{TV}(P_{S_T}, P_{S_{est}})', ...
    'FontSize',AXIS_LABEL_FONTSIZE,'FontName','Times New Roman', ...
    'Interpreter','tex','Color',axis_color);
title(ax,sprintf('DeepMVSA convergence (K=%d)',K), ...
    'FontSize',TITLE_FONTSIZE,'FontWeight','normal', ...
    'FontName','Times New Roman','Color',axis_color);

lgd = legend(ax,[h_data h_std h_ref], ...
       {sprintf('Mean D_{TV}, K=%d (slope=%.3f)',K,fitted_slope), ...
        'Mean \pm 1 std', ...
        'N^{-1/2} reference'}, ...
       'Location','best','FontSize',LEGEND_FONTSIZE, ...
       'FontName','Times New Roman','Interpreter','tex');
set(lgd,'Box','on','Color',legend_bg,'EdgeColor',border_color,'TextColor',axis_color);

% Leave substantially wider margins for the very large tick/axis-label fonts.
% Match the plotting-box size used in demo_deepmvsa_figure1_dtv_SE_v17_GYL.m.
set(ax,'Position',[0.22 0.22 0.66 0.64]);

% Keep export behavior suitable for publication output.
set(fig,'PaperPositionMode','auto','InvertHardcopy','off');

%% ===================== Local functions =====================
% The functions below are copied from the user-provided
% demo_deepmvsa_usgs_invflow_tv.m so that the D_TV calculation method is
% unchanged.

function [D_TV, vol_T, vol_E] = tv_dist_simplex(M_T, M_E, M_MC)
%TV_DIST_SIMPLEX  Total-variation distance between the uniform
%   distributions on two K-simplices (K = p-1), given by vertex matrices
%   M_T and M_E (p x p, columns are vertices) expressed in the SAME
%   coordinates (here: the projected space Up'*).
%
%     D_TV = 1 - Vol(S_T intersect S_E) / max( Vol(S_T), Vol(S_E) ).
%
%   Volumes: Vol = sqrt(det(E'*E))/K!, E = [m_1-m_0 ... m_K-m_0].
%   Intersection volume: symmetric Monte Carlo estimate using uniform
%   (Dirichlet(1,...,1)) samples from both simplices.

p = size(M_T, 2); K = p - 1;

E_T = M_T(:,2:p) - repmat(M_T(:,1), 1, K);
E_E = M_E(:,2:p) - repmat(M_E(:,1), 1, K);
vol_T = sqrt(max(det(E_T'*E_T), 0)) / factorial(K);
vol_E = sqrt(max(det(E_E'*E_E), 0)) / factorial(K);

% Uniform samples from S_T: alpha ~ Dirichlet(1,...,1)  <=>  normalized exponentials
G = -log(rand(p, M_MC)); alpha = G ./ repmat(sum(G, 1), p, 1);
r_T = mean(in_simplex(M_T*alpha, M_E));      % estimates Vol(intersection)/Vol_T

% Uniform samples from S_E (symmetric direction)
G = -log(rand(p, M_MC)); alpha = G ./ repmat(sum(G, 1), p, 1);
r_E = mean(in_simplex(M_E*alpha, M_T));      % estimates Vol(intersection)/Vol_E

vol_int = 0.5*(r_T*vol_T + r_E*vol_E);       % symmetric MC estimate of Vol(S_T intersect S_E)
D_TV = max(1 - vol_int/max(vol_T, vol_E), 0);
end

function inside = in_simplex(X, M)
%IN_SIMPLEX  Barycentric membership test for columns of X in conv(M):
%   x = m_0 + E*c is inside iff c >= 0 and 1 - sum(c) >= 0.
%   The overdetermined solve E\(x-m_0) is least squares, so points lying
%   slightly off the affine hull of M (estimation error) are handled
%   gracefully. Tolerance absorbs numerical roundoff on the boundary.
tol = 1e-8;
m0 = M(:,1);
E = M(:,2:end) - repmat(m0, 1, size(M,2)-1);
C = E \ (X - repmat(m0, 1, size(X,2)));
inside = all(C >= -tol, 1) & (1 - sum(C,1) >= -tol);
end
