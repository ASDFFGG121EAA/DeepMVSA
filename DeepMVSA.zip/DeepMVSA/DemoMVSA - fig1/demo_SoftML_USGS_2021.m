%% demo_SoftML_USGS_2021
% =========================================================================
% 直接复现 Najafi et al. (2021) Soft-ML / CRR 单纯形算法
% 并与当前 MVSA 的 USGS + spectMixGen + dataProj 预处理完全对接。
%
% 需要当前 MATLAB 路径中存在：
%   1) SoftML_Simplex_2021.m
%   2) spectMixGen.m
%   3) dataProj.m
%   4) dirichlet.m                 % spectMixGen 的依赖
%   5) USGS_1995_Library.mat
%
% 直接运行本文件即可。
% =========================================================================

clear;
clc;
close all;

%% --------------------------- 实验参数 -----------------------------------
SIGNATURES_TYPE = 1; %#ok<NASGU>
p = 4;                  % 端元数
N = 100000;             % 样本数
SNR = 20;               % dB
SHAPE_PARAMETER = 1;
MAX_PURIRY = 0.8;
OUTLIERS = 0;

% 为了可重复实验固定随机数。
% 如果你希望每次都随机选择不同 USGS 端元，可以删除这一行。
rng(1);

%% ------------------------- Load USGS library -----------------------------
load('USGS_1995_Library');

wavlen = datalib(:,1);
[L, n_materiais] = size(datalib);

sel_mat = 4 + randperm(n_materiais-4);
sel_mat = sel_mat(1:p);

% 真实端元
M = datalib(:,sel_mat);

clear datalib names;

fprintf('============================================================\n');
fprintf('USGS synthetic experiment\n');
fprintf('Bands L = %d, Endmembers p = %d, Samples N = %d, SNR = %.1f dB\n', ...
        L,p,N,SNR);
fprintf('Selected material columns: ');
fprintf('%d ',sel_mat);
fprintf('\n');
fprintf('============================================================\n');

%% --------------------------- Generate data -------------------------------
% spectMixGen 的模型：
%   Y = M*x + noise
%
% Source_pdf='Diri_id' 且 SHAPE_PARAMETER=1 对应等参数 Dirichlet。
% max_purity=0.8 会限制每个丰度分量最大不超过 0.8。
[Y, x_true, noise] = spectMixGen( ...
    M, N, ...
    'Source_pdf', 'Diri_id', ...
    'pdf_pars', SHAPE_PARAMETER, ...
    'max_purity', MAX_PURIRY*ones(1,p), ...
    'no_outliers', OUTLIERS, ...
    'violation_extremes', [1,1.2], ...
    'snr', SNR, ...
    'noise_shape', 'uniform');

%% ------------------------ MVSA-style affine projection -------------------
% dataProj 的 affine 模式估计最佳 (p-1) 维仿射子空间。
% Y_proj 保持为 L x N；
% Up(:,1:p-1) 是仿射信号空间的正交基；
% my 是 L x 1 均值。
[Y_proj, Up, my, sing_val] = dataProj(Y, p, 'proj_type', 'affine');

%% -------------------------- Degree of difficulty -------------------------
% 使用完整 SVD 避免某些 MATLAB 版本中 svds(M,p) 在 k=min(size(M)) 时的问题。
sing_vects = svd(M,'econ');
fprintf('Conditioning number of M = %2f \n', ...
        sing_vects(1)/sing_vects(end));

Cx = Up'*(M*x_true)*(M*x_true)'*Up/N;
Cn = Up'*noise*noise'*Up/N;

[U_cx, D_cx] = svd(Cx);
LOWER_SNR = D_cx(p,p)/(U_cx(:,p)'*Cn*U_cx(:,p));

fprintf('SNR along smallest eigenvalue = %f \n',LOWER_SNR);

%% ---------------------- Run paper Soft-ML method -------------------------
% 对 p 个端元，论文的满维 simplex 坐标维数为 K=p-1。
%
% 这里直接复用上面的 dataProj 结果：
%   X = Up(:,1:p-1)' * (Y_proj-my)
%
% UseHullGradient=true：
%   使用论文 Section 4.1 提出的 convex-hull 梯度加速。
%   对 N=100000 推荐开启，运行速度会明显更快。
%
% 如果要严格使用全部样本计算 Eq. (3.9)，改成：
%   'UseHullGradient', false
%
% Gamma=[] / Alpha=[]：
%   论文没有公开每组实验的具体 gamma 和 alpha。
%   核心函数会先自动确定一个可运行值，随后 alpha 固定不变，
%   仍执行 Algorithm 1 的固定步长更新。

MAX_ITER = 250;

[M_softml, S_softml, softml_out] = SoftML_Simplex_2021( ...
    Y, p, ...
    'YProj', Y_proj, ...
    'Up', Up, ...
    'my', my, ...
    'MTrue', M, ...
    'MaxIter', MAX_ITER, ...
    'Gamma', [], ...
    'Alpha', [], ...
    'UseConvexHullInit', true, ...
    'UseHullGradient', true, ...
    'Seed', 1, ...
    'Plot', true, ...
    'Verbose', true);

%% ---------------------------- Basic checks -------------------------------
fprintf('\n================ Soft-ML final result ================\n');
fprintf('Final CRR objective = %.6e\n',softml_out.final_objective);
fprintf('Final data loss     = %.6e\n',softml_out.final_data_loss);
fprintf('Final simplex volume= %.6e\n',softml_out.final_volume);
fprintf('Gamma               = %.6e\n',softml_out.gamma);
fprintf('Alpha               = %.6e\n',softml_out.alpha);

if isfield(softml_out,'paper_error')
    fprintf('Paper Eq.(4.1) error= %.6e\n',softml_out.paper_error);
end

fprintf('Abundance min       = %.6e\n',min(S_softml(:)));
fprintf('Max |sum(S)-1|      = %.6e\n',max(abs(sum(S_softml,1)-1)));
fprintf('======================================================\n');

%% --------------------- Match endmember order to truth --------------------
% softml_out.best_permutation 的定义：
%   true endmember i <-> estimated endmember best_permutation(i)
%
% 因此按照真实端元顺序重排估计结果。
if isfield(softml_out,'best_permutation')
    perm = softml_out.best_permutation;
    M_softml_match = M_softml(:,perm);
    S_softml_match = S_softml(perm,:);
else
    M_softml_match = M_softml;
    S_softml_match = S_softml;
end

%% ------------------------- Spectral error metrics ------------------------
endmember_mse = mean((M_softml_match - M).^2,1);
mean_endmember_mse = mean(endmember_mse);

sam_deg = zeros(1,p);
for k = 1:p
    a = M(:,k);
    b = M_softml_match(:,k);

    cosang = (a'*b) / (norm(a)*norm(b) + eps);
    cosang = min(max(cosang,-1),1);
    sam_deg(k) = acos(cosang)*180/pi;
end

fprintf('\nEndmember MSE for each material:\n');
disp(endmember_mse);
fprintf('Mean endmember MSE = %.6e\n',mean_endmember_mse);

fprintf('Endmember SAM (degree) for each material:\n');
disp(sam_deg);
fprintf('Mean SAM = %.6f degree\n',mean(sam_deg));

%% ------------------------- Abundance comparison --------------------------
% 注意：Soft-ML 论文主体的估计目标是 simplex vertices。
% 这里的 S_softml 是根据最终 simplex 反求并投影到概率单纯形得到的丰度。
abundance_mse = mean((S_softml_match - x_true).^2,2);

fprintf('\nAbundance MSE for each endmember:\n');
disp(abundance_mse');
fprintf('Mean abundance MSE = %.6e\n',mean(abundance_mse));

%% ------------------------ Plot endmember spectra -------------------------
figure('Name','Soft-ML estimated endmembers');

for k = 1:p
    subplot(ceil(p/2),2,k);

    if exist('wavlen','var') && numel(wavlen)==L
        xx = wavlen;
        xlabel_text = 'Wavelength';
    else
        xx = 1:L;
        xlabel_text = 'Spectral band';
    end

    plot(xx,M(:,k),'LineWidth',1.5);
    hold on;
    plot(xx,M_softml_match(:,k),'--','LineWidth',1.5);

    xlabel(xlabel_text);
    ylabel('Reflectance');
    title(sprintf('Endmember %d',k));
    legend('Ground Truth','Soft-ML','Location','best');
    grid on;
end

%% ------------------------ Save convenient outputs ------------------------
% 保留这些变量，后面可直接与 MVSA / VCA / Deep-MVSA 做相同指标比较。
M_true = M;
M_est = M_softml_match;
S_est = S_softml_match;

% 大矩阵 noise 如果后续不需要可清除以释放内存。
clear noise;

fprintf('\n程序运行结束。\n');
fprintf('主要输出变量：M_true, M_est, S_est, softml_out\n');
