%% demo_deepmvsa_usgs_invflow
%  DeepMVSA-InvFlow vs MVSA vs VCA on USGS synthetic data.

clear all; clc; close all;

%% Parameters
SIGNATURES_TYPE = 1; p = 4; N = 10000; SNR = 30; L = 200;
SHAPE_PARAMETER = 1; MAX_PURIRY = 0.8; OUTLIERS = 0;

%% Load USGS library
load('USGS_1995_Library')
wavlen = datalib(:,1); [L, n_materiais] = size(datalib);
sel_mat = 4 + randperm(n_materiais-4); sel_mat = sel_mat(1:p);
M = datalib(:,sel_mat); clear datalib wavlen names;

%% Generate data
[Y, x, noise] = spectMixGen(M, N, 'Source_pdf', 'Diri_id', 'pdf_pars', SHAPE_PARAMETER, ...
    'max_purity', MAX_PURIRY*ones(1,p), 'no_outliers', OUTLIERS, ...
    'violation_extremes', [1,1.2], 'snr', SNR, 'noise_shape', 'uniform');

%% Project to affine set
[Y_proj, Up, my, sing_val] = dataProj(Y, p, 'proj_type', 'affine');

%% Degree of difficulty
sing_vects = svds(M, p);
fprintf('Conditioning number of M = %2f \n', sing_vects(1)/sing_vects(end));
Cx = Up'*(M*x)*(M*x)'*Up/N; Cn = Up'*noise*noise'*Up/N;
[U, D] = svd(Cx);
LOWER_SNR = D(p,p)/(U(:,p)'*Cn*U(:,p));
fprintf('SNR along smallest eigenvalue = %f \n', LOWER_SNR);
clear noise x;

%% --------------------- MVSA ---------------------
tic;
A_est = mvsa(Y_proj, p, 'spherize', 'yes', 'verbose', 0);
Mvsa = Up'*A_est; t_mvsa = toc;

%% --------------------- VCA ---------------------
tic;
[Ae, ~, ~] = VCA(Y_proj, 'Endmembers', p, 'verbose', 'off');
Mvca = Up'*Ae; t_vca = toc;

%% --------------------- DeepMVSA-InvFlow ---------------------
tic;
% [M_deep, ~, ~, ~, theta] = deep_mvsa_invflow(Y, p, 'spherize', 'yes', 'verbose', 1, ...
%     'MM_ITERS', 1500, ...
%     'WARM_UP', 400, ...
%     'LR', 1e-3, ...
%     'LAMBDA_VOL', 0.015, ...
%     'LAMBDA_NONNEG', 5, ...
%     'LAMBDA_EQ', 80, ...
%     'LAMBDA_SUMONE', 2);


[M_deep, ~, ~, ~, theta] = deep_mvsa_invflow(Y, p, 'spherize', 'yes', 'verbose', 1, ...
    'MM_ITERS', 1500, 'WARM_UP', 400, 'LR', 1e-3, ...
    'LAMBDA_VOL', 0.01, 'LAMBDA_NONNEG', 5, 'LAMBDA_EQ', 80, 'LAMBDA_SUMONE', 2, ...
    'LAMBDA_ENCLOSE', 10);



Mdeep = Up'*M_deep; t_deep = toc;

%% Project for display
Mtrue = Up'*M;
Y_disp = Up'*Y_proj;

%% Align endmembers
% MVSA
angles = Mtrue'*Mvsa ./ (repmat(sqrt(sum(Mtrue.^2)),p,1)' .* repmat(sqrt(sum(Mvsa.^2)),p,1));
P = zeros(p); for i=1:p, [~,j]=max(angles(i,:)); P(j,i)=1; angles(:,j)=-inf; end
Mvsa = Mvsa*P;

% VCA
angles = Mtrue'*Mvca ./ (repmat(sqrt(sum(Mtrue.^2)),p,1)' .* repmat(sqrt(sum(Mvca.^2)),p,1));
P = zeros(p); for i=1:p, [~,j]=max(angles(i,:)); P(j,i)=1; angles(:,j)=-inf; end
Mvca = Mvca*P;

% DeepMVSA-InvFlow
angles = Mtrue'*Mdeep ./ (repmat(sqrt(sum(Mtrue.^2)),p,1)' .* repmat(sqrt(sum(Mdeep.^2)),p,1));
P = zeros(p); for i=1:p, [~,j]=max(angles(i,:)); P(j,i)=1; angles(:,j)=-inf; end
Mdeep = Mdeep*P;

%% Errors
MVSA_ERR = norm(Mtrue-Mvsa,'fro')/norm(Mtrue,'fro');
VCA_ERR  = norm(Mtrue-Mvca,'fro')/norm(Mtrue,'fro');
DEEP_ERR = norm(Mtrue-Mdeep,'fro')/norm(Mtrue,'fro');

fprintf('\n========== COMPARISON (USGS Synthetic) ==========\n');
fprintf('TIMES (sec):  MVSA=%.3f,  VCA=%.3f,  DeepMVSA-InvFlow=%.3f\n', t_mvsa, t_vca, t_deep);
fprintf('Rel MSE:      MVSA=%f,  VCA=%f,  DeepMVSA-InvFlow=%f\n', MVSA_ERR, VCA_ERR, DEEP_ERR);
fprintf('Learned c = %.6f\n', theta.c);

%% --------------------- Total-variation distance D_TV (Table 2 metric) ---------------------
%  D_TV(P_{S_T}, P_{S_hat}) between the uniform distributions on the true
%  simplex S_T = conv(Mtrue) and each estimated simplex S_hat:
%
%     D_TV = 1 - Vol(S_T intersect S_hat) / max{ Vol(S_T), Vol(S_hat) } .
%
%  * Simplex volumes are closed form: with edge vectors
%    E = [m_1-m_0, ..., m_K-m_0], K = p-1,
%        Vol(S) = sqrt(det(E'*E)) / K!     (Gram determinant, valid in any
%                                             embedding dimension).
%  * Vol(S_T intersect S_hat) has no closed form; it is estimated by Monte Carlo:
%    sample M_MC points uniformly from each simplex
%    (alpha ~ Dirichlet(1,...,1), x = M*alpha) and test barycentric
%    membership in the other simplex. MC standard error ~ 1/sqrt(M_MC)
%    (~0.003 for M_MC = 1e5; increase M_MC for more digits).
%  * The D_TV value is invariant to the endmember permutation used above
%    (it is a set distance), and invariant to any common affine scaling of
%    the ambient coordinates (it is a volume ratio).

M_MC = 1e5;                  % Monte-Carlo samples per simplex
rng(0, 'twister');           % reproducible MC estimates

[DTV_mvsa, vol_true, vol_mvsa] = tv_dist_simplex(Mtrue, Mvsa, M_MC);
[DTV_vca,  ~,        vol_vca ] = tv_dist_simplex(Mtrue, Mvca, M_MC);
[DTV_deep, ~,        vol_deep] = tv_dist_simplex(Mtrue, Mdeep, M_MC);

fprintf('D_TV:         MVSA=%.4f,  VCA=%.4f,  DeepMVSA-InvFlow=%.4f\n', DTV_mvsa, DTV_vca, DTV_deep);
fprintf('Simplex vol:  true=%.4e,  MVSA=%.4e,  VCA=%.4e,  DeepMVSA-InvFlow=%.4e\n', ...
    vol_true, vol_mvsa, vol_vca, vol_deep);

%% 2D Projection Plot
I=1; J=2; E_I=eye(p); v1=E_I(:,I); v2=E_I(:,J);
Y_plot=[v1 v2]'*Y_disp; m_true=[v1 v2]'*Mtrue;
m_vsa=[v1 v2]'*Mvsa; m_vca=[v1 v2]'*Mvca; m_deep=[v1 v2]'*Mdeep;

figure('Name','2D Projection');
plot(Y_plot(1,:),Y_plot(2,:),'.','Color',[0.6 0.6 0.6],'MarkerSize',4); hold on;
plot(m_true(1,[1:p 1]),m_true(2,[1:p 1]),'k*-','LineWidth',2,'MarkerSize',10);
plot(m_vsa(1,[1:p 1]),m_vsa(2,[1:p 1]),'ro--','LineWidth',1.5,'MarkerSize',8);
plot(m_vca(1,[1:p 1]),m_vca(2,[1:p 1]),'gs:','LineWidth',1.5,'MarkerSize',8);
plot(m_deep(1,[1:p 1]),m_deep(2,[1:p 1]),'m^-.','LineWidth',1.5,'MarkerSize',8);
xlabel('v1^T Y'); ylabel('v2^T Y');
legend('Data','True','MVSA','VCA','DeepMVSA-InvFlow','Location','best');
title('Endmembers and Data Points (2D Projection)'); grid on;

%% Spectral signatures
figure('Name','Signatures'); hold on;
plot(1:L,(Up*Mtrue(:,1))','b','LineWidth',1.5);
plot(1:L,(Up*Mvsa(:,1))','r','LineWidth',1.2);
plot(1:L,(Up*Mvca(:,1))','g','LineWidth',1.2);
plot(1:L,(Up*Mdeep(:,1))','m','LineWidth',1.2);
for i=2:p
    plot(1:L,(Up*Mtrue(:,i))','b','LineWidth',1.5);
    plot(1:L,(Up*Mvsa(:,i))','r','LineWidth',1.2);
    plot(1:L,(Up*Mvca(:,i))','g','LineWidth',1.2);
    plot(1:L,(Up*Mdeep(:,i))','m','LineWidth',1.2);
end
legend('True','MVSA','VCA','DeepMVSA-InvFlow','Location','best');
title('Endmember Signatures (USGS Library)');
xlabel('spectral band'); ylabel('reflectance'); grid on;

%% ===================== Local functions =====================
function [D_TV, vol_T, vol_E] = tv_dist_simplex(M_T, M_E, M_MC)
%TV_DIST_SIMPLEX  Total-variation distance between the uniform
%   distributions on two K-simplices (K = p-1), given by vertex matrices
%   M_T and M_E (p x p, columns are vertices) expressed in the SAME
%   coordinates (here: the projected space Up'*).
%
%     D_TV = 1 - Vol(S_T intersect S_E) / max( Vol(S_T), Vol(S_E) ).
%
%   Volumes: Vol = sqrt(det(E'*E))/K!, E = [m_1-m_0 ... m_K-m_0].
%   Intersection volume: symmetric Monte Carlo estimate using uniform
%   (Dirichlet(1,...,1)) samples from both simplices.

p = size(M_T, 2); K = p - 1;

E_T = M_T(:,2:p) - repmat(M_T(:,1), 1, K);
E_E = M_E(:,2:p) - repmat(M_E(:,1), 1, K);
vol_T = sqrt(max(det(E_T'*E_T), 0)) / factorial(K);
vol_E = sqrt(max(det(E_E'*E_E), 0)) / factorial(K);

% Uniform samples from S_T: alpha ~ Dirichlet(1,...,1)  <=>  normalized exponentials
G = -log(rand(p, M_MC)); alpha = G ./ repmat(sum(G, 1), p, 1);
r_T = mean(in_simplex(M_T*alpha, M_E));      % estimates Vol(intersection)/Vol_T

% Uniform samples from S_E (symmetric direction)
G = -log(rand(p, M_MC)); alpha = G ./ repmat(sum(G, 1), p, 1);
r_E = mean(in_simplex(M_E*alpha, M_T));      % estimates Vol(intersection)/Vol_E

vol_int = 0.5*(r_T*vol_T + r_E*vol_E);       % symmetric MC estimate of Vol(S_T intersect S_E)
D_TV = max(1 - vol_int/max(vol_T, vol_E), 0);
end

function inside = in_simplex(X, M)
%IN_SIMPLEX  Barycentric membership test for columns of X in conv(M):
%   x = m_0 + E*c is inside iff c >= 0 and 1 - sum(c) >= 0.
%   The overdetermined solve E\(x-m_0) is least squares, so points lying
%   slightly off the affine hull of M (estimation error) are handled
%   gracefully. Tolerance absorbs numerical roundoff on the boundary.
tol = 1e-8;
m0 = M(:,1);
E = M(:,2:end) - repmat(m0, 1, size(M,2)-1);
C = E \ (X - repmat(m0, 1, size(X,2)));
inside = all(C >= -tol, 1) & (1 - sum(C,1) >= -tol);
end
