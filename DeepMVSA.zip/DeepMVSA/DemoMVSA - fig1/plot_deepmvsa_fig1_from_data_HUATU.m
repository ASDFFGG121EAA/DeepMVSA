%% plot_deepmvsa_fig1_from_data
% Standalone plotting script extracted from the plotting section of
% demo_deepmvsa_fig1_trim12_keep10_plotprint(1).m.
% It directly plots the supplied mean/std D_TV values and does NOT rerun experiments.

clearvars; clc; close all;

%% ===================== Data =====================
K = 5;
N_VALUES = [1e2 1e3 1e4 1e5 1e6 1e7 1e8];

dtv_mean = [0.496706 0.209354 0.0862683 0.0196707 0.0116816 0.00706819 0.00652384];
dtv_std  = [0.0978673 0.0890777 0.0562465 0.0132085 0.0106987 0.00667798 0.00364187];

DTV_MC_SAMPLES = 1e5;

%% ===================== Figure appearance =====================
PLOT_THEME = 'cyan';

AXIS_TICK_FONTSIZE  = 30;
AXIS_LABEL_FONTSIZE = 30;
LEGEND_FONTSIZE     = 28;
TITLE_FONTSIZE      = 16;

%% ===================== Log-log slope fit =====================
dtv_floor = 0.5/DTV_MC_SAMPLES;
y_fit = max(dtv_mean,dtv_floor);

coeff = polyfit(log10(N_VALUES),log10(y_fit),1);
fitted_slope = coeff(1);

y_hat = polyval(coeff,log10(N_VALUES));
y_obs = log10(y_fit);
ss_res = sum((y_obs-y_hat).^2);
ss_tot = sum((y_obs-mean(y_obs)).^2);
if ss_tot > 0
    fitted_r2 = 1-ss_res/ss_tot;
else
    fitted_r2 = NaN;
end

fprintf('N values       : %s\n', mat2str(N_VALUES));
fprintf('Plot mean D_TV : %s\n', mat2str(dtv_mean,6));
fprintf('Plot std D_TV  : %s\n', mat2str(dtv_std,6));
fprintf('Fitted slope   : %.6f\n', fitted_slope);
fprintf('Fit R^2        : %.6f\n', fitted_r2);
fprintf('Reference slope: -0.500000\n');

%% ===================== Color theme =====================
switch lower(strtrim(PLOT_THEME))
    case 'cyan'
        fig_bg       = [1.000 1.000 1.000];
        axes_bg      = [1.000 1.000 1.000];
        data_color   = [0.080 0.390 0.520];
        marker_face  = [0.820 0.940 0.955];
        std_color    = [0.650 0.900 0.930];
        ref_color    = [0.340 0.350 0.390];
        axis_color   = [0.250 0.300 0.330];
        border_color = [0.780 0.820 0.830];
        legend_bg    = [1.000 1.000 1.000];

    case 'lavender'
        fig_bg       = [1.000 1.000 1.000];
        axes_bg      = [1.000 1.000 1.000];
        data_color   = [0.350 0.255 0.590];
        marker_face  = [0.900 0.855 0.970];
        std_color    = [0.650 0.900 0.930];
        ref_color    = [0.350 0.350 0.390];
        axis_color   = [0.300 0.275 0.340];
        border_color = [0.800 0.800 0.840];
        legend_bg    = [1.000 1.000 1.000];

    otherwise
        error('Unknown PLOT_THEME="%s". Use ''cyan'' or ''lavender''.', PLOT_THEME);
end

%% ===================== Plot =====================
fig = figure('Name',sprintf('Figure 1 - K=%d DTV scaling',K), ...
       'Color',fig_bg,'Renderer','opengl','Position',[120 100 900 650]);
ax = axes('Parent',fig,'Color',axes_bg);
hold(ax,'on');
box(ax,'off');
grid(ax,'off');

% D_TV values used only for display on the logarithmic axis.
dtv_plot_floor = 0.5/DTV_MC_SAMPLES;
y_plot = max(dtv_mean,dtv_plot_floor);

% Mean +/- 1 std envelope.
std_lower = max(dtv_mean-dtv_std,dtv_plot_floor);
std_upper = min(dtv_mean+dtv_std,1);
std_upper = max(std_upper,std_lower);

% Transparent std band.
h_std = fill(ax, ...
    [N_VALUES fliplr(N_VALUES)], ...
    [std_upper fliplr(std_lower)], ...
    std_color, ...
    'FaceAlpha',0.30, ...
    'EdgeColor','none', ...
    'DisplayName','Mean \pm 1 std');

% Mean D_TV curve.
h_data = plot(ax,N_VALUES,y_plot,'-o', ...
    'Color',data_color, ...
    'LineWidth',2.5, ...
    'MarkerSize',8.5, ...
    'MarkerEdgeColor',data_color, ...
    'MarkerFaceColor',marker_face);

% N^{-1/2} reference line.
ref_N = logspace(log10(min(N_VALUES)),log10(max(N_VALUES)),250);
anchor_N = 10^(mean(log10(N_VALUES)));
valid_D = y_plot(isfinite(y_plot) & y_plot>0);
anchor_D = 10^(median(log10(valid_D)));
ref_D = anchor_D*(ref_N/anchor_N).^(-0.5);
h_ref = plot(ax,ref_N,ref_D,'--', ...
    'Color',ref_color,'LineWidth',1.8);

%% ===================== Axes =====================
set(ax,'XScale','log','YScale','log', ...
    'XGrid','off','YGrid','off', ...
    'XMinorGrid','off','YMinorGrid','off', ...
    'XMinorTick','off','YMinorTick','off', ...
    'TickDir','in','TickLength',[0.015 0.015], ...
    'FontSize',AXIS_TICK_FONTSIZE,'LineWidth',1.15, ...
    'FontName','Times New Roman', ...
    'XColor',axis_color,'YColor',axis_color, ...
    'Layer','top');

set(ax,'Color',axes_bg);
set(fig,'Color',fig_bg);

y_lower = 10^floor(log10(min([valid_D std_lower])));
y_upper = max(1,1.05*max(std_upper));
if ~isfinite(y_lower) || y_lower <= 0
    y_lower = dtv_plot_floor;
end
if y_lower >= y_upper
    y_lower = y_upper/10;
end

ylim(ax,[y_lower y_upper]);
xlim(ax,[min(N_VALUES) max(N_VALUES)]);

xticks(ax,[1e2 1e4 1e6 1e8]);
xticklabels(ax,{'10^{2}','10^{4}','10^{6}','10^{8}'});
ax.TickLabelInterpreter = 'tex';

% Draw top/right frame edges manually.
xl = xlim(ax);
yl = ylim(ax);
line(ax,xl,[yl(2) yl(2)], ...
    'Color',axis_color,'LineWidth',1.15, ...
    'HandleVisibility','off','Clipping','off');
line(ax,[xl(2) xl(2)],yl, ...
    'Color',axis_color,'LineWidth',1.15, ...
    'HandleVisibility','off','Clipping','off');

%% ===================== Labels and legend =====================
xlabel(ax,'Sample size N', ...
    'FontSize',AXIS_LABEL_FONTSIZE, ...
    'FontName','Times New Roman','Color',axis_color);

ylabel(ax,'D_{TV}(P_{S_T}, P_{S_{est}})', ...
    'FontSize',AXIS_LABEL_FONTSIZE, ...
    'FontName','Times New Roman', ...
    'Interpreter','tex','Color',axis_color);

title(ax,sprintf('DeepMVSA convergence (K=%d)',K), ...
    'FontSize',TITLE_FONTSIZE,'FontWeight','normal', ...
    'FontName','Times New Roman','Color',axis_color);

lgd = legend(ax,[h_data h_std h_ref], ...
    {sprintf('Mean D_{TV}, K=%d (slope=%.3f)',K,fitted_slope), ...
     'Mean \pm 1 std', ...
     'N^{-1/2} reference'}, ...
    'Location','best','FontSize',LEGEND_FONTSIZE, ...
    'FontName','Times New Roman','Interpreter','tex');
set(lgd,'Box','on','Color',legend_bg, ...
    'EdgeColor',border_color,'TextColor',axis_color);

set(ax,'Position',[0.22 0.22 0.66 0.64]);
set(fig,'PaperPositionMode','auto','InvertHardcopy','off');
