function out = make_dz01v_unmixing_mat(source_dir, out_file, opts)
%MAKE_DZ01V_UNMIXING_MAT Build a radiance cube from DZ01V band GeoTIFFs.
%
% Default output variable:
%   cube_rad: [band, row, col], radiance calibrated, single precision.
%
% For MVSA/DeepMVSA after loading:
%   Y = reshape(cube_rad, num_bands, []);
%   Y = double(Y(:, valid_idx));

if nargin < 1 || isempty(source_dir)
    source_dir = ['C:\Users\GYL\Desktop\MVSA\笔记本\20260114024138\' ...
        'DZ01V_L4_E118.8_N29.8_20260114024138_01_T1'];
end
if nargin < 3 || isempty(opts)
    opts = struct();
end

num_bands = get_option(opts, 'NumBands', 16);
output_class = get_option(opts, 'OutputClass', 'single');
save_y_matrix = get_option(opts, 'SaveYMatrix', false);

if ~isfolder(source_dir)
    error('Source directory does not exist: %s', source_dir);
end
if ~ismember(output_class, {'single', 'double'})
    error('OutputClass must be ''single'' or ''double''.');
end

mtl_list = dir(fullfile(source_dir, '*_MTL.txt'));
if isempty(mtl_list)
    error('No *_MTL.txt metadata file found in: %s', source_dir);
end
mtl_file = fullfile(source_dir, mtl_list(1).name);
mtl_text = fileread(mtl_file);

if nargin < 2 || isempty(out_file)
    product_id = erase(mtl_list(1).name, '_MTL.txt');
    out_file = fullfile(source_dir, [product_id '_unmixing_radiance_cube_16xHxW.mat']);
end

band_files = strings(num_bands, 1);
radiance_mult = nan(num_bands, 1);
radiance_add = nan(num_bands, 1);
band_center_wavelength_nm = nan(num_bands, 1);

cube_rad = [];
valid_mask = [];
rows = [];
cols = [];

fprintf('Reading DZ01V bands from:\n  %s\n', source_dir);
fprintf('Metadata:\n  %s\n', mtl_file);

for b = 1:num_bands
    band_match = dir(fullfile(source_dir, sprintf('*_B%d.TIF', b)));
    if isempty(band_match)
        error('Missing band file B%d in: %s', b, source_dir);
    end
    band_path = fullfile(source_dir, band_match(1).name);
    band_files(b) = string(band_path);

    dn = imread(band_path);
    if b == 1
        rows = size(dn, 1);
        cols = size(dn, 2);
        cube_rad = zeros(num_bands, rows, cols, output_class);
        valid_mask = true(rows, cols);
    elseif size(dn, 1) ~= rows || size(dn, 2) ~= cols
        error('Band B%d size differs from B1.', b);
    end

    radiance_mult(b) = read_mtl_scalar(mtl_text, sprintf('RADIANCE_MULT_BAND_%d', b), NaN);
    radiance_add(b) = read_mtl_scalar(mtl_text, sprintf('RADIANCE_ADD_BAND_%d', b), 0);
    band_center_wavelength_nm(b) = read_mtl_scalar( ...
        mtl_text, sprintf('MEASURED_CENTER_WAVELENGTH_BAND_%d', b), NaN);

    if isnan(radiance_mult(b))
        error('Missing RADIANCE_MULT_BAND_%d in metadata.', b);
    end

    if strcmp(output_class, 'single')
        rad = single(dn) .* single(radiance_mult(b)) + single(radiance_add(b));
    else
        rad = double(dn) .* radiance_mult(b) + radiance_add(b);
    end

    cube_rad(b, :, :) = reshape(rad, 1, rows, cols);
    valid_mask = valid_mask & isfinite(rad) & dn > 0 & dn < intmax(class(dn));

    fprintf('  B%02d -> %s | mult=%g add=%g center=%g nm\n', ...
        b, band_match(1).name, radiance_mult(b), radiance_add(b), ...
        band_center_wavelength_nm(b));
end

num_pixels = rows * cols;
valid_idx = uint32(find(valid_mask(:)));
Y_size = [num_bands, num_pixels];
cube_order = 'band,row,col';
data_units = 'radiance';
source_sensor = 'DZ01 VNIR';
created_on = string(datetime('now', 'Format', 'yyyy-MM-dd HH:mm:ss'));
unmixing_note = ['Use Y = reshape(cube_rad, num_bands, []); ' ...
    'then Y = double(Y(:, valid_idx)); before MVSA/DeepMVSA.'];

fprintf('Image size: bands=%d, rows=%d, cols=%d, pixels=%d\n', ...
    num_bands, rows, cols, num_pixels);
fprintf('Valid pixels: %d / %d\n', numel(valid_idx), num_pixels);

if save_y_matrix
    Y = reshape(cube_rad, num_bands, []);
    save(out_file, 'cube_rad', 'Y', 'valid_mask', 'valid_idx', 'Y_size', ...
        'rows', 'cols', 'num_bands', 'cube_order', 'data_units', ...
        'source_sensor', 'source_dir', 'mtl_file', 'band_files', ...
        'radiance_mult', 'radiance_add', 'band_center_wavelength_nm', ...
        'created_on', 'unmixing_note', '-v7.3');
else
    save(out_file, 'cube_rad', 'valid_mask', 'valid_idx', 'Y_size', ...
        'rows', 'cols', 'num_bands', 'cube_order', 'data_units', ...
        'source_sensor', 'source_dir', 'mtl_file', 'band_files', ...
        'radiance_mult', 'radiance_add', 'band_center_wavelength_nm', ...
        'created_on', 'unmixing_note', '-v7.3');
end

fprintf('Saved unmixing-ready MAT file:\n  %s\n', out_file);

out = struct();
out.out_file = out_file;
out.rows = rows;
out.cols = cols;
out.num_bands = num_bands;
out.Y_size = Y_size;
out.valid_pixels = numel(valid_idx);
out.data_units = data_units;
out.cube_variable = 'cube_rad';
end

function value = get_option(opts, name, default_value)
if isstruct(opts) && isfield(opts, name) && ~isempty(opts.(name))
    value = opts.(name);
else
    value = default_value;
end
end

function value = read_mtl_scalar(mtl_text, key, default_value)
pattern = [regexptranslate('escape', key) '\s*=\s*"?([-+0-9.Ee]+)"?'];
tokens = regexp(mtl_text, pattern, 'tokens', 'once');
if isempty(tokens)
    value = default_value;
else
    value = str2double(tokens{1});
end
end
