%% demo_deepmvsa_dz01v_invflow
% DeepMVSA-InvFlow on real DZ01V_L4 data.
% Based on demo_deepmvsa_usgs_invflow.m.
%
% This script:
%   1) loads DZ01V_L4.mat;
%   2) converts cube_rad -> Y = [bands x valid_pixels] when necessary;
%   3) performs the same affine projection used by the USGS demo;
%   4) runs only DeepMVSA-InvFlow;
%   5) produces only one figure: the 2D Projection plot.
%
% Required functions on MATLAB path:
%   dataProj.m
%   deep_mvsa_invflow.m

clear; clc; close all;

%% ===================== Parameters =====================
DATA_FILE = 'DZ01V_L4.mat';

% Number of endmembers.
% p = 3 is retained from the supplied USGS demo and gives a triangle in 2D.
p = 5;

% DeepMVSA-InvFlow parameters: kept identical to the supplied USGS demo.
DEEP_MM_ITERS       = 1500;
DEEP_WARM_UP        = 400;
DEEP_LR             = 1e-3;
DEEP_LAMBDA_VOL     = 0.01;
DEEP_LAMBDA_NONNEG  = 5;
DEEP_LAMBDA_EQ      = 80;
DEEP_LAMBDA_SUMONE  = 2;
DEEP_LAMBDA_ENCLOSE = 10;
DEEP_BATCH_SIZE     = 2048;
DEEP_SEED           = 0;

% Only affects the number of gray data points DISPLAYED in the 2D figure.
% DeepMVSA still uses all valid pixels in Y.
MAX_PLOT_POINTS = 100000;

% Save the only result figure to disk.
SAVE_FIGURE = true;
FIGURE_FILE = 'DZ01V_DeepMVSA_2D_Projection.png';

%% ===================== Load DZ01V data =====================
if ~isfile(DATA_FILE)
    error('Data file does not exist: %s', DATA_FILE);
end

file_info = whos('-file', DATA_FILE);
var_names = {file_info.name};

fprintf('Loading DZ01V data from:\n  %s\n', DATA_FILE);

if ismember('Y', var_names)
    % Case 1: the MAT file already contains Y.
    S = load(DATA_FILE, 'Y');
    Y = S.Y;
    clear S;

    % If num_bands exists, use it to check/correct orientation.
    if ismember('num_bands', var_names)
        Smeta = load(DATA_FILE, 'num_bands');
        num_bands_file = double(Smeta.num_bands);
        clear Smeta;

        if size(Y,1) ~= num_bands_file && size(Y,2) == num_bands_file
            Y = Y.';
        end
    end

elseif ismember('cube_rad', var_names)
    % Case 2: MAT file was produced by make_dz01v_unmixing_mat.m.
    vars_to_load = {'cube_rad'};
    if ismember('valid_idx', var_names)
        vars_to_load{end+1} = 'valid_idx';
    elseif ismember('valid_mask', var_names)
        vars_to_load{end+1} = 'valid_mask';
    end

    S = load(DATA_FILE, vars_to_load{:});

    cube_rad = S.cube_rad;
    L_cube = size(cube_rad, 1);
    Y = reshape(cube_rad, L_cube, []);
    clear cube_rad;

    % Keep exactly the valid pixels prepared by the DZ01V preprocessing file.
    if isfield(S, 'valid_idx') && ~isempty(S.valid_idx)
        Y = Y(:, double(S.valid_idx));
    elseif isfield(S, 'valid_mask') && ~isempty(S.valid_mask)
        idx = find(S.valid_mask(:));
        Y = Y(:, idx);
        clear idx;
    end
    clear S;

else
    error(['DZ01V_L4.mat must contain either variable ''Y'' or ''cube_rad''. ' ...
           'The preprocessing file make_dz01v_unmixing_mat.m produces ''cube_rad''.']);
end

% DeepMVSA/dataProj are run in double precision, matching the original workflow.
Y = double(Y);

% Safety filtering in case Y was supplied directly rather than through cube_rad.
valid_col = all(isfinite(Y), 1) & any(Y ~= 0, 1);
if ~all(valid_col)
    fprintf('Removing %d invalid/zero pixels.\n', sum(~valid_col));
    Y = Y(:, valid_col);
end
clear valid_col;

[L, N] = size(Y);

if p < 2
    error('p must be at least 2 for a 2D projection.');
end
if N < p
    error('Not enough valid pixels: N=%d, p=%d.', N, p);
end

fprintf('DZ01V matrix Y: %d bands x %d valid pixels\n', L, N);
fprintf('DeepMVSA endmembers p = %d\n', p);
fprintf('Mini-batch size = %d\n', DEEP_BATCH_SIZE);
fprintf('Training iterations = %d\n', DEEP_MM_ITERS);
fprintf('Effective epochs = %.4f\n', DEEP_MM_ITERS * min(DEEP_BATCH_SIZE,N) / N);

%% ===================== Affine projection =====================
% Same projection step as in demo_deepmvsa_usgs_invflow.m.
[Y_proj, Up, ~, ~] = dataProj(Y, p, 'proj_type', 'affine');

% Select only a subset for DISPLAY so plotting a large real image stays fast.
rng(DEEP_SEED, 'twister');
num_plot = min(N, MAX_PLOT_POINTS);
if num_plot < N
    plot_idx = randperm(N, num_plot);
else
    plot_idx = 1:N;
end

% In the USGS demo: Y_disp = Up' * Y_proj.
% Here we directly retain only the columns needed for the final figure.
Y_plot_p = Up' * Y_proj(:, plot_idx);
clear Y_proj plot_idx;

%% ===================== DeepMVSA-InvFlow only =====================
tic;
[M_deep, ~, ~, ~, theta] = deep_mvsa_invflow(Y, p, ...
    'spherize', 'yes', ...
    'verbose', 1, ...
    'MM_ITERS', DEEP_MM_ITERS, ...
    'WARM_UP', DEEP_WARM_UP, ...
    'LR', DEEP_LR, ...
    'LAMBDA_VOL', DEEP_LAMBDA_VOL, ...
    'LAMBDA_NONNEG', DEEP_LAMBDA_NONNEG, ...
    'LAMBDA_EQ', DEEP_LAMBDA_EQ, ...
    'LAMBDA_SUMONE', DEEP_LAMBDA_SUMONE, ...
    'LAMBDA_ENCLOSE', DEEP_LAMBDA_ENCLOSE, ...
    'BATCH_SIZE', DEEP_BATCH_SIZE, ...
    'SEED', DEEP_SEED);
t_deep = toc;

% Same display coordinates as the supplied USGS demo.
Mdeep = Up' * M_deep;

fprintf('\n========== DZ01V DeepMVSA-InvFlow ==========\n');
fprintf('Runtime: %.3f sec\n', t_deep);
if isstruct(theta) && isfield(theta, 'c')
    fprintf('Learned c = %.6f\n', theta.c);
end

%% ===================== Only result: 2D Projection =====================
% Use the first two coordinates of the p-dimensional affine representation.
Y_plot = Y_plot_p(1:2, :);
m_deep = Mdeep(1:2, :);

figure('Name', 'DZ01V - DeepMVSA 2D Projection', 'Color', 'w');
plot(Y_plot(1,:), Y_plot(2,:), '.', ...
    'Color', [0.60 0.60 0.60], 'MarkerSize', 4);
hold on;

% Close the estimated simplex polygon. For p=3 this is the DeepMVSA triangle.
order = [1:p 1];
plot(m_deep(1,order), m_deep(2,order), 'm^-.', ...
    'LineWidth', 1.8, 'MarkerSize', 9, 'MarkerFaceColor', 'm');

xlabel('v_1^T Y');
ylabel('v_2^T Y');
legend('DZ01V data', 'DeepMVSA-InvFlow', 'Location', 'best');
title('DZ01V Endmembers and Data Points (2D Projection)');
grid on;
box on;
axis tight;

if SAVE_FIGURE
    exportgraphics(gcf, FIGURE_FILE, 'Resolution', 300);
    fprintf('2D Projection figure saved to:\n  %s\n', FIGURE_FILE);
end
