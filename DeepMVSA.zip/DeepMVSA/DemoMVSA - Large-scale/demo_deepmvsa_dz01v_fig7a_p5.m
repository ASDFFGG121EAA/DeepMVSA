%% demo_deepmvsa_dz01v_invflow
% DeepMVSA-InvFlow on DZ01V_L4.mat -- Fig. 7(a)-style experiment.
%
% Experimental setting used here:
%   1) use ALL valid DZ01V pixels for DeepMVSA unmixing;
%   2) do NOT randomly subsample pixels;
%   3) do NOT add a separate PCA-to-10 preprocessing step;
%   4) estimate p = 5 endmembers;
%   5) display ALL valid pixels in the final 2-D projection;
%   6) generate ONLY the Fig. 7(a)-style 2-D result figure.
%
% Required functions on MATLAB path:
%   dataProj.m
%   deep_mvsa_invflow.m

clear; clc; close all;

%% ===================== Parameters =====================
DATA_FILE = 'DZ01V_L4.mat';

% Five-endmember experiment.
p = 3;

% DeepMVSA-InvFlow parameters: retained from the supplied USGS demo.
DEEP_MM_ITERS       = 5500;
DEEP_WARM_UP        = 400;
DEEP_LR             = 1e-3;
DEEP_LAMBDA_VOL     = 0.01;
DEEP_LAMBDA_NONNEG  = 5;
DEEP_LAMBDA_EQ      = 80;
DEEP_LAMBDA_SUMONE  = 2;
DEEP_LAMBDA_ENCLOSE = 20;
DEEP_BATCH_SIZE     = 4096;
DEEP_SEED           = 0;

% Save the only result figure.
SAVE_FIGURE = true;
FIGURE_FILE = 'DZ01V_DeepMVSA_Fig7a_p5.png';

%% ===================== Load DZ01V data =====================
if ~isfile(DATA_FILE)
    error('Data file does not exist: %s', DATA_FILE);
end

file_info = whos('-file', DATA_FILE);
var_names = {file_info.name};

fprintf('Loading DZ01V data from:\n  %s\n', DATA_FILE);

if ismember('Y', var_names)
    % Case 1: MAT file already contains Y.
    S = load(DATA_FILE, 'Y');
    Y = S.Y;
    clear S;

    % If num_bands is available, use it to verify/correct orientation.
    if ismember('num_bands', var_names)
        Smeta = load(DATA_FILE, 'num_bands');
        num_bands_file = double(Smeta.num_bands);
        clear Smeta;

        if size(Y,1) ~= num_bands_file && size(Y,2) == num_bands_file
            Y = Y.';
        end
    end

elseif ismember('cube_rad', var_names)
    % Case 2: MAT file was produced by make_dz01v_unmixing_mat.m.
    vars_to_load = {'cube_rad'};
    if ismember('valid_idx', var_names)
        vars_to_load{end+1} = 'valid_idx';
    elseif ismember('valid_mask', var_names)
        vars_to_load{end+1} = 'valid_mask';
    end

    S = load(DATA_FILE, vars_to_load{:});

    cube_rad = S.cube_rad;
    num_bands_cube = size(cube_rad, 1);
    Y = reshape(cube_rad, num_bands_cube, []);
    clear cube_rad;

    % Use all valid pixels prepared by the DZ01V preprocessing file.
    if isfield(S, 'valid_idx') && ~isempty(S.valid_idx)
        Y = Y(:, double(S.valid_idx));
    elseif isfield(S, 'valid_mask') && ~isempty(S.valid_mask)
        valid_idx_local = find(S.valid_mask(:));
        Y = Y(:, valid_idx_local);
        clear valid_idx_local;
    end
    clear S;

else
    error(['DZ01V_L4.mat must contain either variable ''Y'' or ''cube_rad''. ' ...
           'The preprocessing file make_dz01v_unmixing_mat.m produces ''cube_rad''.']);
end

% Match the numerical type used in the original MATLAB DeepMVSA workflow.
Y = double(Y);

% Safety filtering for a directly supplied Y. This does NOT subsample data;
% it only removes invalid or entirely-zero pixel spectra.
valid_col = all(isfinite(Y), 1) & any(Y ~= 0, 1);
if ~all(valid_col)
    fprintf('Removing %d invalid/zero pixels.\n', sum(~valid_col));
    Y = Y(:, valid_col);
end
clear valid_col;

[L, N] = size(Y);

if L < p
    error('Number of spectral bands L=%d must be >= p=%d.', L, p);
end
if N < p
    error('Not enough valid pixels: N=%d, p=%d.', N, p);
end

fprintf('\n========== DZ01V DATA ==========' );
fprintf('\nSpectral bands L       = %d\n', L);
fprintf('Valid pixels N         = %d\n', N);
fprintf('Number of endmembers p = %d\n', p);
fprintf('All %d valid pixels will participate in DeepMVSA.\n', N);
fprintf('All %d valid pixels will also be displayed in the final 2-D figure.\n', N);

%% ===================== Affine projection =====================
% This is the same affine projection step used by the supplied USGS demo.
% No additional PCA-to-10 preprocessing is introduced here.
[Y_proj, Up, ~, ~] = dataProj(Y, p, 'proj_type', 'affine');

% For the final figure, use ALL pixels and only compute the first two
% coordinates needed for display. This is equivalent to taking the first
% two rows of Up' * Y_proj, but avoids allocating the full p-by-N display
% matrix solely for visualization.
Y_plot = Up(:,1:2)' * Y_proj;

%% ===================== DeepMVSA-InvFlow =====================
tic;
[M_deep, ~, ~, ~, theta] = deep_mvsa_invflow(Y, p, ...
    'spherize', 'yes', ...
    'verbose', 1, ...
    'MM_ITERS', DEEP_MM_ITERS, ...
    'WARM_UP', DEEP_WARM_UP, ...
    'LR', DEEP_LR, ...
    'LAMBDA_VOL', DEEP_LAMBDA_VOL, ...
    'LAMBDA_NONNEG', DEEP_LAMBDA_NONNEG, ...
    'LAMBDA_EQ', DEEP_LAMBDA_EQ, ...
    'LAMBDA_SUMONE', DEEP_LAMBDA_SUMONE, ...
    'LAMBDA_ENCLOSE', DEEP_LAMBDA_ENCLOSE, ...
    'BATCH_SIZE', DEEP_BATCH_SIZE, ...
    'SEED', DEEP_SEED);
t_deep = toc;

% Same coordinate system as the displayed data.
Mdeep = Up' * M_deep;
m_deep = Mdeep(1:2, :);

fprintf('\n========== DZ01V DeepMVSA-InvFlow ==========' );
fprintf('\nRuntime                  = %.3f sec\n', t_deep);
fprintf('Mini-batch size          = %d\n', DEEP_BATCH_SIZE);
fprintf('Training iterations      = %d\n', DEEP_MM_ITERS);
fprintf('Approx. effective epochs = %.6f\n', ...
    DEEP_MM_ITERS * min(DEEP_BATCH_SIZE, N) / N);
if isstruct(theta) && isfield(theta, 'c')
    fprintf('Learned c                = %.6f\n', theta.c);
end

%% ===================== Fig. 7(a)-style 2-D result =====================
figure('Name', 'DZ01V - DeepMVSA Fig. 7(a)', 'Color', 'w');

% IMPORTANT: plot ALL valid DZ01V pixels. No display subsampling is used.
plot(Y_plot(1,:), Y_plot(2,:), '.', ...
    'Color', [0.20 0.20 0.20], ...
    'MarkerSize', 2);
hold on;

% With p=5 the true simplex is four-dimensional, so a 2-D projection does
% not have a canonical 1->2->3->4->5 polygon order. Draw the convex-hull
% outline of the five projected endmembers, while displaying ALL five
% estimated endmembers explicitly as red markers.
try
    hull_idx = convhull(m_deep(1,:)', m_deep(2,:)');
    plot(m_deep(1,hull_idx), m_deep(2,hull_idx), 'r-', ...
        'LineWidth', 2.0);
catch
    % Degenerate 2-D projection fallback: order points by polar angle.
    center = mean(m_deep, 2);
    angle = atan2(m_deep(2,:) - center(2), m_deep(1,:) - center(1));
    [~, order] = sort(angle);
    order = [order, order(1)];
    plot(m_deep(1,order), m_deep(2,order), 'r-', ...
        'LineWidth', 2.0);
end

plot(m_deep(1,:), m_deep(2,:), 'r^', ...
    'LineStyle', 'none', ...
    'MarkerSize', 9, ...
    'LineWidth', 1.5, ...
    'MarkerFaceColor', 'r');

xlabel('v_1^T Y');
ylabel('v_2^T Y');
legend('DZ01V data', 'DeepMVSA simplex', 'DeepMVSA endmembers', ...
    'Location', 'best');
title('DZ01V: DeepMVSA Estimated Dominant Endmembers');
grid on;
box on;
axis tight;

if SAVE_FIGURE
    exportgraphics(gcf, FIGURE_FILE, 'Resolution', 300);
    fprintf('Fig. 7(a)-style result saved to:\n  %s\n', FIGURE_FILE);
end
