%% demo_deepmvsa_usgs_invflow_table4_dtv_only_GYL
% TABLE 4 hyperparameter-sensitivity experiment for DeepMVSA.
%
% Purpose:
%   - Run DeepMVSA only.
%   - Use the Table-4 base configuration: K=5, N=1e4, SNR=30 dB.
%   - Repeat 20 independent trials.
%   - Compute ONLY D_TV for every trial.
%   - Report mean D_TV and sample standard deviation.
%
% Usage:
%   Manually change ONE of the five LAMBDA_* parameters below, keep all
%   others at their default values, and run this file once. The final line
%   "TABLE 4 CELL" is the value to enter into the corresponding table cell.
%
% Default values:
%   gamma_vol = LAMBDA_VOL     = 0.01
%   gamma_enc = LAMBDA_ENCLOSE = 10
%   gamma_so  = LAMBDA_SUMONE  = 2
%   lambda_nn = LAMBDA_NONNEG  = 5
%   lambda_eq = LAMBDA_EQ      = 80

clear; clc;

%% ========================== Table-4 setup ==============================
K = 5;                       % simplex dimension
p = K + 1;                   % number of vertices/endmembers
N = 10000;                   % Table 4: N = 10^4
SNR = 30;                    % Table 4: SNR = 30 dB
R = 2;                      % 20 independent repetitions
M_MC = 1e5;                  % Monte-Carlo samples used to estimate D_TV

% Synthetic-data settings inherited from the current Table-2 experiment.
SHAPE_PARAMETER = 1;
MAX_PURIRY = 0.8;
OUTLIERS = 0;

%% ========================== DeepMVSA settings ==========================
% Keep MM_ITERS / WARM_UP / LR fixed for the whole sensitivity experiment.
MM_ITERS = 1500;
WARM_UP = 400;
LR = 1e-3;

% -----------------------------------------------------------------------
% MANUALLY CHANGE ONLY ONE PARAMETER PER RUN.
% The values below are the defaults used by the current experiment.
% -----------------------------------------------------------------------
LAMBDA_VOL = 0.01;
LAMBDA_NONNEG = 5;
LAMBDA_EQ = 80;
LAMBDA_SUMONE = 2;
LAMBDA_ENCLOSE = 10;

%% ========================== Load USGS library ==========================
load('USGS_1995_Library');
datalib_all = datalib;
[~, n_materiais] = size(datalib_all);
clear datalib wavlen names;

if p > n_materiais - 4
    error('p=%d exceeds the number of selectable USGS signatures.', p);
end

%% ========================== D_TV storage ===============================
DTV_ALL = nan(R,1);

fprintf('\n=======================================================================\n');
fprintf('TABLE 4 D_TV-ONLY SENSITIVITY RUN\n');
fprintf('K=%d, p=%d, N=%d, SNR=%g dB, repetitions=%d\n', K, p, N, SNR, R);
fprintf('MM_ITERS=%d, WARM_UP=%d, LR=%g\n', MM_ITERS, WARM_UP, LR);
fprintf('LAMBDA_VOL     = %.10g\n', LAMBDA_VOL);
fprintf('LAMBDA_ENCLOSE = %.10g\n', LAMBDA_ENCLOSE);
fprintf('LAMBDA_SUMONE  = %.10g\n', LAMBDA_SUMONE);
fprintf('LAMBDA_NONNEG  = %.10g\n', LAMBDA_NONNEG);
fprintf('LAMBDA_EQ      = %.10g\n', LAMBDA_EQ);
fprintf('=======================================================================\n');

%% ========================== 20 repetitions =============================
for trial = 1:R

    fprintf('\n-------------------------- Trial %02d / %02d --------------------------\n', ...
        trial, R);

    % Fixed trial seeds make the same 20 synthetic scenes reproducible
    % across different manual hyperparameter runs.
    rng(trial, 'twister');

    %% ---------------------- Select true endmembers --------------------
    sel_mat = 4 + randperm(n_materiais - 4);
    sel_mat = sel_mat(1:p);
    M = datalib_all(:, sel_mat);

    %% ---------------------- Generate synthetic data -------------------
    Y = spectMixGen( ...
        M, N, ...
        'Source_pdf', 'Diri_id', ...
        'pdf_pars', SHAPE_PARAMETER, ...
        'max_purity', MAX_PURIRY*ones(1,p), ...
        'no_outliers', OUTLIERS, ...
        'violation_extremes', [1,1.2], ...
        'snr', SNR, ...
        'noise_shape', 'uniform');

    %% ---------------------- Affine projection -------------------------
    [Y_proj, Up] = dataProj(Y, p, 'proj_type', 'affine');

    %% ---------------------- DeepMVSA only -----------------------------
    % Fixed model seed per trial gives reproducible initialization across
    % different hyperparameter settings.
    rng(1000 + trial, 'twister');

    M_deep = deep_mvsa_invflow( ...
        Y, p, ...
        'spherize', 'yes', ...
        'verbose', 0, ...
        'MM_ITERS', MM_ITERS, ...
        'WARM_UP', WARM_UP, ...
        'LR', LR, ...
        'LAMBDA_VOL', LAMBDA_VOL, ...
        'LAMBDA_NONNEG', LAMBDA_NONNEG, ...
        'LAMBDA_EQ', LAMBDA_EQ, ...
        'LAMBDA_SUMONE', LAMBDA_SUMONE, ...
        'LAMBDA_ENCLOSE', LAMBDA_ENCLOSE);

    %% ---------------------- D_TV only ---------------------------------
    Mtrue = Up' * M;
    Mdeep = Up' * M_deep;

    % D_TV is invariant to the ordering of the simplex vertices, so no
    % endmember permutation/matching step is required here.
    rng(100000 + trial, 'twister');
    DTV_ALL(trial) = tv_dist_simplex(Mtrue, Mdeep, M_MC);

    fprintf('D_TV = %.6f\n', DTV_ALL(trial));
end

%% ========================== Final Table-4 result =======================
mean_DTV = mean(DTV_ALL);
std_DTV = std(DTV_ALL,0);    % sample standard deviation across 20 trials

fprintf('\n\n=======================================================================\n');
fprintf('FINAL TABLE 4 RESULT\n');
fprintf('-----------------------------------------------------------------------\n');
fprintf('D_TV values over %d repetitions:\n', R);
fprintf('%.6f\n', DTV_ALL);
fprintf('-----------------------------------------------------------------------\n');
fprintf('Mean D_TV = %.6f\n', mean_DTV);
fprintf('Std  D_TV = %.6f\n', std_DTV);
fprintf('TABLE 4 CELL = %.4f (%.4f)\n', mean_DTV, std_DTV);
fprintf('=======================================================================\n');

%% ========================== Local functions ============================
function D_TV = tv_dist_simplex(M_T, M_E, M_MC)
%TV_DIST_SIMPLEX Total-variation distance between uniform distributions
%on two K-simplices, using the symmetric Monte-Carlo estimator inherited
%from the current Table-2 experiment.
%
%   D_TV = 1 - Vol(S_T intersection S_E) / max(Vol(S_T), Vol(S_E)).

p_local = size(M_T, 2);
K_local = p_local - 1;

E_T = M_T(:,2:p_local) - repmat(M_T(:,1), 1, K_local);
E_E = M_E(:,2:p_local) - repmat(M_E(:,1), 1, K_local);
vol_T = sqrt(max(det(E_T'*E_T), 0)) / factorial(K_local);
vol_E = sqrt(max(det(E_E'*E_E), 0)) / factorial(K_local);

G = -log(rand(p_local, M_MC));
alpha = G ./ repmat(sum(G,1), p_local, 1);
r_T = mean(in_simplex(M_T*alpha, M_E));

G = -log(rand(p_local, M_MC));
alpha = G ./ repmat(sum(G,1), p_local, 1);
r_E = mean(in_simplex(M_E*alpha, M_T));

vol_int = 0.5 * (r_T*vol_T + r_E*vol_E);
D_TV = max(1 - vol_int/max(vol_T, vol_E), 0);
end

function inside = in_simplex(X, M)
%IN_SIMPLEX Barycentric membership test for columns of X in conv(M).
tol = 1e-8;
m0 = M(:,1);
E = M(:,2:end) - repmat(m0, 1, size(M,2)-1);
C = E \ (X - repmat(m0, 1, size(X,2)));
inside = all(C >= -tol, 1) & (1 - sum(C,1) >= -tol);
end
