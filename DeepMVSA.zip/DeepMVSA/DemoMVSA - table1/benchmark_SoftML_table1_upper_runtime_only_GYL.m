%% benchmark_SoftML_table1_upper_runtime_only_GYL
% Table 1: Soft-ML full-model runtime benchmark.
%
% DATA PROTOCOL:
%   Synthetic-data generation and scene settings are unchanged from the
%   supplied Soft-ML memory benchmark.
%
% RUNTIME PROTOCOL:
%   Runtime is exactly the wall-clock time immediately before and after the
%   complete SoftML_Simplex_2021_v3_memory() function call.
%
%   Included in timing: all work executed inside the Soft-ML function call,
%   including intrinsic-coordinate construction from YProj/Up/my, convex hull,
%   dataset diameter, initialization, Algorithm 1, final objective/endmember
%   recovery, abundance estimation, output construction, and MTrue error.
%
%   Excluded from timing: USGS loading, PCA/FP8 preparation, spectMixGen, and
%   the external dataProj() call, because these occur before softml_tic.
%
%   All memory-monitoring code and memory-related options are removed.

clear all; clc; close all;

% Ensure this folder's instrumented Soft-ML file has path priority.
this_file = mfilename('fullpath');
this_dir = fileparts(this_file);
addpath(this_dir, '-begin');
fprintf('Using Soft-ML file: %s', which('SoftML_Simplex_2021_v3_memory'));
clear this_file this_dir;

%% ===================== Table 1 upper-panel settings =====================
p = 6;                  % PRESERVED from uploaded file. NOTE: if Table 1 upper panel is K=2, set p=3.
N = 1000000;              % manually use 1e4, 1e5, 1e6, ...
SNR = 20;
SHAPE_PARAMETER = 1;
MAX_PURIRY = 0.8;
OUTLIERS = 0;


% Same synthetic scene whenever only N/measurement settings are changed.
rng(1, 'twister');

%% ===================== Prepare synthetic data =====================
load('USGS_1995_Library')
[~, n_materiais] = size(datalib);

% Select the same p endmembers in the original USGS spectral space.
sel_mat = 4 + randperm(n_materiais - 4);
sel_mat = sel_mat(1:p);
M_original = double(datalib(:, sel_mat));

% ---------------------------------------------------------------
% 1) Reduce the selected endmembers to 20 spectral dimensions.
%    The 20-D PCA basis is learned from the COMPLETE USGS library,
%    not from only the p selected endmembers.
% ---------------------------------------------------------------
TARGET_L = 30;
Xlib = double(datalib);
mu_lib = mean(Xlib, 2);
Xlib_centered = Xlib - mu_lib;
[Ulib, ~, ~] = svd(Xlib_centered, 'econ');

if size(Ulib, 2) < TARGET_L
    error('USGS library has fewer than %d available PCA dimensions.', TARGET_L);
end

P20 = Ulib(:, 1:TARGET_L);
M_20 = P20' * (M_original - mu_lib);       % 20 x p

% ---------------------------------------------------------------
% 2) Quantize M_20 to FP8 E4M3 values.
%
% MATLAB does not provide a general native FP8 numeric matrix that can be
% passed directly to legacy MATLAB functions such as spectMixGen. Therefore
% M below is stored as ordinary MATLAB numeric values, but every element is
% rounded to the FP8-E4M3 representable grid before spectMixGen sees it.
% Thus spectMixGen uses the FP8-quantized 20-D ground-truth endmembers.
% ---------------------------------------------------------------
M = fp8_e4m3_quantize(M_20);              % 20 x p, FP8-quantized values

fprintf('Original M size           : %d x %d\n', size(M_original,1), size(M_original,2));
fprintf('Reduced/FP8 M size        : %d x %d\n', size(M,1), size(M,2));
fprintf('M values quantized to     : FP8 E4M3 grid\n');

clear datalib wavlen names sel_mat n_materiais;
clear Xlib Xlib_centered Ulib P20 mu_lib M_original M_20 TARGET_L;

fprintf('Generating N=%d samples for K=%d (p=%d)...\n', N, p-1, p);
[Y, ~, ~] = spectMixGen(M, N, ...
    'Source_pdf', 'Diri_id', ...
    'pdf_pars', SHAPE_PARAMETER, ...
    'max_purity', MAX_PURIRY * ones(1,p), ...
    'no_outliers', OUTLIERS, ...
    'violation_extremes', [1,1.2], ...
    'snr', SNR, ...
    'noise_shape', 'uniform');
fprintf('Data generation finished.\n');

%% ===================== Prepare affine projection for Soft-ML =====================
% Use the same external affine projection interface as the reference call.
[Y_proj, Up, my, sing_val] = dataProj(Y, p, 'proj_type', 'affine'); %#ok<ASGLU>

%% ===================== Run Soft-ML: full function-call runtime =====================
fprintf('\nRunning Soft-ML full-model runtime benchmark...\n');

% Timer starts immediately before the complete Soft-ML function call.
softml_tic = tic;

[M_softml, S_softml, softml_out] = SoftML_Simplex_2021_v3_runtime( ... %#ok<NASGU>
    Y, p, ...
    'YProj', Y_proj, ...
    'Up', Up, ...
    'my', my, ...
    'MTrue', M, ...
    'MaxIter', 1, ...
    'Gamma', [], ...
    'Alpha', [], ...
    'UseConvexHullInit', true, ...
    'UseHullGradient', true, ...
    'Seed', 1, ...
    'Plot', false, ...
    'Verbose', false);

% Timer stops immediately after the function returns.
softml_runtime_sec = toc(softml_tic);

fprintf('\n---------------------------------------------------------------\n');
fprintf('Soft-ML full-call runtime     : %.6f sec\n', softml_runtime_sec);
fprintf('Soft-ML full-call runtime     : %.3f min\n', softml_runtime_sec / 60);
fprintf('Soft-ML full-call runtime     : %.3f h\n', softml_runtime_sec / 3600);
fprintf('---------------------------------------------------------------\n');


%% ===================== Local helper: FP8 E4M3 quantization =====================
function y = fp8_e4m3_quantize(x)
%FP8_E4M3_QUANTIZE Round real values to an FP8-E4M3 representable grid.
%
% Format used here:
%   sign      : 1 bit
%   exponent  : 4 bits, bias = 7
%   mantissa  : 3 bits
%   normals   : exponent -6 ... +7
%   subnormal quantum: 2^-9
%   max finite magnitude: 240
%
% The returned MATLAB array is double for compatibility with spectMixGen,
% but its numerical values have already been rounded to FP8 E4M3 levels.

    x = double(x);
    y = zeros(size(x), 'double');

    s = sign(x);
    a = abs(x);

    % Preserve NaN separately.  Infinite inputs saturate to max finite.
    nan_mask = isnan(a);
    inf_mask = isinf(a);
    finite_mask = isfinite(a) & (a > 0);

    a(inf_mask) = 240;

    % E4M3 constants (IEEE-style finite range used in this experiment).
    min_normal = 2^-6;
    sub_step   = 2^-9;
    max_finite = 240;

    % ----- Subnormal region -----
    sub_mask = finite_mask & (a < min_normal);
    if any(sub_mask(:))
        q = round(a(sub_mask) / sub_step) * sub_step;
        y(sub_mask) = min(q, min_normal);
    end

    % ----- Normal region -----
    normal_mask = finite_mask & (a >= min_normal);
    if any(normal_mask(:))
        av = min(a(normal_mask), max_finite);
        e = floor(log2(av));
        e = max(-6, min(7, e));
        step = 2.^(e - 3);          % three explicit mantissa bits
        q = round(av ./ step) .* step;
        q = min(q, max_finite);
        y(normal_mask) = q;
    end

    y(inf_mask) = max_finite;
    y = y .* s;
    y(nan_mask) = NaN;
end
