function [M_est, Sest, Up, my, theta] = deep_mvsa_invflow_memory(Y, p, varargin)
%% DeepMVSA-InvFlow -- full-Y / MATLAB-native memory benchmark version for Table 1
% This version keeps the COMPLETE input matrix Y in memory, but is designed
% for N=1e8 with a low ambient dimension (Table-1 upper panel: K=2, p=L=3)
% and single-precision input storage.
%
% Important distinction:
%   - Y is fully materialized (NOT a streaming/virtual data set).
%   - Optimization still uses random mini-batches from this complete Y.
%   - For very large N, set RETURN_FULL_ABUNDANCE=false so p-by-N Sest is
%     not materialized after optimization.
%
% Memory reductions relative to the previous implementation:
% MATLAB-native Table-1 instrumentation uses memory().MemUsedMATLAB and
% explicit allocation checkpoints; no PowerShell/OS polling is used.
%   1) no full Yc, Yp, Y_proj copies;
%   2) no full coordinate matrix -- coordinates are generated from indices;
%   3) q_m uses sum(Y_work,2), not ones(1,N)*Y_work';
%   4) VCA initialization can use a bounded subset;
%   5) Y and Y_work remain single as persistent large arrays.  Preprocessing
%      uses one temporary double copy at a time for accurate global moments;
%      optimizer mini-batches are also cast to double.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @isnumeric);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);
addParameter(pStruct, 'BATCH_SIZE', 4096, @(x) isnumeric(x) && isscalar(x) && x >= 1);
addParameter(pStruct, 'SEED', [], @isnumeric);
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'MEASURE_OPT_MEMORY', false, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
addParameter(pStruct, 'MEMORY_BASELINE_SAMPLES', 7, @(x) isnumeric(x) && isscalar(x) && x >= 1);
addParameter(pStruct, 'MEMORY_CHECKPOINT_EVERY', 100, @(x) isnumeric(x) && isscalar(x) && x >= 1);
addParameter(pStruct, 'RETURN_FULL_ABUNDANCE', true, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
addParameter(pStruct, 'VCA_INIT_SAMPLES', 200000, @(x) isnumeric(x) && isscalar(x) && x >= p);
addParameter(pStruct, 'NORMALIZE_SAMPLE_PENALTIES', false, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
parse(pStruct, varargin{:});

if ~isempty(pStruct.Results.SEED)
    rng(pStruct.Results.SEED, 'twister');
end

if isempty(Y) || ~isnumeric(Y) || ndims(Y) ~= 2
    error('Y must be a nonempty numeric L-by-N matrix.');
end

[L, N] = size(Y);
if L < p
    error('Need L >= p. Received L=%d, p=%d.', L, p);
end
B = min(floor(double(pStruct.Results.BATCH_SIZE)), N);
return_full_abundance = logical(pStruct.Results.RETURN_FULL_ABUNDANCE);
normalize_sample_penalties = logical(pStruct.Results.NORMALIZE_SAMPLE_PENALTIES);

if pStruct.Results.verbose
    fprintf('Full-Y mode: Y is %d x %d, class=%s, %.3f GiB\n', ...
        L, N, class(Y), numel(Y) * bytes_per_element(Y) / 1024^3);
end

%% --------------------- Memory-efficient preprocessing ---------------------
[my, Up, D, C, lambda_reg, Y_work] = ...
    build_work_matrix_memory_efficient(Y, p, pStruct.Results.spherize);

%% --------------------- Initialization ---------------------
if isempty(pStruct.Results.M0)
    n_init = min(N, floor(double(pStruct.Results.VCA_INIT_SAMPLES)));
    if n_init < N
        init_idx = unique(round(linspace(1, N, n_init)));
        M0 = VCA(double(Y_work(:, init_idx)), 'Endmembers', p, 'verbose', 'off');
        clear init_idx
    else
        M0 = VCA(double(Y_work), 'Endmembers', p, 'verbose', 'off');
    end
else
    M0 = double(pStruct.Results.M0);
    if strcmp(pStruct.Results.spherize, 'yes')
        M0 = M0 - my;
        M0 = C * Up(:,1:p-1)' * M0;
        M0(p,:) = 1;
        M0 = M0 / sqrt(p);
    else
        M0 = Up' * M0;
    end
end
Q0 = inv(double(M0));

% q_m = 1'Y_work' * inv(Y_work*Y_work') without allocating ones(1,N).
% Use one temporary double copy for accurate accumulation over N=1e8.
Y_work_double = double(Y_work);
sum_ywork = sum(Y_work_double, 2);
gram_ywork = Y_work_double * Y_work_double';
qm = sum_ywork' / gram_ywork;
clear Y_work_double sum_ywork gram_ywork M0

%% --------------------- Coordinate geometry (NO O(N) coords array) ---------------------
H = round(sqrt(double(N)));
W = round(double(N) / H);
is_grid = (double(H) * double(W) == double(N));
if is_grid
    coord_dim = 2;
else
    coord_dim = 1;
end

%% -------- Theorem 3.2 optimization-memory measurement (MATLAB-native) --------
% The measurement interval starts AFTER preprocessing / VCA / q_m creation
% and immediately BEFORE A-Net parameters + Adam states are allocated.
%
% Unlike the previous PowerShell sampler, this version uses MATLAB's own
% memory().MemUsedMATLAB and explicit allocation checkpoints.  Therefore
% short-lived optimization allocations are sampled at known code locations
% rather than hoping that an external time-based poll catches them.
measure_opt_memory = logical(pStruct.Results.MEASURE_OPT_MEMORY);
memory_checkpoint_every = max(1, floor(double(pStruct.Results.MEMORY_CHECKPOINT_EVERY)));
opt_tic = [];

if measure_opt_memory
    if ~ispc
        error(['MEASURE_OPT_MEMORY=true in this instrumented file uses MATLAB memory(), ' ...
               'which is intended for the Windows MATLAB Table-1 benchmark.']);
    end

    matlab_native_memory_monitor('reset');
    matlab_native_memory_monitor('start', 'optimization baseline', ...
        round(pStruct.Results.MEMORY_BASELINE_SAMPLES));
    opt_tic = tic;
end

%% --------------------- A-Net parameters ---------------------
hidden = 32;
theta.W1 = 0.01*randn(hidden, coord_dim); theta.b1 = zeros(hidden,1);
theta.W2 = 0.01*randn(hidden, hidden);    theta.b2 = zeros(hidden,1);
theta.W3 = 0.01*randn(p, hidden);         theta.b3 = zeros(p,1);
theta.Wg1 = 0.01*randn(hidden, coord_dim); theta.bg1 = zeros(hidden,1);
theta.Wg2 = 0.01*randn(p, hidden);         theta.bg2 = zeros(p,1);
theta.c = 0.05;

theta.L = zeros(p,p);
theta.R = zeros(p,p);
theta.r_log = zeros(p,1);

m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

if measure_opt_memory
    % Exact MATLAB array bytes for learnable parameters + both Adam buffers.
    % This quantity is deterministic for fixed p/coord_dim and is reported as
    % a stable diagnostic alongside the process-level MATLAB memory delta.
    state_info = whos('theta', 'm', 'v');
    exact_state_bytes = sum([state_info.bytes]);
    matlab_native_memory_monitor('set_state_bytes', 'theta + Adam(m,v)', exact_state_bytes);
    matlab_native_memory_monitor('sample_process', 'after theta + Adam allocation');
    clear state_info exact_state_bytes
end

if pStruct.Results.verbose
    fprintf('Mini-batch optimizer over COMPLETE Y: N=%d, batch=%d\n', N, B);
end

%% --------------------- Warm-up ---------------------
if pStruct.Results.verbose, fprintf('Warm-up (linear, fixed Q)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    do_mem_checkpoint = measure_opt_memory && ...
        (k == 1 || mod(k, memory_checkpoint_every) == 0 || k == pStruct.Results.WARM_UP);

    if do_mem_checkpoint
        matlab_native_memory_monitor('arm', sprintf('warm-up iter %d', k));
    end

    [Yb, cb] = next_batch_indexed(Y_work, N, B, H, W, is_grid);

    if do_mem_checkpoint
        matlab_native_memory_monitor('sample_process', sprintf('warm-up %d: mini-batch ready', k));
    end

    [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_SUMONE, pStruct.Results.LAMBDA_ENCLOSE, ...
        true, N, normalize_sample_penalties);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;

    if do_mem_checkpoint
        matlab_native_memory_monitor('sample_process', sprintf('warm-up %d: post Adam', k));
        matlab_native_memory_monitor('disarm');
    end

    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Warm-up %d/%d, loss=%.6f\n', k, pStruct.Results.WARM_UP, loss);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + nonlinear)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
for k = 1:n_joint
    do_mem_checkpoint = measure_opt_memory && ...
        (k == 1 || mod(k, memory_checkpoint_every) == 0 || k == n_joint);

    if do_mem_checkpoint
        matlab_native_memory_monitor('arm', sprintf('joint iter %d', k));
    end

    [Yb, cb] = next_batch_indexed(Y_work, N, B, H, W, is_grid);

    if do_mem_checkpoint
        matlab_native_memory_monitor('sample_process', sprintf('joint %d: mini-batch ready', k));
    end

    [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, pStruct.Results.LAMBDA_SUMONE, ...
        pStruct.Results.LAMBDA_ENCLOSE, false, N, normalize_sample_penalties);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;

    if do_mem_checkpoint
        matlab_native_memory_monitor('sample_process', sprintf('joint %d: post Adam', k));
        matlab_native_memory_monitor('disarm');
    end

    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Joint %d/%d, loss=%.6f, c=%.4f\n', k, n_joint, loss, theta.c);
    end
end

%% -------- End optimization-memory measurement --------
if measure_opt_memory
    optimization_runtime_sec = toc(opt_tic);
    matlab_native_memory_monitor('sample_process', 'end of joint training');
    opt_mem_report = matlab_native_memory_monitor('stop');

    % Expose the measurement through theta without changing the function
    % signature or the mathematical optimization.
    theta.memory_stats = opt_mem_report;
    theta.memory_stats.optimization_runtime_sec = optimization_runtime_sec;

    fprintf('\n=======================================================================\n');
    fprintf('THEOREM 3.2 MATLAB-NATIVE OPTIMIZATION-MEMORY MEASUREMENT\n');
    fprintf('-----------------------------------------------------------------------\n');
    fprintf('N                                   : %d\n', N);
    fprintf('K                                   : %d\n', p - 1);
    fprintf('p = K+1                             : %d\n', p);
    fprintf('Batch size                          : %d\n', B);
    fprintf('Full Y stored                       : yes (%s)\n', class(Y));
    fprintf('Baseline MATLAB MemUsed             : %.2f MB\n', opt_mem_report.baseline_mb);
    fprintf('Peak MATLAB MemUsed (optimization)  : %.2f MB\n', opt_mem_report.peak_mb);
    fprintf('Peak optimization delta             : %.2f MB   <-- Table 1 memory\n', ...
        opt_mem_report.delta_mb);
    fprintf('Peak process checkpoint             : %s\n', opt_mem_report.peak_label);
    fprintf('Exact theta + Adam state            : %.2f MB\n', opt_mem_report.state_bytes/1024^2);
    fprintf('Peak local workspace arrays         : %.2f MB\n', ...
        opt_mem_report.peak_local_workspace_bytes/1024^2);
    fprintf('Peak local-workspace checkpoint     : %s\n', ...
        opt_mem_report.peak_local_workspace_label);
    fprintf('Process-memory checkpoints          : %d\n', opt_mem_report.process_samples);
    fprintf('Local-workspace checkpoints         : %d\n', opt_mem_report.local_samples);
    fprintf('Optimization runtime                : %.6f sec\n', optimization_runtime_sec);
    fprintf('=======================================================================\n\n');
end

%% --------------------- Recover endmembers ---------------------
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M_sub = inv(Q);

if strcmp(pStruct.Results.spherize, 'yes')
    M_sub = M_sub * sqrt(p);
    M_sub = M_sub(1:p-1,:);
    M_est = Up(:,1:p-1) * diag(sqrt(diag(D) + lambda_reg)) * M_sub + my;
else
    M_est = Up * M_sub;
end

%% --------------------- Optional full abundance output ---------------------
if return_full_abundance
    CHUNK = min(N, 1048576);
    Sest = zeros(p, N);
    for i1 = 1:CHUNK:N
        i2 = min(i1 + CHUNK - 1, N);
        idx = i1:i2;
        cb = coordinates_from_indices(idx, N, H, W, is_grid);
        Sest(:, i1:i2) = abundance_net_forward_nl(cb, theta, false);
    end
else
    Sest = [];
end
end

%% ===================== Large-array helpers =====================
function [my, Up, D, C, lambda_reg, Y_work] = build_work_matrix_memory_efficient(Y, p, spherize)
%BUILD_WORK_MATRIX_MEMORY_EFFICIENT  Avoids Yc/Yp/Y_proj full-size copies.
[L, N] = size(Y);
% Y remains single persistently, but a temporary full double copy gives
% accurate global mean/covariance accumulation at N=1e8.  For L=p=3 this
% temporary is only about 2.235 GiB and is cleared before Y_work is built.
Y_double = double(Y);
my = mean(Y_double, 2);
YYt = (Y_double * Y_double') / double(N);
clear Y_double
Cov = YYt - my * my';
Cov = (Cov + Cov') / 2;

[V, evals] = eig(Cov, 'vector');
[evals, order] = sort(real(evals), 'descend');
if numel(evals) < p-1
    error('Insufficient covariance rank for p=%d.', p);
end
Up_sub = real(V(:, order(1:p-1)));
selected = max(real(evals(1:p-1)), 0);
D = diag(selected);

my_ortho = my - Up_sub * (Up_sub' * my);
denom = norm(my_ortho);
if denom <= 1e-12
    error('Degenerate affine mean direction encountered during preprocessing.');
end
Up = [Up_sub, my_ortho / denom];

if strcmp(spherize, 'yes')
    lambda_reg = 1e-10;
    C = diag(1 ./ sqrt(diag(D) + lambda_reg));

    % Algebraically equivalent to whitening the affine projection:
    % C*Up_sub'*(Y-my)/sqrt(p), without materializing Yc or Yp.
    T = (C * Up_sub') / sqrt(p);
    T_store = cast(T, 'like', Y);
    offset_store = cast(T * my, 'like', Y);

    Y_work = zeros(p, N, 'like', Y);
    Y_work(1:p-1,:) = T_store * Y;
    Y_work(1:p-1,:) = Y_work(1:p-1,:) - offset_store;
    Y_work(p,:) = cast(1/sqrt(p), 'like', Y);
else
    lambda_reg = 0;
    C = [];
    T = Up';
    T_store = cast(T, 'like', Y);
    Y_work = T_store * Y;
end

if size(Y_work,1) ~= p
    error('Internal preprocessing error: expected p-by-N work matrix.');
end
end

function [Yb, cb] = next_batch_indexed(Y_work, N, B, H, W, is_grid)
%NEXT_BATCH_INDEXED Draw from the COMPLETE Y_work and create only B coords.
idx = randi(N, 1, B);
Yb = double(Y_work(:, idx));
cb = coordinates_from_indices(idx, N, H, W, is_grid);
end

function cb = coordinates_from_indices(idx, N, H, W, is_grid)
idx0 = double(idx) - 1;
if is_grid
    % Reproduce MATLAB column-major gx(:), gy(:) ordering without meshgrid.
    row0 = mod(idx0, double(H));
    col0 = floor(idx0 / double(H));
    if W > 1
        x = -1 + 2 * col0 / double(W - 1);
    else
        x = zeros(size(col0));
    end
    if H > 1
        y = -1 + 2 * row0 / double(H - 1);
    else
        y = zeros(size(row0));
    end
    cb = [x; y];
else
    if N > 1
        cb = -1 + 2 * idx0 / double(N - 1);
    else
        cb = zeros(size(idx0));
    end
end
end

function n = bytes_per_element(A)
switch class(A)
    case {'double','int64','uint64'}
        n = 8;
    case {'single','int32','uint32'}
        n = 4;
    case {'int16','uint16'}
        n = 2;
    otherwise
        n = 1;
end
end

%% ===================== Optimization helpers =====================
function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)));
end
end

function [A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up)
Z1 = theta.W1*coords + theta.b1; H1 = tanh(Z1);
Z2 = theta.W2*H1 + theta.b2;     H2 = tanh(Z2);
Z3 = theta.W3*H2 + theta.b3;
Z3 = Z3 - max(Z3,[],1); expZ = exp(Z3);
A_base = expZ ./ sum(expZ,1);

Zg1 = theta.Wg1*coords + theta.bg1; Hg1 = tanh(Zg1);
Zg2 = theta.Wg2*Hg1 + theta.bg2;
G = 1./(1+exp(-Zg2));

c = warm_up*0 + (1-warm_up)*theta.c;
A_eff = A_base + c*(G.*(A_base.^2));

cache.Z1=Z1; cache.H1=H1; cache.Z2=Z2; cache.H2=H2; cache.Z3=Z3;
cache.expZ=expZ; cache.coords=coords;
cache.Zg1=Zg1; cache.Hg1=Hg1; cache.Zg2=Zg2; cache.G=G;
cache.A_base=A_base; cache.c=c; cache.warm_up=warm_up;

if matlab_native_memory_monitor('is_armed')
    local_info = whos;
    matlab_native_memory_monitor('sample_local', 'A-Net forward live set', ...
        sum([local_info.bytes]));
    clear local_info
end
end

function grad = abundance_net_backward_nl(dA_eff, cache, theta)
A_base = cache.A_base; G = cache.G; c = cache.c; warm_up = cache.warm_up;

dA_base = dA_eff + 2*c*G.*A_base.*dA_eff;
dG = c*(A_base.^2).*dA_eff;
dc = sum(sum((G.*(A_base.^2)).*dA_eff));

if warm_up
    grad.Wg1 = zeros(size(theta.Wg1)); grad.bg1 = zeros(size(theta.bg1));
    grad.Wg2 = zeros(size(theta.Wg2)); grad.bg2 = zeros(size(theta.bg2));
    grad.c = 0;
else
    dZg2 = dG.*(G.*(1-G));
    grad.Wg2 = dZg2*cache.Hg1'; grad.bg2 = sum(dZg2,2);
    dHg1 = theta.Wg2'*dZg2;
    dZg1 = dHg1.*(1-tanh(cache.Zg1).^2);
    grad.Wg1 = dZg1*cache.coords'; grad.bg1 = sum(dZg1,2);
    grad.c = dc;
end

A = cache.expZ ./ sum(cache.expZ,1);
dZ3 = A.*(dA_base - sum(A.*dA_base,1));
grad.W3 = dZ3*cache.H2'; grad.b3 = sum(dZ3,2);
dH2 = theta.W3'*dZ3;
dZ2 = dH2.*(1-tanh(cache.Z2).^2);
grad.W2 = dZ2*cache.H1'; grad.b2 = sum(dZ2,2);
dH1 = theta.W2'*dZ2;
dZ1 = dH1.*(1-tanh(cache.Z1).^2);
grad.W1 = dZ1*cache.coords'; grad.b1 = sum(dZ1,2);

if matlab_native_memory_monitor('is_armed')
    local_info = whos;
    matlab_native_memory_monitor('sample_local', 'A-Net backward live set', ...
        sum([local_info.bytes]));
    clear local_info
end
end

function [loss, grad] = compute_gradients_invflow(theta, Y, coords, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, lambda_enclose, ...
    warm_up, N_total, normalize_sample_penalties)
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q);

[A_eff, ~, ~, cache] = abundance_net_forward_nl(coords, theta, warm_up);

Nb = size(Y, 2);
if normalize_sample_penalties
    % Unbiased estimator of (1/N) sum_j penalty_j used in Eq. (14).
    sample_scale = 1 / Nb;
else
    % Legacy behavior retained for compatibility with previous scripts.
    sample_scale = N_total / Nb;
end

Y_hat = M * A_eff;
diff = Y_hat - Y;
loss_recon = mean(sum(diff.^2,1));
loss_vol = -sum(theta.r_log);

if matlab_native_memory_monitor('is_armed')
    local_info = whos;
    matlab_native_memory_monitor('sample_local', 'reconstruction live set', ...
        sum([local_info.bytes]));
    clear local_info
end

penalty = min(A_eff,0);
loss_nonneg = sample_scale * sum(penalty.^2, 'all');

sum_A = sum(A_eff,1);
loss_sumone = sample_scale * sum((sum_A-1).^2, 'all');

col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');

QY = Q*Y;
pen_enclose = min(QY, 0);
loss_enclose = sample_scale * sum(pen_enclose.^2, 'all');

if matlab_native_memory_monitor('is_armed')
    local_info = whos;
    matlab_native_memory_monitor('sample_local', 'enclosure live set', ...
        sum([local_info.bytes]));
    clear local_info
end

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + lambda_enclose*loss_enclose;

dY_hat = 2*diff/Nb;
dM = dY_hat * A_eff';
grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * sample_scale * pen_enclose * Y';
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

if matlab_native_memory_monitor('is_armed')
    local_info = whos;
    matlab_native_memory_monitor('sample_local', 'Q-gradient live set', ...
        sum([local_info.bytes]));
    clear local_info
end

grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

dA_eff = M' * dY_hat + sample_scale * (2*lambda_nonneg*penalty + ...
    2*lambda_sumone*repmat(sum_A-1, p, 1));
grad_net = abundance_net_backward_nl(dA_eff, cache, theta);
grad.W1 = grad_net.W1; grad.b1 = grad_net.b1;
grad.W2 = grad_net.W2; grad.b2 = grad_net.b2;
grad.W3 = grad_net.W3; grad.b3 = grad_net.b3;
grad.Wg1 = grad_net.Wg1; grad.bg1 = grad_net.bg1;
grad.Wg2 = grad_net.Wg2; grad.bg2 = grad_net.bg2;
grad.c = grad_net.c;

if matlab_native_memory_monitor('is_armed')
    local_info = whos;
    matlab_native_memory_monitor('sample_local', 'gradient assembly live set', ...
        sum([local_info.bytes]));
    clear local_info
end
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr)
beta1 = 0.9; beta2 = 0.999; eps0 = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*(grad.(f).^2);
    m_hat = m.(f) / (1 - beta1^iter);
    v_hat = v.(f) / (1 - beta2^iter);
    theta.(f) = theta.(f) - lr * m_hat ./ (sqrt(v_hat) + eps0);
end
end

%% ===================== MATLAB-native memory-monitor helper =====================
function out = matlab_native_memory_monitor(action, label, value)
%MATLAB_NATIVE_MEMORY_MONITOR  Stable checkpoint-based Table-1 memory monitor.
%
% Main metric:
%   peak optimization delta =
%       max_t memory().MemUsedMATLAB(t) - baseline MemUsedMATLAB
%
% The baseline is taken after preprocessing/VCA/q_m and immediately before
% learnable parameters + Adam states are allocated.  Process memory is then
% sampled at explicit allocation checkpoints.  This avoids the timing jitter
% of an external polling process.
%
% A second diagnostic, peak_local_workspace_bytes, is supplied explicitly by
% whos at selected high-live-set locations.  It is deterministic for fixed
% array shapes and helps verify that a process-memory peak is plausible.
%
% Actions:
%   reset
%   start(label, n_baseline_samples)
%   arm(label) / disarm
%   is_armed
%   sample_process(label)
%   sample_local(label, live_workspace_bytes)
%   set_state_bytes(label, bytes)
%   stop

    persistent S

    if nargin < 2 || isempty(label)
        label = '';
    end
    if nargin < 3
        value = [];
    end

    switch lower(action)
        case 'reset'
            S = [];
            out = [];

        case 'start'
            if ~ispc
                error('MATLAB-native memory benchmark is configured for Windows MATLAB.');
            end

            n_samples = 7;
            if ~isempty(value)
                n_samples = max(1, round(double(value)));
            end

            baseline_samples = zeros(1, n_samples);
            for ii = 1:n_samples
                u = memory;
                baseline_samples(ii) = double(u.MemUsedMATLAB);
                if ii < n_samples
                    pause(0.01);
                end
            end

            baseline_bytes = median(baseline_samples);

            S = struct();
            S.baseline_bytes = baseline_bytes;
            S.peak_bytes = baseline_bytes;
            S.peak_label = char(label);
            S.process_samples = 0;
            S.armed = false;
            S.arm_label = '';
            S.state_bytes = 0;
            S.state_label = '';
            S.peak_local_workspace_bytes = 0;
            S.peak_local_workspace_label = '';
            S.local_samples = 0;

            out = S;

        case 'arm'
            if isempty(S)
                out = [];
                return;
            end
            S.armed = true;
            S.arm_label = char(label);
            out = [];

        case 'disarm'
            if ~isempty(S)
                S.armed = false;
                S.arm_label = '';
            end
            out = [];

        case 'is_armed'
            out = ~isempty(S) && S.armed;

        case 'set_state_bytes'
            if isempty(S)
                out = [];
                return;
            end
            S.state_bytes = double(value);
            S.state_label = char(label);
            out = [];

        case 'sample_process'
            if isempty(S)
                out = [];
                return;
            end

            u = memory;
            current_bytes = double(u.MemUsedMATLAB);
            S.process_samples = S.process_samples + 1;

            full_label = compose_monitor_label(S, label);
            if current_bytes > S.peak_bytes
                S.peak_bytes = current_bytes;
                S.peak_label = full_label;
            end
            out = current_bytes;

        case 'sample_local'
            if isempty(S) || ~S.armed
                out = [];
                return;
            end

            live_bytes = double(value);
            S.local_samples = S.local_samples + 1;

            full_label = compose_monitor_label(S, label);
            if live_bytes > S.peak_local_workspace_bytes
                S.peak_local_workspace_bytes = live_bytes;
                S.peak_local_workspace_label = full_label;
            end

            % Also take the MATLAB process-memory checkpoint at exactly this
            % known high-live-set location.
            u = memory;
            current_bytes = double(u.MemUsedMATLAB);
            S.process_samples = S.process_samples + 1;
            if current_bytes > S.peak_bytes
                S.peak_bytes = current_bytes;
                S.peak_label = full_label;
            end

            out = current_bytes;

        case 'stop'
            if isempty(S)
                out = struct();
                return;
            end

            u = memory;
            current_bytes = double(u.MemUsedMATLAB);
            S.process_samples = S.process_samples + 1;
            if current_bytes > S.peak_bytes
                S.peak_bytes = current_bytes;
                S.peak_label = 'stop';
            end

            S.baseline_mb = S.baseline_bytes / 1024^2;
            S.peak_mb = S.peak_bytes / 1024^2;
            S.delta_mb = max(S.peak_bytes - S.baseline_bytes, 0) / 1024^2;

            out = S;
            S = [];

        otherwise
            error('Unknown MATLAB-native memory-monitor action: %s', action);
    end
end

function label_out = compose_monitor_label(S, label_in)
%COMPOSE_MONITOR_LABEL Include the armed training-stage label when present.
    if isempty(S.arm_label)
        label_out = char(label_in);
    elseif isempty(label_in)
        label_out = S.arm_label;
    else
        label_out = sprintf('%s / %s', S.arm_label, char(label_in));
    end
end

