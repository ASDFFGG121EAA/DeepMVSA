function [M_est, S_est, out] = SoftML_Simplex_2021_v3_memory(Y, p, varargin)
% IMPLEMENTATION_VERSION = '2026-08-14-v3-existing-data-only';
% SoftML_Simplex_2021_v3_memory
% =========================================================================
% MATLAB复现：
%   A. Najafi et al.,
%   "On Statistical Learning of Simplices: Unmixing Problem Revisited",
%   The Annals of Statistics, 2021.
%
% 复现内容：
%   1) 论文 Definition 2.2：planar distance d_S(x)
%   2) 论文 Definition 3.1：CRR 连续松弛风险
%   3) Soft-ML 损失 l(u)=1-exp(-b*u)
%   4) Theorem 3.3：样本距离项关于单纯形顶点的解析梯度
%   5) 式 (3.5)：单纯形体积
%   6) 式 (3.9)：CRR 总梯度
%   7) Algorithm 1：固定步长梯度下降
%   8) Section 4.1：Convex-hull 初始化
%   9) Section 4.1：可选的 Convex-hull 梯度加速
%  10) 端元恢复与重心坐标/丰度估计
%
% -------------------------------------------------------------------------
% 最简单的使用方式
% -------------------------------------------------------------------------
% 假设高光谱数据为：
%   Y : L x N，L 为波段数，N 为像元数
%   p : 端元数（= 单纯形顶点数）
%
% 直接运行：
%
%   [M_est, S_est, out] = SoftML_Simplex_2021_v3(Y, p);
%
% 输出：
%   M_est : L x p，估计端元
%   S_est : p x N，投影到标准概率单纯形后的丰度
%   out   : 包含论文算法的中间变量、参数和收敛历史
%
% 例如：
%   load('my_data.mat');     % 其中含 Y
%   p = 3;
%   [M_est,S_est,out] = SoftML_Simplex_2021_v3(Y,p,...
%       'MaxIter',250,...
%       'Gamma',[],...
%       'Alpha',[],...
%       'UseConvexHullInit',true,...
%       'UseHullGradient',false,...
%       'Plot',true);
%
% -------------------------------------------------------------------------
% 与 MVSA 的 dataProj.m 直接兼容
% -------------------------------------------------------------------------
% 如果你已经执行：
%
%   [Y_proj, Up, my, sing_val] = dataProj(Y,p,'proj_type','affine');
%
% 则推荐直接复用该仿射投影，不再重复做 PCA：
%
%   [M_est,S_est,out] = SoftML_Simplex_2021_v3(Y,p,...
%       'YProj',Y_proj,...
%       'Up',Up,...
%       'my',my,...
%       'MTrue',M);
%
% dataProj 的 affine 模式中，Up(:,1:p-1) 正好张成信号的 (p-1) 维
% 仿射子空间；本算法直接采用：
%
%   X = Up(:,1:p-1)' * (Y_proj - my)
%
% 作为论文 K=p-1 维单纯形算法的输入坐标。
%
% -------------------------------------------------------------------------
% 重要说明：论文公开信息中的一个实现缺口
% -------------------------------------------------------------------------
% 论文理论部分令 K 维单纯形具有 K+1 个顶点，因此解析梯度公式是在
% “数据维数 K = 顶点数 p - 1”的满维坐标中给出的。
%
% 对原始高光谱数据 Y(L x N)，本程序先：
%   1) 去均值；
%   2) PCA/SVD 投影到 K=p-1 维仿射子空间；
%   3) 在该 K 维坐标中严格实现论文 (2.2)、(3.3)-(3.9) 和 Algorithm 1；
%   4) 再把顶点映射回原始 L 波段空间，得到 M_est。
%
% 论文 Cuprite 实验文字同时写到“PCA 到 10 维”以及“顶点数 K+1=3”，
% 但论文没有给出如何在 10 维环境中使用其 K=p-1 满维解析梯度的进一步
% 实现细节。因此本程序不虚构该未公开步骤，而是严格实现论文已经给出的
% 数学算法。
%
% -------------------------------------------------------------------------
% Gamma / Alpha
% -------------------------------------------------------------------------
% 论文说明 gamma 和学习率 alpha 是人工调节的，但没有公开每组实验的
% 精确数值。为了做到“加入数据即可运行”：
%
%   Gamma=[] 时：根据初始 data-gradient 与 volume-gradient 的范数自动
%                 给一个平衡初值；
%   Alpha=[] 时：根据数据直径和初始总梯度自动给一个固定步长。
%
% 一旦自动确定，后续仍严格按 Algorithm 1 使用固定 alpha：
%   Theta_{t+1} = Theta_t - alpha * grad_R
%
% 若你需要固定实验参数，请直接指定 'Gamma',数值 和 'Alpha',数值。
%
% -------------------------------------------------------------------------
% 依赖
% -------------------------------------------------------------------------
% 不需要 Optimization Toolbox。
% 使用 MATLAB 自带 SVD、PINV、CONVHULLN 等基础数值函数。
%
% =========================================================================

% ------------------------------- 输入检查 --------------------------------
% 本函数只处理已经准备好的 Y 和 p。
% 不再执行任何无输入自动流程，也不再生成任何内置随机合成数据。
% 请显式调用：
%   [M_est,S_est,out] = SoftML_Simplex_2021_v3(Y,p,...)
%
if nargin < 2
    error(['SoftML_Simplex_2021_v3 需要输入已经生成好的数据 Y 和端元数 p。', newline, ...
           '请不要直接点击运行该函数文件。', newline, ...
           '正确用法： [M_est,S_est,out] = SoftML_Simplex_2021_v3(Y,p);']);
end


if ~isnumeric(Y) || ndims(Y) ~= 2 || isempty(Y)
    error('Y 必须是非空二维数值矩阵，尺寸应为 L x N。');
end
if any(~isfinite(Y(:)))
    error('Y 中存在 NaN 或 Inf，请先清理数据。');
end
if ~isscalar(p) || p < 2 || p ~= round(p)
    error('p 必须是 >= 2 的整数，表示单纯形顶点数/端元数。');
end

[L,N] = size(Y);
K = p - 1;

if N < p
    error('样本数 N 必须不少于顶点数 p。');
end
if K > min(L, N-1)
    error('p-1 超过数据可用秩：请减小 p 或增加有效样本/波段。');
end

Y = double(Y);

% ------------------------------- 参数设置 --------------------------------
ip = inputParser;
ip.FunctionName = mfilename;

addParameter(ip,'MaxIter',250,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(ip,'Gamma',[],@(x)isempty(x)||(isnumeric(x)&&isscalar(x)&&x>=0));
addParameter(ip,'Alpha',[],@(x)isempty(x)||(isnumeric(x)&&isscalar(x)&&x>0));
addParameter(ip,'UseConvexHullInit',true,@(x)islogical(x)||ismember(x,[0,1]));
addParameter(ip,'UseHullGradient',false,@(x)islogical(x)||ismember(x,[0,1]));
addParameter(ip,'Seed',1,@(x)isnumeric(x)&&isscalar(x));
addParameter(ip,'Jitter',1e-12,@(x)isnumeric(x)&&isscalar(x)&&x>=0);
addParameter(ip,'InitTrials',200,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(ip,'Verbose',true,@(x)islogical(x)||ismember(x,[0,1]));
addParameter(ip,'Plot',true,@(x)islogical(x)||ismember(x,[0,1]));
addParameter(ip,'Theta0',[],@(x)isempty(x)||isnumeric(x));
addParameter(ip,'MTrue',[],@(x)isempty(x)||isnumeric(x));

% 与用户现有 dataProj.m 的输出直接对接
addParameter(ip,'YProj',[],@(x)isempty(x)||isnumeric(x));
addParameter(ip,'Up',[],@(x)isempty(x)||isnumeric(x));
addParameter(ip,'my',[],@(x)isempty(x)||isnumeric(x));

addParameter(ip,'DiameterBlockSize',1000,@(x)isnumeric(x)&&isscalar(x)&&x>=10);

% Optional MATLAB-native optimization-memory measurement (Windows).
% Same protocol as the DeepMVSA Table-1 experiment: memory().MemUsedMATLAB
% at explicit high-live-set checkpoints, plus deterministic whos-based
% local-workspace diagnostics. No PowerShell/Get-Process polling is used.
addParameter(ip,'MEASURE_OPT_MEMORY',false,@(x)islogical(x)||(isnumeric(x)&&isscalar(x)));
addParameter(ip,'MEMORY_BASELINE_SAMPLES',7,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(ip,'MEMORY_CHECKPOINT_EVERY',1,@(x)isnumeric(x)&&isscalar(x)&&x>=1);

parse(ip,varargin{:});
opt = ip.Results;

opt.MaxIter = round(opt.MaxIter);
opt.InitTrials = round(opt.InitTrials);
opt.DiameterBlockSize = round(opt.DiameterBlockSize);

rng(opt.Seed);

% =========================================================================
% Step 1. 得到论文所需的 K=p-1 维仿射坐标
%
% 优先复用用户现有 dataProj.m 的结果：
%   [Y_proj,Up,my,...] = dataProj(Y,p,'proj_type','affine')
%
% dataProj.m 明确给出：
%   Up(:,1:p-1) 张成最佳 (p-1) 维仿射信号空间，
%   my 是数据均值。
%
% 若未提供 YProj/Up/my，则退化为本函数内部 SVD/PCA。
% =========================================================================
has_external_proj = ~isempty(opt.YProj) || ~isempty(opt.Up) || ~isempty(opt.my);

if has_external_proj

    if isempty(opt.YProj) || isempty(opt.Up) || isempty(opt.my)
        error(['若使用外部 dataProj 结果，YProj、Up、my 三个参数必须同时提供。', ...
               '例如：''YProj'',Y_proj,''Up'',Up,''my'',my']);
    end

    Yproj = double(opt.YProj);
    Up_ext = double(opt.Up);
    mu = double(opt.my(:));

    if ~isequal(size(Yproj),[L,N])
        error('YProj 尺寸必须与 Y 一致，即 L x N = %d x %d。',L,N);
    end

    if size(Up_ext,1) ~= L || size(Up_ext,2) < K
        error('Up 至少必须为 L x (p-1)，当前需要 %d x %d。',L,K);
    end

    if numel(mu) ~= L
        error('my 必须包含 L=%d 个元素。',L);
    end

    U = Up_ext(:,1:K);

    % dataProj 的前 p-1 列理论上为正交归一基。
    orth_err = norm(U'*U-eye(K),'fro');
    if orth_err > 1e-6
        warning('Up(:,1:p-1) 的正交误差为 %.3e；将通过 QR 重新正交化。',orth_err);
        [U,~] = qr(U,0);
    end

    Yproj_c = bsxfun(@minus,Yproj,mu);
    X = U' * Yproj_c;

    projection_source = 'external dataProj affine projection';

else

    mu = mean(Y,2);
    Yc = bsxfun(@minus,Y,mu);

    [Ufull,Sfull,~] = svd(Yc,'econ');
    sv = diag(Sfull);

    if numel(sv) < K || sv(K) <= max(size(Yc))*eps(max(sv))
        error('数据在前 p-1 个方向上秩不足，无法构成非退化单纯形。');
    end

    U = Ufull(:,1:K);
    X = U' * Yc;

    projection_source = 'internal affine PCA/SVD';
end

% =========================================================================
% Step 2. Convex hull：论文 Section 4.1 的初始化/可选加速
% =========================================================================
hull_idx = [];
if opt.UseConvexHullInit || opt.UseHullGradient
    hull_idx = compute_convex_hull_indices(X);
end

if isempty(hull_idx)
    hull_idx = 1:N;
end

% =========================================================================
% Step 3. 数据直径 diam(D)，实验中 b = 1 / diam(D)
% =========================================================================
% 欧氏直径一定可以在凸包极点之间取得，因此若已经有 hull，可直接在 hull
% 顶点中计算，结果仍是完整数据集的精确直径。
diam_idx = hull_idx;
data_diam = exact_dataset_diameter(X(:,diam_idx), opt.DiameterBlockSize);

if ~(isfinite(data_diam) && data_diam > 0)
    error('数据直径为 0 或非法，无法运行。');
end

beta = 1 / data_diam;

% =========================================================================
% Step 4. 初始化 Theta^(0)
% =========================================================================
if ~isempty(opt.Theta0)
    Theta = double(opt.Theta0);
    if ~isequal(size(Theta),[K,p])
        error('Theta0 尺寸必须为 (p-1) x p，即 %d x %d。',K,p);
    end
else
    if opt.UseConvexHullInit
        init_pool = hull_idx;
    else
        init_pool = 1:N;
    end
    Theta = initialize_simplex_from_points(X, init_pool, p, opt.InitTrials, data_diam);
end

% =========================================================================
% Step 5. 选择梯度数据
% =========================================================================
if opt.UseHullGradient
    grad_idx = hull_idx;
else
    grad_idx = 1:N;
end

Xgrad = X(:,grad_idx);

% ================= Soft-ML optimization-memory measurement ==============
% START: after projection/hull/diameter/simplex initialization and Xgrad
%        preparation, immediately before Algorithm 1 storage/iterations.
% STOP : immediately after Algorithm 1.
%
% This interval matches the DeepMVSA Table-1 optimization-memory protocol:
% preprocessing / initialization are baseline state and are not counted as
% optimization working-memory growth.
measure_opt_memory = logical(opt.MEASURE_OPT_MEMORY);
memory_checkpoint_every = max(1, floor(double(opt.MEMORY_CHECKPOINT_EVERY)));
softml_memory_stats = struct();

if measure_opt_memory
    if ~ispc
        error(['MEASURE_OPT_MEMORY=true in this instrumented Soft-ML uses MATLAB memory(), ' ...
               'which is intended for the Windows Table-1 benchmark.']);
    end

    softml_memory_monitor('reset');
    softml_memory_monitor('start', 'optimization baseline', ...
        round(opt.MEMORY_BASELINE_SAMPLES));
end

% =========================================================================
% Step 6. Algorithm 1：固定步长梯度下降
% =========================================================================
history.objective     = nan(opt.MaxIter,1);
history.data_loss     = nan(opt.MaxIter,1);
history.volume        = nan(opt.MaxIter,1);
history.grad_norm     = nan(opt.MaxIter,1);
history.num_outside   = nan(opt.MaxIter,1);
history.max_distance  = nan(opt.MaxIter,1);

gamma = opt.Gamma;
alpha = opt.Alpha;

%if opt.Verbose
 %   fprintf('============================================================\n');
%    fprintf('Soft-ML simplex inference (Najafi et al., 2021)\n');
%    fprintf('L=%d, N=%d, p=%d, intrinsic K=p-1=%d\n',L,N,p,K);
 %   fprintf('Projection source: %s\n',projection_source);
  %  fprintf('Convex-hull vertices: %d\n',numel(hull_idx));
  %  fprintf('Gradient samples: %d\n',numel(grad_idx));
   % fprintf('diam(D)=%.6e, beta=1/diam(D)=%.6e\n',data_diam,beta);
  %  fprintf('============================================================\n');
%end

for t = 1:opt.MaxIter

    do_mem_checkpoint = measure_opt_memory && ...
        (t == 1 || mod(t, memory_checkpoint_every) == 0 || t == opt.MaxIter);

    if do_mem_checkpoint
        softml_memory_monitor('arm', sprintf('Soft-ML iter %d', t));
        softml_memory_monitor('sample_process', sprintf('iter %d: start', t));
    end

    % 论文建议在计算梯度前加入无限小扰动以避开零测度病态情形
    if opt.Jitter > 0
        Theta = Theta + (opt.Jitter * data_diam) * randn(size(Theta));
    end

    % 所有 facet 的 outward normal (w_k,b_k)
    [W,bvec] = compute_facets(Theta);

    if do_mem_checkpoint
        softml_memory_monitor('sample_process', sprintf('iter %d: facets ready', t));
    end

    % 数据项梯度：Theorem 3.3 / Eq. (3.7)
    [Gdata, grad_stats] = compute_data_gradient( ...
        Xgrad, Theta, W, bvec, beta, N);

    if do_mem_checkpoint
        softml_memory_monitor('sample_process', sprintf('iter %d: data gradient returned', t));
    end

    % 体积及其梯度：Eq. (3.5)，与 Eq. (3.9) 等价
    [volS,Gvol] = simplex_volume_and_gradient(Theta);

    % 自动 gamma：论文未公开具体实验数值，仅在用户没有指定时使用
    if isempty(gamma)
        ngd = norm(Gdata,'fro');
        ngv = norm(Gvol,'fro');
        if ngv <= eps
            gamma = 1;
        elseif ngd <= eps
            gamma = 0.1;
        else
            % 让初始体积梯度约为数据梯度的 10%，作为可运行默认值
            gamma = 0.10 * ngd / ngv;
        end

        if opt.Verbose
            fprintf('Auto Gamma = %.6e  (论文未公开精确 gamma，当前为自动初值)\n',gamma);
        end
    end

    G = Gdata + gamma * Gvol;

    % 自动 alpha：只在第一次确定，之后严格固定，符合 Algorithm 1
    if isempty(alpha)
        ng = norm(G,'fro');
        if ng <= eps
            alpha = 1e-3;
        else
            % 初次 Frobenius 更新量约为数据直径的 2%
            alpha = 0.02 * data_diam / ng;
        end

        if opt.Verbose
            fprintf('Auto Alpha = %.6e  (确定后保持固定)\n',alpha);
        end
    end

    % 计算完整 CRR 目标值（使用全部 N 个样本）
    [data_loss, d_all] = crr_data_loss(X, W, bvec, beta);
    obj = data_loss + gamma * volS;

    if do_mem_checkpoint
        softml_memory_monitor('sample_process', sprintf('iter %d: full CRR loss returned', t));
    end

    history.objective(t)    = obj;
    history.data_loss(t)    = data_loss;
    history.volume(t)       = volS;
    history.grad_norm(t)    = norm(G,'fro');
    history.num_outside(t)  = sum(d_all > 0);
    history.max_distance(t) = max(d_all);

    %if opt.Verbose && (t==1 || mod(t,10)==0 || t==opt.MaxIter)
      %  fprintf(['Iter %4d/%4d | Obj %.6e | Data %.6e | Vol %.6e | ', ...
      %           '||G|| %.3e | outside %d/%d\n'], ...
       %          t,opt.MaxIter,obj,data_loss,volS,history.grad_norm(t), ...
      %           history.num_outside(t),N);
    %end

    % ----------------------- Algorithm 1 核心更新 -------------------------
    Theta = Theta - alpha * G;

    if do_mem_checkpoint
        softml_memory_monitor('sample_process', sprintf('iter %d: end', t));
        softml_memory_monitor('disarm');
    end
end

%% -------- End Soft-ML optimization-memory measurement --------
if measure_opt_memory
    softml_memory_monitor('sample_process', 'end of Algorithm 1');
    softml_memory_stats = softml_memory_monitor('stop');

    fprintf('\n=======================================================================\n');
    fprintf('SOFT-ML MATLAB-NATIVE OPTIMIZATION-MEMORY MEASUREMENT\n');
    fprintf('-----------------------------------------------------------------------\n');
    fprintf('N                                   : %d\n', N);
    fprintf('K                                   : %d\n', K);
    fprintf('p = K+1                             : %d\n', p);
    fprintf('Gradient samples                    : %d\n', size(Xgrad,2));
    fprintf('Baseline MATLAB MemUsed             : %.2f MB\n', softml_memory_stats.baseline_mb);
    fprintf('Peak MATLAB MemUsed (optimization)  : %.2f MB\n', softml_memory_stats.peak_mb);
    fprintf('Peak optimization delta             : %.2f MB   <-- Table 1 memory\n', ...
        softml_memory_stats.delta_mb);
    fprintf('Peak process checkpoint             : %s\n', softml_memory_stats.peak_label);
    fprintf('Peak local workspace arrays         : %.2f MB\n', ...
        softml_memory_stats.peak_local_workspace_bytes/1024^2);
    fprintf('Peak local-workspace checkpoint     : %s\n', ...
        softml_memory_stats.peak_local_workspace_label);
    fprintf('Process-memory checkpoints          : %d\n', softml_memory_stats.process_samples);
    fprintf('Local-workspace checkpoints         : %d\n', softml_memory_stats.local_samples);
    fprintf('=======================================================================\n\n');
end

% =========================================================================
% Step 7. 最终结果
% =========================================================================
[W_final,b_final] = compute_facets(Theta);
[final_data_loss,d_final] = crr_data_loss(X,W_final,b_final,beta);
[final_volume,~] = simplex_volume_and_gradient(Theta);
final_objective = final_data_loss + gamma*final_volume;

% 映射回原始波段空间
M_est = repmat(mu,1,p) + U * Theta;          % L x p

% =========================================================================
% Step 8. 由估计单纯形计算重心坐标/丰度
% =========================================================================
% 在 K=p-1 维坐标中加入 sum(s)=1 方程：
%   [Theta; 1^T] s = [x; 1]
Abar = [Theta; ones(1,p)];
Xbar = [X; ones(1,N)];

if rcond(Abar) < 1e-14
    S_raw = pinv(Abar) * Xbar;
else
    S_raw = Abar \ Xbar;
end

% 对每列投影到标准概率单纯形：s>=0, sum(s)=1
S_est = project_columns_to_probability_simplex(S_raw);

% =========================================================================
% 输出信息
% =========================================================================
out = struct();
out.implementation_version = '2026-08-14-v3-existing-data-only';
out.memory_stats = softml_memory_stats;
out.Theta = Theta;
out.W = W_final;
out.b = b_final;
out.U = U;
out.meanY = mu;
out.X = X;
out.projection_source = projection_source;
if has_external_proj
    out.YProj = Yproj;
end
out.beta = beta;
out.gamma = gamma;
out.alpha = alpha;
out.data_diameter = data_diam;
out.hull_idx = hull_idx;
out.gradient_idx = grad_idx;
out.S_raw = S_raw;
out.history = history;
out.final_data_loss = final_data_loss;
out.final_volume = final_volume;
out.final_objective = final_objective;
out.final_planar_distance = d_final;
out.options = opt;

% =========================================================================
% 若给出真实端元，计算论文 Eq. (4.1) 的 permutation-invariant vertex error
% =========================================================================
if ~isempty(opt.MTrue)
    Mtrue = double(opt.MTrue);
    if ~isequal(size(Mtrue),[L,p])
        warning('MTrue 尺寸不是 L x p，跳过论文 Eq. (4.1) error 计算。');
    else
        Theta_true = U' * bsxfun(@minus,Mtrue,mu);
        [paper_error,best_perm] = paper_vertex_error(Theta_true,Theta);
        out.M_true = Mtrue;
        out.Theta_true = Theta_true;
        out.paper_error = paper_error;
        out.best_permutation = best_perm;

        %if opt.Verbose
         %   fprintf('Paper Eq.(4.1) vertex error = %.6e\n',paper_error);
         %   fprintf('Best permutation = ');
          %  fprintf('%d ',best_perm);
         %   fprintf('\n');
       % end
    end
end

% =========================================================================
% 可视化
% =========================================================================
if opt.Plot
    plot_results(X,Theta,history,out);
end

if opt.Verbose
    fprintf('------------------------------------------------------------\n');
    fprintf('Finished.\n');
    fprintf('Final objective = %.6e\n',final_objective);
    fprintf('Final data loss = %.6e\n',final_data_loss);
    fprintf('Final volume    = %.6e\n',final_volume);
    fprintf('Final outside   = %d/%d\n',sum(d_final>0),N);
    fprintf('------------------------------------------------------------\n');
end

end


% =========================================================================
% 局部函数 1：计算凸包顶点索引
% =========================================================================
function hull_idx = compute_convex_hull_indices(X)

[K,N] = size(X);

if K == 1
    [~,i1] = min(X(1,:));
    [~,i2] = max(X(1,:));
    hull_idx = unique([i1,i2]);
    return;
end

try
    F = convhulln(X');
    hull_idx = unique(F(:))';
catch ME1
    warning('convhulln 默认调用失败：%s。尝试 QJ 数值扰动选项。',ME1.message);
    try
        F = convhulln(X',{'Qt','QJ'});
        hull_idx = unique(F(:))';
    catch ME2
        warning('convhulln 再次失败：%s。退化为使用全部样本。',ME2.message);
        hull_idx = 1:N;
    end
end

end


% =========================================================================
% 局部函数 2：从数据点初始化一个非退化单纯形
% =========================================================================
function Theta = initialize_simplex_from_points(X,pool_idx,p,max_trials,data_diam)

K = p - 1;

if numel(pool_idx) < p
    error('可用于初始化的点少于 p 个。');
end

tol_vol = max(1e-14, eps) * max(data_diam,1)^K;

for r = 1:max_trials
    idx = pool_idx(randperm(numel(pool_idx),p));
    T = X(:,idx);
    v = simplex_volume_only(T);
    if isfinite(v) && v > tol_vol
        Theta = T;
        return;
    end
end

% 数值后备：寻找具有较大离散度的点（仅在随机初始化反复退化时使用）
warning('随机凸包初始化多次得到退化单纯形，启用数值后备初始化。');

idx_selected = zeros(1,p);
idx_selected(1) = pool_idx(randi(numel(pool_idx)));

for j = 2:p
    chosen = X(:,idx_selected(1:j-1));
    best_score = -inf;
    best_idx = pool_idx(1);

    for c = pool_idx
        x = X(:,c);

        if j == 2
            score = norm(x - chosen(:,1));
        else
            C = chosen(:,2:end) - chosen(:,1);
            z = x - chosen(:,1);
            if isempty(C)
                resid = z;
            else
                resid = z - C*(pinv(C)*z);
            end
            score = norm(resid);
        end

        if score > best_score
            best_score = score;
            best_idx = c;
        end
    end

    idx_selected(j) = best_idx;
end

Theta = X(:,idx_selected);

if simplex_volume_only(Theta) <= tol_vol
    error('无法构造非退化初始单纯形，请检查数据秩或 p。');
end

end


% =========================================================================
% 局部函数 3：计算所有 facet 的 outward unit normal
%
% 对第 k 个 facet：
%   删除 theta_k，得到 Theta_{-k}
%   c_k = mean(Theta_{-k},2)
%   找 centered facet 的零空间向量 w_k
%   调整方向，使 w_k'*(theta_k-c_k) <= 0
%   b_k = -w_k'*c_k
% =========================================================================
function [W,bvec] = compute_facets(Theta)

[K,p] = size(Theta);

if p ~= K + 1
    error('论文解析公式要求 Theta 尺寸为 K x (K+1)。');
end

W = zeros(K,p);
bvec = zeros(p,1);

for k = 1:p
    others = [1:k-1, k+1:p];
    B = Theta(:,others);

    c = mean(B,2);
    C = B - c;

    % C 的秩应为 K-1；其左零空间即 facet normal
    [U,~,~] = svd(C,'econ');
    w = U(:,end);

    nw = norm(w);
    if nw <= eps
        error('facet normal 计算失败：当前单纯形过度退化。');
    end
    w = w / nw;

    % outward orientation：
    % 被删除的顶点 theta_k 位于 facet 内侧，因此要求 <= 0
    if w' * (Theta(:,k) - c) > 0
        w = -w;
    end

    W(:,k) = w;
    bvec(k) = -w' * c;
end

end


% =========================================================================
% 局部函数 4：CRR 数据项
%
% d_S(x) = max(0, max_k (w_k' x + b_k))
% l(d)   = 1 - exp(-beta*d)
% R_data = 1/sqrt(N) * sum_i l(d_i)
% =========================================================================
function [loss,d,kstar] = crr_data_loss(X,W,bvec,beta)

N = size(X,2);

V = bsxfun(@plus,W' * X,bvec);
[maxv,kstar] = max(V,[],1);
d = max(0,maxv);

if softml_memory_monitor('is_armed')
    local_info = whos;
    softml_memory_monitor('sample_local', 'CRR full-data live set', ...
        sum([local_info.bytes]));
    clear local_info
end

loss = sum(1 - exp(-beta*d)) / sqrt(N);

end


% =========================================================================
% 局部函数 5：Theorem 3.3 / Eq. (3.7) 的数据项梯度
%
% 若 d_i=0：G_i=0
%
% 若 d_i>0：
%   k* = argmax_k(w_k'x+b_k)
%   x_proj = x - w*w'*(x-c)
%   p* = pinv(Theta_{-k*})*x_proj
%   G_i = -l'(d_i) * w * p*' * J_{k*}
%
% 这里按 active facet 分组向量化计算。
% normN 使用完整数据 N，以保持 Eq. (3.9) 中 1/sqrt(n) 的归一化。
% =========================================================================
function [Gdata,stats] = compute_data_gradient(Xgrad,Theta,W,bvec,beta,normN)

[K,p] = size(Theta);

V = bsxfun(@plus,W' * Xgrad,bvec);
[maxv,kstar] = max(V,[],1);

outside = maxv > 0;
Gdata = zeros(K,p);

if softml_memory_monitor('is_armed')
    local_info = whos;
    softml_memory_monitor('sample_local', 'data-gradient active-facet live set', ...
        sum([local_info.bytes]));
    clear local_info
end

for k = 1:p

    idx = find(outside & (kstar == k));
    if isempty(idx)
        continue;
    end

    others = [1:k-1, k+1:p];
    B = Theta(:,others);
    c = mean(B,2);
    w = W(:,k);

    Xk = Xgrad(:,idx);

    % 投影到 active facet 的超平面
    Xproj = Xk - w * (w' * bsxfun(@minus,Xk,c));

    % Eq. (3.6)
    Pstar = pinv(B) * Xproj;             % K x n_k

    d = maxv(idx);
    lprime = beta * exp(-beta*d);        % 1 x n_k

    if softml_memory_monitor('is_armed')
        local_info = whos;
        softml_memory_monitor('sample_local', sprintf('data-gradient facet %d live set', k), ...
            sum([local_info.bytes]));
        clear local_info
    end

    % sum_i [-l'(d_i) w p_i^T]
    weighted_p = Pstar * lprime(:);      % K x 1
    Gdata(:,others) = Gdata(:,others) - w * weighted_p';
end

Gdata = Gdata / sqrt(normN);

stats.num_outside_gradset = sum(outside);
if any(outside)
    stats.max_distance_gradset = max(maxv(outside));
else
    stats.max_distance_gradset = 0;
end

end


% =========================================================================
% 局部函数 6：单纯形体积和体积梯度
%
% Vol(S) = |det([theta_1-theta_0,...,theta_K-theta_0])| / K!
%
% 令 A=[theta_1-theta_0,...,theta_K-theta_0]
% d|det(A)|/dA = sign(det(A))*cofactor(A)
%
% 再利用 A 的每列都含 -theta_0，可得到：
%   grad_theta_j = grad_A_j, j>=1
%   grad_theta_0 = -sum_j grad_A_j
%
% 与论文 Eq. (3.9) 的 adjugate 表达式等价。
% =========================================================================
function [volS,Gvol] = simplex_volume_and_gradient(Theta)

[K,p] = size(Theta);

if p ~= K + 1
    error('Theta 必须为 K x (K+1)。');
end

A = Theta(:,2:end) - Theta(:,1);
detA = det(A);

volS = abs(detA) / factorial(K);

if K == 1
    gradDet = 1;
else
    % 梯度 det(A) 关于 A 是 cofactor matrix = adj(A)^T
    if rcond(A) > 1e-12
        gradDet = detA * (A' \ eye(K));
    else
        gradDet = determinant_cofactor_gradient(A);
    end
end

sgn = sign(detA);
if sgn == 0
    % 理论中通过无限小扰动避开 det=0；这里给出数值后备
    sgn = 1;
end

GA = (sgn / factorial(K)) * gradDet;

Gvol = zeros(K,p);
Gvol(:,2:end) = GA;
Gvol(:,1) = -sum(GA,2);

end


% =========================================================================
% 局部函数 7：仅计算体积
% =========================================================================
function v = simplex_volume_only(Theta)

K = size(Theta,1);
A = Theta(:,2:end) - Theta(:,1);
v = abs(det(A)) / factorial(K);

end


% =========================================================================
% 局部函数 8：det(A) 关于 A 的 cofactor gradient
% 数值病态时使用，避免直接依赖 inv(A)
% =========================================================================
function C = determinant_cofactor_gradient(A)

K = size(A,1);

if K == 1
    C = 1;
    return;
end

C = zeros(K,K);

for i = 1:K
    rows = [1:i-1, i+1:K];
    for j = 1:K
        cols = [1:j-1, j+1:K];
        C(i,j) = (-1)^(i+j) * det(A(rows,cols));
    end
end

end


% =========================================================================
% 局部函数 9：精确计算数据直径
%
% diam(D)=max_{i,j} ||x_i-x_j||_2
% 分块计算，避免 pdist 一次性占用 O(N^2) 内存。
% =========================================================================
function diamD = exact_dataset_diameter(X,block_size)

N = size(X,2);

if N == 1
    diamD = 0;
    return;
end

maxd2 = 0;

for i1 = 1:block_size:N
    i2 = min(i1+block_size-1,N);
    A = X(:,i1:i2);
    aa = sum(A.^2,1)';

    for j1 = i1:block_size:N
        j2 = min(j1+block_size-1,N);
        B = X(:,j1:j2);
        bb = sum(B.^2,1);

        D2 = aa + bb - 2*(A' * B);
        local_max = max(D2(:));

        if local_max > maxd2
            maxd2 = local_max;
        end
    end
end

diamD = sqrt(max(maxd2,0));

end


% =========================================================================
% 局部函数 10：把丰度逐列投影到标准概率单纯形
%   min ||s-v||_2^2
%   s.t. s>=0, sum(s)=1
% =========================================================================
function S = project_columns_to_probability_simplex(V)

[p,N] = size(V);
S = zeros(p,N);

for n = 1:N
    v = V(:,n);
    u = sort(v,'descend');
    cssv = cumsum(u) - 1;
    ind = (1:p)';

    rho = find(u - cssv./ind > 0,1,'last');

    if isempty(rho)
        S(:,n) = ones(p,1)/p;
        continue;
    end

    theta = cssv(rho)/rho;
    s = max(v-theta,0);

    ss = sum(s);
    if ss > 0
        s = s/ss;
    else
        s = ones(p,1)/p;
    end

    S(:,n) = s;
end

end


% =========================================================================
% 局部函数 11：论文 Eq. (4.1) 顶点误差
% 适用于常见的小 p；p>9 时使用动态规划 assignment，避免 perms 爆炸。
% =========================================================================
function [err,best_perm] = paper_vertex_error(Ttrue,Test)

[K,p] = size(Ttrue);

if ~isequal(size(Test),[K,p])
    error('Ttrue 和 Test 尺寸必须一致。');
end

C = zeros(p,p);
for i = 1:p
    for j = 1:p
        z = Ttrue(:,i) - Test(:,j);
        C(i,j) = sum(z.^2);
    end
end

if p <= 9
    P = perms(1:p);
    best_cost = inf;
    best_perm = 1:p;

    for r = 1:size(P,1)
        perm = P(r,:);
        idx = sub2ind([p,p],1:p,perm);
        cost = sum(C(idx));
        if cost < best_cost
            best_cost = cost;
            best_perm = perm;
        end
    end
else
    [best_cost,best_perm] = assignment_dp(C);
end

err = sqrt(best_cost / (K*p));

end


% =========================================================================
% 局部函数 12：小/中等 p 的精确 assignment 动态规划
% 复杂度 O(p*2^p)，适合常见端元数。
% =========================================================================
function [best_cost,best_perm] = assignment_dp(C)

p = size(C,1);

if p > 20
    warning('p>20，精确 bitmask assignment 代价过高，改用贪心匹配。');
    remaining = 1:p;
    best_perm = zeros(1,p);
    best_cost = 0;

    for i = 1:p
        [v,loc] = min(C(i,remaining));
        best_perm(i) = remaining(loc);
        best_cost = best_cost + v;
        remaining(loc) = [];
    end
    return;
end

num_states = 2^p;
dp = inf(num_states,1);
parent_mask = zeros(num_states,1,'uint32');
parent_col = zeros(num_states,1,'uint16');

dp(1) = 0;   % mask=0 对应 MATLAB 索引 1

for mask = 0:num_states-1
    state = mask + 1;
    current = dp(state);

    if ~isfinite(current)
        continue;
    end

    row = sum(bitget(uint32(mask),1:p)) + 1;
    if row > p
        continue;
    end

    for col = 1:p
        if bitget(uint32(mask),col) == 0
            newmask = bitset(uint32(mask),col,1);
            newstate = double(newmask) + 1;
            newcost = current + C(row,col);

            if newcost < dp(newstate)
                dp(newstate) = newcost;
                parent_mask(newstate) = uint32(mask);
                parent_col(newstate) = uint16(col);
            end
        end
    end
end

best_cost = dp(end);
best_perm = zeros(1,p);

mask = uint32(num_states-1);
for row = p:-1:1
    state = double(mask)+1;
    best_perm(row) = double(parent_col(state));
    mask = parent_mask(state);
end

end


% =========================================================================
% 局部函数 13：绘图
% =========================================================================
function plot_results(X,Theta,history,out)

K = size(X,1);
p = size(Theta,2);

%figure('Name','Soft-ML CRR convergence');
%plot(1:numel(history.objective),history.objective,'LineWidth',1.5);
%xlabel('Iteration');
%ylabel('CRR objective');
%title('Soft-ML simplex inference: objective');
%grid on;

%figure('Name','Soft-ML volume convergence');
%plot(1:numel(history.volume),history.volume,'LineWidth',1.5);
%xlabel('Iteration');
%ylabel('Simplex volume');
%title('Simplex volume');
%grid on;

if K == 2
    figure('Name','Estimated simplex');
    plot(X(1,:),X(2,:),'.','MarkerSize',5);
    hold on;

    order = [1:p,1];
    plot(Theta(1,order),Theta(2,order),'-','LineWidth',2);

    if isfield(out,'Theta_true')
        Tt = out.Theta_true;
        plot(Tt(1,order),Tt(2,order),'--','LineWidth',2);
        legend('Data','Estimated simplex','True simplex','Location','best');
    else
        legend('Data','Estimated simplex','Location','best');
    end

    xlabel('PC / affine coordinate 1');
    ylabel('PC / affine coordinate 2');
    title('Data and estimated simplex');
    axis equal;
    grid on;
    hold off;
end

end

%% ===================== MATLAB-native Soft-ML memory helper =====================
function out = softml_memory_monitor(action, label, value)
%SOFTML_MEMORY_MONITOR  Checkpoint-based monitor matching DeepMVSA Table 1.
%
% Main Table-1 metric:
%   peak optimization delta =
%       max_t memory().MemUsedMATLAB(t) - baseline MemUsedMATLAB
%
% The baseline is taken after Soft-ML projection/hull/diameter/simplex
% initialization and Xgrad preparation, immediately before Algorithm 1.
%
% Local-workspace diagnostics use whos inside the high-live-set helper
% functions.  These are deterministic array-byte diagnostics and are not
% substituted for the process-level Table-1 metric.

    persistent S

    if nargin < 2 || isempty(label)
        label = '';
    end
    if nargin < 3
        value = [];
    end

    switch lower(action)
        case 'reset'
            S = [];
            out = [];

        case 'start'
            n_samples = 7;
            if ~isempty(value)
                n_samples = max(1, round(double(value)));
            end

            samples = zeros(1,n_samples);
            for ii = 1:n_samples
                u = memory;
                samples(ii) = double(u.MemUsedMATLAB);
                if ii < n_samples
                    pause(0.01);
                end
            end

            baseline_bytes = median(samples);
            S = struct();
            S.baseline_bytes = baseline_bytes;
            S.peak_bytes = baseline_bytes;
            S.peak_label = char(label);
            S.process_samples = 0;
            S.armed = false;
            S.arm_label = '';
            S.peak_local_workspace_bytes = 0;
            S.peak_local_workspace_label = '';
            S.local_samples = 0;
            out = S;

        case 'arm'
            if isempty(S), out = []; return; end
            S.armed = true;
            S.arm_label = char(label);
            out = [];

        case 'disarm'
            if ~isempty(S)
                S.armed = false;
                S.arm_label = '';
            end
            out = [];

        case 'is_armed'
            out = ~isempty(S) && S.armed;

        case 'sample_process'
            if isempty(S), out = []; return; end
            u = memory;
            current_bytes = double(u.MemUsedMATLAB);
            S.process_samples = S.process_samples + 1;
            full_label = softml_compose_monitor_label(S,label);
            if current_bytes > S.peak_bytes
                S.peak_bytes = current_bytes;
                S.peak_label = full_label;
            end
            out = current_bytes;

        case 'sample_local'
            if isempty(S) || ~S.armed, out = []; return; end
            live_bytes = double(value);
            S.local_samples = S.local_samples + 1;
            full_label = softml_compose_monitor_label(S,label);
            if live_bytes > S.peak_local_workspace_bytes
                S.peak_local_workspace_bytes = live_bytes;
                S.peak_local_workspace_label = full_label;
            end

            % Process-level checkpoint at the exact same known high-live-set
            % location, avoiding time-based sampling jitter.
            u = memory;
            current_bytes = double(u.MemUsedMATLAB);
            S.process_samples = S.process_samples + 1;
            if current_bytes > S.peak_bytes
                S.peak_bytes = current_bytes;
                S.peak_label = full_label;
            end
            out = current_bytes;

        case 'stop'
            if isempty(S), out = struct(); return; end
            u = memory;
            current_bytes = double(u.MemUsedMATLAB);
            S.process_samples = S.process_samples + 1;
            if current_bytes > S.peak_bytes
                S.peak_bytes = current_bytes;
                S.peak_label = 'stop';
            end

            S.baseline_mb = S.baseline_bytes/1024^2;
            S.peak_mb = S.peak_bytes/1024^2;
            S.delta_mb = max(S.peak_bytes-S.baseline_bytes,0)/1024^2;
            out = S;
            S = [];

        otherwise
            error('Unknown Soft-ML memory-monitor action: %s',action);
    end
end

function label_out = softml_compose_monitor_label(S,label_in)
    if isempty(S.arm_label)
        label_out = char(label_in);
    elseif isempty(label_in)
        label_out = S.arm_label;
    else
        label_out = sprintf('%s / %s',S.arm_label,char(label_in));
    end
end
