function [M,Sest,Up,my,sing_values,diag_stats] = mvsa_runtime_diagnostic(Y,p,varargin)

%% MVSA runtime/QP diagnostic version
%
%  Minimum Volume Simplex Analysis (MVSA)
%
%% --------------- Description ---------------------------------------------
%
%  MVSA Estimates the vertices  M={m_1,...m_p} of the (p-1)-dimensional
%  simplex of minimum volume containing the vectors [y_1,...y_N], under the
%  assumption that y_i belongs to a (p-1)  dimensional affine set. Thus,
%  any vector y_i   belongs  to the convex hull of  the columns of M; i.e.,
%
%                   y_i = M*x_i
%
%  where x_i belongs to the probability (p-1)-simplex.
%
%  As described in the papers [1], [2], matrix M is  obtained by implementing
%  the following steps:
%
%   1-Project y onto a p-dimensional subspace containing the data set y
%
%            yp = Up'*y;      Up is an isometric matrix (Up'*Up=Ip)
%
%   2- solve the   optimization problem
%
%     Q^* = arg min_Q  -\log abs(det(Q))
%
%      subject to: Q*yp >= 0 and ones(1,p)*Q=mq,
%
%     where mq = ones(1,N)*yp'inv(yp*yp)
%
%   3- Compute
%
%      M = Up*inv(Q^*);
%
%% -------------------- Line of Attack  -----------------------------------
%
%  MVSA implements a  sequence of quadratic constrained subproblems. At
%  each iteration the gradient of the objective function is replaced
%  by a quadratic approximation followed by a line-search type procedure.
%
% ------------------------------------------------------------------------
%%  ===== Required inputs =============
%
% y - matrix with  L(channels) x N(pixels).
%     each pixel is a linear mixture of p endmembers
%     signatures y = M*x + noise,
%
%     MVSA assumes that y belongs to an affine space. It may happen,
%     however, that the data supplied by the user is not in an affine
%     set. For this reason, the first step this code implements
%     is the estimation of the affine set the best represent
%     (in the l2 sense) the data.
%
%  p - number of independent columns of M. Therefore, M spans a
%  (p-1)-dimensional affine set.
%
%
%%  ====================== Optional inputs =============================
%
%  'MM_ITERS' = double; Default 4;
%
%               Maximum number of constrained quadratic programs
%
%
%  'spherize'  = {'yes', 'no'}; Default 'yes'
%
%              Applies a spherization step to data such that the spherized
%              data spans over the same range along any axis.
%
%
%  'MU' = double; Default; 1e-6
%
%               Maximum eigenvalue of the quadratic approximation term
%
%
%  'LAMBDA' = double; Default; 1e-10
%
%               Spherization regularization parameter
%
%  'TOLF'  = double; Default; 1e-2
%
%              Tolerance for the termination test (relative variation of f(Q))
%
%
%
%  'M0'  =  <[Lxp] double>; Given by the VCA algorithm
%
%            Initial M.
%
%
%  'verbose'   = {0,1,2}; Default 1
%
%                 0 - work silently
%                 1 - display MVSA warnings
%                 2 - display MVSA and MATLAB warnings
%
%
%
%
%%  =========================== Outputs ==================================
%
% M  =  [Lxp] estimated mixing matrix
%
% Up =  [Lxp] isometric matrix spanning  the same subspace as M
%
% my =   mean value of y
%
% sing_values  = (p-1) eigenvalues of Cy = (y-my)*(y-my)/N. The dynamic range
%                  of these eigenvalues gives an idea of the  difficulty of the
%                  underlying problem
%
%
% NOTE: the identified affine set is given by
%
%              {z\in R^p : z=Up(:,1:p-1)*a+my, a\in R^(p-1)}
%
%% -------------------------------------------------------------------------
%
% Copyright (May, 2009):        Jos Bioucas-Dias (bioucas@lx.it.pt)
%                               Jun li (jun@lx.it.pt)
%
% MVSA is distributed under the terms of
% the GNU General Public License 2.0.
%
% Permission to use, copy, modify, and distribute this software for
% any purpose without fee is hereby granted, provided that this entire
% notice is included in all copies of any software which is or includes
% a copy or modification of this software and in all copies of the
% supporting documentation for such software.
% This software is being provided "as is", without any express or
% implied warranty.  In particular, the authors do not make any
% representation or warranty of any kind concerning the merchantability
% of this software or its fitness for any particular purpose."
% ----------------------------------------------------------------------
%
% More details in:
%
% [1] Jun Li and Jos M. Bioucas-Dias
%     "Minimum volume simplex analysis: A fast algorithm to unmix hyperspectral data"
%      in IEEE International Geoscience and Remote sensing Symposium IGARSS2008, Boston, USA,  2008
%
% [2] Jun Li and Jos M. Bioucas-Dias
%     "Minimum volume simplex analysis: A new algorithm to unmix
%     hyperspectral Data", IEEE Transactions on Geoscience and Remote
%     Sensing, 2009 (submitted).
%
% -------------------------------------------------------------------------

%%
%--------------------------------------------------------------
% test for number of required parametres
%--------------------------------------------------------------
if (nargin-length(varargin)) ~= 2
    error('Wrong number of required parameters');
end
% data set size
[L,N] = size(Y);
if (L<p)
    error('Insufficient number of columns in y');
end
% Sixth output contains QP diagnostic information.
% This diagnostic version does NOT alter the original MVSA stopping logic.
diag_stats = struct();
%%
%--------------------------------------------------------------
% Set the defaults for the optional parameters
%--------------------------------------------------------------
% maximum number of quadratic QPs
MMiters = 10;
spherize = 'yes';
% display only MVSA warnings
verbose = 1;
% spherization regularization parameter
lambda = 1e-10;
% quadractic regularization parameter for the Hesssian
% Hreg = = mu*I+H
mu = 1e-6;
% no initial simplex
M = 0;
% tolerance for the termination test
tol_f = 1e-2;

% QP diagnostic controls.
diagnostic_qp = true;
diagnostic_constraints = true;

%%
%--------------------------------------------------------------
% Local variables
%--------------------------------------------------------------
% maximum violation of inequalities
slack = 1e-3;
% flag energy decreasing
any_energy_decreasing = 0;
% used in the termination test
f_val_back = inf;
%--------------------------------------------------------------
% Read the optional parameters
%--------------------------------------------------------------
if (rem(length(varargin),2)==1)
    error('Optional parameters should always go by pairs');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case 'MM_ITERS'
                MMiters = varargin{i+1};
            case 'SPHERIZE'
                spherize = varargin{i+1};
            case 'MU'
                mu = varargin{i+1};
            case  'LAMBDA'
                lambda = varargin{i+1};
            case 'TOLF'
                tol_f = varargin{i+1};
            case 'M0'
                M = varargin{i+1};
            case 'VERBOSE'
                verbose = varargin{i+1};
            case 'DIAGNOSTIC_QP'
                diagnostic_qp = logical(varargin{i+1});
            case 'DIAGNOSTIC_CONSTRAINTS'
                diagnostic_constraints = logical(varargin{i+1});
            otherwise
                % Hmmm, something wrong with the parameter string
                error(['Unrecognized option: ''' varargin{i} '''']);
        end;
    end;
end

%%
%--------------------------------------------------------------
% set display mode
%--------------------------------------------------------------
if (verbose == 0) | (verbose == 1)
    warning('off','all');
    options = optimset('Display', 'off','Diagnostics','off','MaxIter',2000,'TolFun',1e-10,'TolX',1e-10 );
else
    warning('on','all');
    options = optimset('Display', 'final','Diagnostics','on','MaxIter',2000,'TolFun',1e-10,'TolX',1e-10);
end

%%
%--------------------------------------------------------------
% identify the affine space that best represent the data set y
%--------------------------------------------------------------
my = mean(Y,2);
Y = Y-repmat(my,1,N);
[Up,D] = svds(Y*Y'/N,p-1);
% represent y in the subspace R^(p-1)
Y = Up*Up'*Y;
% lift y
Y = Y + repmat(my,1,N); 
% compute the orthogonal component of my
my_ortho = my-Up*Up'*my;
% define another orthonormal direction
Up = [Up my_ortho/sqrt(sum(my_ortho.^2))];
sing_values = diag(D);
% get coordinates in R^p
Y = Up'*Y;
%%
%------------------------------------------
% spherize if requested
%------------------------------------------
if strcmp(spherize,'yes')
    Y = Up*Y;
    Y = Y-repmat(my,1,N);
    C = diag(1./sqrt((diag(D+lambda*eye(p-1)))));
    Y=C*Up(:,1:p-1)'*Y;
    %  lift
    Y(p,:) = 1;
    % normalize to unit norm
    Y = Y/sqrt(p);
end


%---------------------------------------------
%  Initialization
%---------------------------------------------
if M == 0
    % Initialize with VCA
    Mvca = VCA(Y,'Endmembers',p);
    M = Mvca;
    % expand Q
    Ym = mean(M,2);
    Ym = repmat(Ym,1,p);
    dQ = M - Ym;
    % fraction: multiply by p is to make sure Q0 starts with a feasible
    % initial value.
    M = M + p*dQ;
else
    % Ensure that M is in the affine set defined by the data
    M = M-repmat(my,1,p);
    M = Up(:,1:p-1)*Up(:,1:p-1)'*M;
    M = M +  repmat(my,1,p);
    M = Up'*M;   % represent in the data subspace
    % is sherization is set
    if strcmp(spherize,'yes')
        M = Up*M-repmat(my,1,p);
        M=C*Up(:,1:p-1)'*M;
        %  lift
        M(p,:) = 1;
        % normalize to unit norm
        M = M/sqrt(p);
    end
end
Q0 = inv(M);
Q=Q0;


%%
%---------------------------------------------
%  build constraint matrices
%---------------------------------------------
% inequality matrix
%A = kron(Y',eye(p));   % size np * p^2
% equality matrx
E = kron(eye(p),ones(1,p));
% equality independent vector
qm = sum(inv(Y*Y')*Y,2);

%%
%---------------------------------------------
%  sequence of QPs - main body (DIAGNOSTIC)
%---------------------------------------------
% IMPORTANT:
%   This block preserves the original MVSA stopping decisions.  It only
%   records what happens around each quadProg1 call so we can determine why
%   one K may finish earlier than another.
%
%   NOTE: in this MVSA implementation exitflag is set to 1 immediately after
%   quadProg1 returns. Therefore it is NOT the true internal solver exit flag.
%   The diagnostic reports this explicitly.
throtle = 0;

qp_template = struct( ...
    'iter', NaN, ...
    'throtle_in', NaN, ...
    'expected_inner_cap_if_standard_quadProg1', NaN, ...
    'feasibility_steps', NaN, ...
    'neg_before_feas', NaN, ...
    'neg_after_feas', NaN, ...
    'mu', NaN, ...
    'f0', NaN, ...
    'detQ0_abs', NaN, ...
    'qp_time_sec', NaN, ...
    'q_step_norm', NaN, ...
    'q_step_rel', NaN, ...
    'f_candidate', NaN, ...
    'objective_improvement', NaN, ...
    'candidate_better', false, ...
    'candidate_neg_count', NaN, ...
    'candidate_eq_residual', NaN, ...
    'relative_change_vs_prev', NaN, ...
    'throtle_out', NaN, ...
    'outer_iter_time_sec', NaN, ...
    'decision', '');
qp_diag = repmat(qp_template, MMiters, 1);

actual_outer_iters = 0;
total_feasibility_steps = 0;
termination_reason = 'max_outer_iterations';
qp_total_tic = tic;

if diagnostic_qp
    fprintf('\n================================================================================================================\n');
    fprintf('MVSA QP DIAGNOSTIC: p=%d, K=%d, N=%d, MMiters=%d, tol_f=%.3e\n', p, p-1, N, MMiters, tol_f);
    fprintf('IMPORTANT: outer code hard-codes exitflag=1 after quadProg1; this is not quadProg1 internal convergence status.\n');
    fprintf('Columns: iter | thr_in | feas | f0 | f_candidate | improve | rel(prev) | qrel | QP_sec | decision\n');
    fprintf('----------------------------------------------------------------------------------------------------------------\n');
end

for k = 1:MMiters
    actual_outer_iters = actual_outer_iters + 1;
    iter_tic = tic;
    throtle_in = throtle;

    % In the standard quadProg1 version used by this code family, throtle=0
    % uses an inner cap of 150 and throtle=1 uses 300.  This is reported only
    % as a diagnostic expectation; the outer MVSA function cannot observe the
    % actual inner iteration count because quadProg1 returns q only.
    if throtle_in == 1
        expected_inner_cap = 300;
    else
        expected_inner_cap = 150;
    end

    % ---------------- make initial point feasible ----------------
    M = inv(Q);
    Ym = mean(M,2);
    Ym = repmat(Ym,1,p);
    dW = M - Ym;
    count = 0;

    if diagnostic_constraints
        neg_before_feas = nnz((inv(M)*Y) < 0);
    else
        neg_before_feas = NaN;
    end

    if ~throtle
        while sum(sum((inv(M)*Y) < 0)) > 0
            % Original code printed once per expansion.  Suppress that noisy
            % I/O here and report the final count once per outer iteration.
            M = M + 0.01*dW;
            count = count + 1;
            if count > 100
                if verbose
                    fprintf('\n could not make M feasible after 100 expansions\n')
                end
                break;
            end
        end
    end
    total_feasibility_steps = total_feasibility_steps + count;

    Q = inv(M);
    if diagnostic_constraints
        neg_after_feas = nnz((Q*Y) < 0);
    else
        neg_after_feas = NaN;
    end

    % ---------------- quadratic model ----------------
    g = -M';
    g = g(:);
    H = mu*eye(p^2)+diag(g.^2);
    q0 = Q(:);
    Q0 = Q;
    f = g-H*q0;

    f0_val = -log(abs(det(Q0)));
    f0_quad = f0_val; %#ok<NASGU>
    detQ0_abs = abs(det(Q0));
    energy_decreasing = 0;

    % ---------------- QP call: time it directly ----------------
    qp_tic = tic;
    q = quadProg1(H, f, Y, zeros(p*N,1), E, qm, q0, throtle);
    qp_time_sec = toc(qp_tic);

    q_step_norm = norm(q-q0);
    q_step_rel = q_step_norm / max(norm(q0), eps);

    % Outer code in the supplied MVSA implementation hard-codes this.
    exitflag = 1;

    % Keep original unreachable branches intact for fidelity.
    if exitflag < 0
        if verbose
            fprintf('\n iter = %d, quadprog did not converge: exitflag = %d \n', k, exitflag);
        end
        if k == MMiters
            if ~any_energy_decreasing
                if verbose, fprintf('\n outputing the VCA solution\n'); end
                Q = inv(Mvca);
                q = Q(:);
            else
                if verbose, fprintf('\n outputing the solution of the previous iteration\n'); end
                Q = Q0;
                q = Q(:);
            end
        else
            Q = Q0;
            q = Q(:);
            mu = 1e-2;
        end
    elseif exitflag == 0
        f_quad = f0_val + (q-q0)'*g + 1/2*(q-q0)'*H*(q-q0);
        if (f0_quad > f_quad) && (sum(sum(Q*Y < -slack)) == 0)
            energy_decreasing = 1;
            any_energy_decreasing = 1;
        else
            Q = Q0;
            q = Q(:);
            mu = 1e-2;
        end
    end

    decision = 'continue';
    f_candidate = NaN;
    objective_improvement = NaN;
    candidate_better = false;
    candidate_neg_count = NaN;
    candidate_eq_residual = NaN;
    relative_change_vs_prev = NaN;

    if energy_decreasing || (exitflag == 1)
        Qcand = reshape(q,p,p);
        f_candidate = -log(abs(det(Qcand)));
        objective_improvement = f0_val - f_candidate; % >0 means candidate is better
        candidate_better = (f_candidate <= f0_val);

        if diagnostic_constraints
            candidate_neg_count = nnz((Qcand*Y) < -slack);
            candidate_eq_residual = norm(E*q - qm);
        end

        if isfinite(f_val_back) && isfinite(f_candidate) && f_candidate ~= 0
            relative_change_vs_prev = abs((f_val_back-f_candidate)/f_candidate);
        end

        Q = Qcand;

        % ---------------- ORIGINAL line-search/throtle logic ----------------
        if (f0_val < f_candidate)
            Q = Q0;
            if throtle == 1
                decision = 'BREAK: consecutive non-improving candidate (throtle==1)';

                qp_diag(k).iter = k;
                qp_diag(k).throtle_in = throtle_in;
                qp_diag(k).expected_inner_cap_if_standard_quadProg1 = expected_inner_cap;
                qp_diag(k).feasibility_steps = count;
                qp_diag(k).neg_before_feas = neg_before_feas;
                qp_diag(k).neg_after_feas = neg_after_feas;
                qp_diag(k).mu = mu;
                qp_diag(k).f0 = f0_val;
                qp_diag(k).detQ0_abs = detQ0_abs;
                qp_diag(k).qp_time_sec = qp_time_sec;
                qp_diag(k).q_step_norm = q_step_norm;
                qp_diag(k).q_step_rel = q_step_rel;
                qp_diag(k).f_candidate = f_candidate;
                qp_diag(k).objective_improvement = objective_improvement;
                qp_diag(k).candidate_better = candidate_better;
                qp_diag(k).candidate_neg_count = candidate_neg_count;
                qp_diag(k).candidate_eq_residual = candidate_eq_residual;
                qp_diag(k).relative_change_vs_prev = relative_change_vs_prev;
                qp_diag(k).throtle_out = throtle;
                qp_diag(k).outer_iter_time_sec = toc(iter_tic);
                qp_diag(k).decision = decision;

                if diagnostic_qp
                    fprintf('%4d | %6d | %4d | %+9.4e | %+11.4e | %+9.2e | %9.2e | %7.2e | %7.3f | %s\n', ...
                        k, throtle_in, count, f0_val, f_candidate, objective_improvement, ...
                        relative_change_vs_prev, q_step_rel, qp_time_sec, decision);
                end
                termination_reason = 'line_search_throtle_break';
                break
            else
                throtle = 1;
                decision = 'reject QP candidate; set throtle=1';
            end
        else
            throtle = 0;
            decision = 'accept QP candidate';
        end

        energy_decreasing = 1;
    end

    % ---------------- ORIGINAL termination test ----------------
    tol_pass = false;
    if energy_decreasing
        if abs((f_val_back-f_candidate)/f_candidate) < tol_f && ~throtle
            tol_pass = true;
            decision = 'BREAK: relative objective change < tol_f';
        end
        f_val_back = f_candidate;
    end

    % Record diagnostics.
    qp_diag(k).iter = k;
    qp_diag(k).throtle_in = throtle_in;
    qp_diag(k).expected_inner_cap_if_standard_quadProg1 = expected_inner_cap;
    qp_diag(k).feasibility_steps = count;
    qp_diag(k).neg_before_feas = neg_before_feas;
    qp_diag(k).neg_after_feas = neg_after_feas;
    qp_diag(k).mu = mu;
    qp_diag(k).f0 = f0_val;
    qp_diag(k).detQ0_abs = detQ0_abs;
    qp_diag(k).qp_time_sec = qp_time_sec;
    qp_diag(k).q_step_norm = q_step_norm;
    qp_diag(k).q_step_rel = q_step_rel;
    qp_diag(k).f_candidate = f_candidate;
    qp_diag(k).objective_improvement = objective_improvement;
    qp_diag(k).candidate_better = candidate_better;
    qp_diag(k).candidate_neg_count = candidate_neg_count;
    qp_diag(k).candidate_eq_residual = candidate_eq_residual;
    qp_diag(k).relative_change_vs_prev = relative_change_vs_prev;
    qp_diag(k).throtle_out = throtle;
    qp_diag(k).outer_iter_time_sec = toc(iter_tic);
    qp_diag(k).decision = decision;

    if diagnostic_qp
        fprintf('%4d | %6d | %4d | %+9.4e | %+11.4e | %+9.2e | %9.2e | %7.2e | %7.3f | %s\n', ...
            k, throtle_in, count, f0_val, f_candidate, objective_improvement, ...
            relative_change_vs_prev, q_step_rel, qp_time_sec, decision);
        if diagnostic_constraints
            fprintf('     constraints: neg(before/after feasibility/candidate@-slack) = %g / %g / %g, eq residual = %.3e\n', ...
                neg_before_feas, neg_after_feas, candidate_neg_count, candidate_eq_residual);
        end
    end

    if tol_pass
        termination_reason = 'tol_f_break';
        break;
    end
end

qp_loop_time_sec = toc(qp_total_tic);
qp_diag = qp_diag(1:actual_outer_iters);

diag_stats = struct();
diag_stats.p = p;
diag_stats.K = p-1;
diag_stats.N = N;
diag_stats.requested_outer_iters = MMiters;
diag_stats.actual_outer_iters = actual_outer_iters;
diag_stats.total_feasibility_steps = total_feasibility_steps;
diag_stats.termination_reason = termination_reason;
diag_stats.qp_loop_time_sec = qp_loop_time_sec;
diag_stats.sum_quadProg1_time_sec = sum([qp_diag.qp_time_sec]);
diag_stats.qp = qp_diag;
diag_stats.exitflag_note = 'Outer MVSA hard-codes exitflag=1; it is not quadProg1 internal status.';

if diagnostic_qp
    fprintf('----------------------------------------------------------------------------------------------------------------\n');
    fprintf('QP diagnostic summary: actual outer iters=%d/%d, total feasibility steps=%d\n', ...
        actual_outer_iters, MMiters, total_feasibility_steps);
    fprintf('Termination reason       : %s\n', termination_reason);
    fprintf('Sum quadProg1 time       : %.6f s\n', diag_stats.sum_quadProg1_time_sec);
    fprintf('Whole outer-QP loop time : %.6f s\n', qp_loop_time_sec);
    fprintf('================================================================================================================\n\n');
end

if strcmp(spherize,'yes')
    M = inv(Q);
    %M(1,:)
    % refer to the initial affine set
    % unscale
    M = M*sqrt(p);
    %remove offset
    M = M(1:p-1,:);
    % unspherize
    M = Up(:,1:p-1)*diag(sqrt(diag(D+lambda*eye(p-1))))*M;
    % sum ym
    M = M + repmat(my,1,p);
    Sest = Q*Y;
else
    M = inv(Q);%*sqrt(my_ortho'*my_ortho)
    M = Up*M;%*sqrt(my_ortho'*my_ortho);;
    Sest = Q*Y;
end



% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % %

end
